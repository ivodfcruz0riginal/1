# QA v0.8 — Linhagens

## Testes realizados
- `npm install`
- `npm run build`

## Resultado
Build concluída com sucesso.

## Validação funcional
- `EfetivoScreen` compila com o novo `LineagePanel`.
- `AnimalDetailPanel` recebe `allAnimals` e calcula genealogia sem quebrar animais sem pai/mãe registados.
- `lineageService` deriva tudo a partir do efetivo existente, sem criar estado duplicado.

## Riscos conhecidos
- A base de dados de animais ainda tem genealogia parcial; algumas linhagens mostram poucos ancestrais.
- A próxima iteração deve ligar linhagens às Crónicas da Herdade e aos eventos de reprodução.

## Próximo passo recomendado
v0.9 — Crónicas da Herdade: registar automaticamente linhas dominantes, vacas fundadoras, sementais marcantes e riscos de perda genética.
