# QA — v0.5 Memória das Personagens

## Validação técnica
- `npm run build` executado com sucesso.
- Build Vite gerada em `dist/`.

## Verificações funcionais
- O Conselho da Manhã continua limitado a até 3 assuntos.
- Memórias pesadas podem regressar como assuntos de continuidade.
- Reuniões com localização contextual apontam para o quadro correspondente.
- Eventos por quadro continuam a ser resolvidos através de `locationEventService`.
- O Diário/Crónica do Dia inclui assuntos resolvidos, pendentes e memórias que podem regressar.

## Riscos a observar no próximo teste manual
- Follow-ups podem tornar-se repetitivos se a mesma memória regressar demasiadas vezes.
- Algumas reuniões ainda dependem de `dialogueId` para inferir localização física.
- Será preciso testar uma semana de jogo para avaliar ritmo e repetição.
