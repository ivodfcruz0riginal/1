# QA — v0.7 World Simulation

## Build
Validada com `npm run build`.

## Testes realizados
- Compilação TypeScript/Vite concluída com sucesso.
- `ADVANCE_DAY_PERIOD` mantém o ciclo diário existente.
- Eventos autónomos são registados no `dayLog`.
- Rotinas são registadas no `dayLog` sem bloquear o jogador.
- Acontecimentos do mundo podem criar notificações em locais.
- Memórias de personagens são criadas quando um acontecimento envolve uma personagem.

## Riscos conhecidos
- A simulação ainda é simples e baseada em regras fixas.
- A frequência dos eventos deve ser afinada em playtest para evitar excesso de ruído no Diário.
- O próximo passo deve mostrar melhor estes acontecimentos no ecrã, sem transformar tudo em popup.

## Critério de aprovação
Ao avançar o período do dia, a herdade deixa registos próprios: rotinas, pequenos acontecimentos e sinais de que a casa continua a funcionar sem depender totalmente do jogador.
