# QA Sprint 22 — Ciclo de Um Dia

## Testes executados
- Build de produção: `npm run build`.
- Verificação de TypeScript/Vite.
- Verificação de importações novas.
- Verificação de compatibilidade com saves antigos via hidratação de `dayOfMonth`, `dayPeriod` e `dayLog`.

## Resultado
A build compila com sucesso.

## Riscos conhecidos
- A granularidade diária ainda usa tarefas geradas de forma simples.
- O avanço mensal permanece disponível para debug/uso rápido, mas o fluxo recomendado passa a ser Fechar Dia.
- O ciclo diário está implementado dentro da lógica mensal existente, sem alterar ainda todos os sistemas económicos para escala diária.

## Próximo QA recomendado
Jogar 7 dias seguidos e confirmar:
- Conselho da Manhã varia por dia.
- Diário recebe entradas diárias.
- Fechar dia regenera tarefas.
- Save/Load mantém o dia correto.
