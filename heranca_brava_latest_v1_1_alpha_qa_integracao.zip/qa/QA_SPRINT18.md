# QA — Sprint 18

## Build base
`heranca_brava_duarte_vertical_sprint17.zip`

## Testes realizados
- Instalação de dependências com `npm install`.
- Build de produção com `npm run build`.

## Resultado
Build concluída com sucesso.

## Verificações funcionais
- Conselho da Manhã mantém funcionamento anterior.
- Reuniões normais continuam com botões Atender/Adiar.
- Reuniões com conflito mostram dois pareceres e duas decisões.
- Resolver conflito atualiza memórias e relações.
- Resolver conflito escreve evento no Diário.

## Riscos conhecidos
- O conflito depende de condições sanitárias/económicas; pode não surgir em todos os meses.
- Os impactos numéricos são iniciais e devem ser afinados após playtest.
