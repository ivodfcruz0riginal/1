# QA — v0.9 Crónicas da Herdade

## Build
Validada com:

```bash
npm run build
```

Resultado: build concluída com sucesso.

## Verificações
- `chronicleService.ts` compila e não cria dependências circulares críticas.
- `LivroTab.tsx` continua acessível dentro do Escritório.
- O Livro da Casa apresenta dados reais do estado do jogo.
- As linhagens vêm de `lineageService.ts`, sem duplicar cálculo genético.
- As crónicas usam `dayLog`, `eventLog`, `characterMemories` e `annualReports` existentes.
- Os assuntos pendentes do Conselho da Manhã aparecem como assuntos vivos.
- O texto mantém a linguagem de herdade e evita transformar o jogo num relatório técnico.

## Riscos conhecidos
- A qualidade narrativa das crónicas depende da qualidade dos textos registados pelos restantes sistemas.
- Algumas entradas podem repetir informação semelhante entre Diário e Crónicas; isto deverá ser afinado no playtest.
- Ainda não existe edição manual ou fixação de uma crónica como “marco histórico” pelo jogador.
