# QA — v1.0 Alpha Integração Total

## Verificado
- Build compila com `npm run build`.
- `alphaIntegrationService.ts` não duplica motores existentes; apenas agrega estado.
- `EscritorioScreen.tsx` mostra um painel de orientação sem criar uma nova navegação.
- `closeDayState` usa uma crónica integrada para ligar dia atual e amanhã.

## Riscos
- O painel pode ficar demasiado informativo se houver muitos assuntos simultâneos.
- O texto de crónica ainda é gerado por regras simples; deverá ser refinado após playtest.
- A recomendação de próximo passo depende da qualidade dos dados de Conselho e eventos de localização.

## Próximo QA recomendado
Jogar 7 dias seguidos e verificar:
- repetição do Fio do Dia;
- coerência entre Conselho e evento no quadro;
- se o Diário ajuda ou se cria ruído;
- se o jogador sabe o que fazer sem tutorial.
