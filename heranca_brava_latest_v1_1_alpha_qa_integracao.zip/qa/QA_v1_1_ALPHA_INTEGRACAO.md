# QA v1.1 — Alpha Integração

## Build base

`heranca_brava_latest_v1_0_alpha_integracao.zip`

## Testes previstos

1. Abrir Escritório.
2. Confirmar presença do painel **Fio do Dia**.
3. Confirmar presença do painel **Alpha QA · Integração**.
4. Atender um assunto do Conselho da Manhã.
5. Visitar o quadro recomendado.
6. Resolver ou adiar o evento contextual.
7. Avançar período e verificar registos de rotina/mundo vivo.
8. Fechar o dia e confirmar geração de crónica.

## Critério de aprovação

A cadeia `Conselho → Quadro → Decisão → Diário → Crónicas → Amanhã` deve aparecer no painel QA com o menor número possível de bloqueantes.
