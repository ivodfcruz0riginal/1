# QA — v0.6 Identidade dos Cercados e Quadros

## Build testada
`heranca_brava_latest_v0_6_identidade_cercados.zip`

## Testes realizados

### Compilação
- Comando: `npm run build`
- Resultado: aprovado.

### Tipos e integração
- `LocationIdentity` foi adicionada como campo opcional para não quebrar localizações existentes.
- `LocationDetailPanel` lê a identidade apenas quando existe.
- Localizações sem identidade continuam funcionais.

### Autenticidade
- Removida qualquer lógica de “treino” de toiros.
- A linguagem passa a focar observação, maneio, lote, camada, água, sombra, peleas e condição corporal.

## Riscos conhecidos
- A identidade visual dos locais ainda é textual; falta futuramente refletir isto no mapa e nos eventos contextuais.
- Alguns locais ainda não têm identidade completa, nomeadamente Casa, Escritório, Tentadero, Armazém e Oficina.

## Próximo foco recomendado
Integrar esta identidade nos eventos contextuais, para que o Cercado Norte gere situações diferentes do Cercado Sul.
