import type { Animal } from '../types/animal';
import type { AnimalLineageTrail, LineageSummary, LineageTraitAverages } from '../types/lineage';

function round(value: number): number {
  return Math.round(value);
}

function average(values: number[]): number {
  if (values.length === 0) return 0;
  return round(values.reduce((sum, value) => sum + value, 0) / values.length);
}

function averageTraits(animals: Animal[]): LineageTraitAverages {
  return {
    bravery: average(animals.map(animal => animal.bravery)),
    nobility: average(animals.map(animal => animal.nobility)),
    mobility: average(animals.map(animal => animal.mobility)),
    stamina: average(animals.map(animal => animal.stamina)),
    transmission: average(animals.map(animal => animal.transmission)),
    fertility: average(animals.map(animal => animal.fertility)),
  };
}

function getAnimalMap(animals: Animal[]): Record<string, Animal> {
  return animals.reduce<Record<string, Animal>>((map, animal) => {
    map[animal.id] = animal;
    return map;
  }, {});
}

function isBreedingAnimal(animal: Animal): boolean {
  return animal.status === 'Ativo' && (
    animal.category === 'Semental' ||
    animal.category === 'Vaca' ||
    animal.category === 'Novilha' ||
    animal.approvedForBreeding
  );
}

function isYoungAnimal(animal: Animal): boolean {
  return animal.category === 'Bezerro' || animal.category === 'Bezerra' || animal.category === 'Novilho' || animal.category === 'Utrero' || animal.ageYears <= 4;
}

export function calculateLineageInfluenceScore(animals: Animal[]): number {
  if (animals.length === 0) return 0;
  const traits = averageTraits(animals);
  const activeCount = animals.filter(animal => animal.status === 'Ativo').length;
  const breedingCount = animals.filter(isBreedingAnimal).length;
  const youngCount = animals.filter(isYoungAnimal).length;
  const quality = (traits.bravery + traits.nobility + traits.mobility + traits.transmission) / 4;
  const depth = Math.min(20, activeCount * 1.2 + breedingCount * 2 + youngCount * 0.7);
  return Math.max(0, Math.min(100, round((quality * 0.78) + depth)));
}

function buildRiskLevel(animals: Animal[], breedingAnimals: number): LineageSummary['riskLevel'] {
  const activeCount = animals.filter(animal => animal.status === 'Ativo').length;
  if (activeCount <= 2 || breedingAnimals <= 1) return 'alto';
  if (activeCount <= 5 || breedingAnimals <= 3) return 'medio';
  return 'baixo';
}

function buildLineageNote(summary: Omit<LineageSummary, 'note'>): string {
  const strongestTrait = Object.entries(summary.averageTraits)
    .sort(([, a], [, b]) => b - a)[0]?.[0];

  const traitLabel: Record<string, string> = {
    bravery: 'bravura',
    nobility: 'nobreza',
    mobility: 'mobilidade',
    stamina: 'fôlego',
    transmission: 'transmissão',
    fertility: 'fertilidade',
  };

  if (summary.riskLevel === 'alto') {
    return `Linha curta. A casa deve proteger esta origem antes de perder variabilidade.`;
  }
  if (summary.influenceScore >= 85) {
    return `Linha muito influente na casa, marcada por ${traitLabel[strongestTrait] ?? 'regularidade'}.`;
  }
  if (summary.youngAnimals >= 3) {
    return `Linha com renovação ativa; importa observar a próxima camada antes de decidir.`;
  }
  return `Linha estável, ainda sem domínio claro sobre o efetivo atual.`;
}

export function createLineageSummaries(animals: Animal[]): LineageSummary[] {
  const groups = animals.reduce<Record<string, Animal[]>>((map, animal) => {
    const key = animal.bloodline || 'Sem origem definida';
    map[key] = [...(map[key] ?? []), animal];
    return map;
  }, {});

  return Object.entries(groups)
    .map(([name, group]) => {
      const activeAnimals = group.filter(animal => animal.status === 'Ativo');
      const breeding = group.filter(isBreedingAnimal);
      const foundingFemales = group
        .filter(animal => animal.sex === 'Fêmea' && (animal.category === 'Vaca' || animal.category === 'Novilha'))
        .sort((a, b) => (b.transmission + b.fertility + b.nobility) - (a.transmission + a.fertility + a.nobility))
        .slice(0, 3);
      const keySires = group
        .filter(animal => animal.sex === 'Macho' && (animal.category === 'Semental' || animal.approvedForBreeding))
        .sort((a, b) => (b.transmission + b.bravery + b.nobility) - (a.transmission + a.bravery + a.nobility))
        .slice(0, 3);
      const recentYoung = group
        .filter(isYoungAnimal)
        .sort((a, b) => b.birthYear - a.birthYear || b.exactAgeMonths - a.exactAgeMonths)
        .slice(0, 4);
      const averageAgeYears = group.length > 0 ? Math.round(group.reduce((sum, animal) => sum + animal.ageYears, 0) / group.length) : 0;
      const partial: Omit<LineageSummary, 'note'> = {
        id: name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        name,
        totalAnimals: group.length,
        activeAnimals: activeAnimals.length,
        breedingAnimals: breeding.length,
        sementais: group.filter(animal => animal.category === 'Semental').length,
        vacas: group.filter(animal => animal.category === 'Vaca').length,
        youngAnimals: group.filter(isYoungAnimal).length,
        averageAgeYears,
        averageTraits: averageTraits(group),
        influenceScore: calculateLineageInfluenceScore(group),
        foundingFemales,
        keySires,
        recentYoung,
        riskLevel: buildRiskLevel(group, breeding.length),
      };
      return { ...partial, note: buildLineageNote(partial) };
    })
    .sort((a, b) => b.influenceScore - a.influenceScore || b.totalAnimals - a.totalAnimals);
}

export function getAnimalLineageTrail(animal: Animal, animals: Animal[]): AnimalLineageTrail {
  const map = getAnimalMap(animals);
  const father = animal.fatherId ? map[animal.fatherId] : undefined;
  const mother = animal.motherId ? map[animal.motherId] : undefined;
  const paternalGrandfather = father?.fatherId ? map[father.fatherId] : undefined;
  const paternalGrandmother = father?.motherId ? map[father.motherId] : undefined;
  const maternalGrandfather = mother?.fatherId ? map[mother.fatherId] : undefined;
  const maternalGrandmother = mother?.motherId ? map[mother.motherId] : undefined;
  const knownAncestors = [father, mother, paternalGrandfather, paternalGrandmother, maternalGrandfather, maternalGrandmother].filter(Boolean).length;
  const generationDepth = knownAncestors >= 5 ? 3 : knownAncestors >= 2 ? 2 : knownAncestors >= 1 ? 1 : 0;

  const readableTrail = [
    father ? `Pai: ${father.name} (${father.bloodline})` : 'Pai: sem registo direto',
    mother ? `Mãe: ${mother.name} (${mother.bloodline})` : 'Mãe: sem registo direto',
    paternalGrandfather ? `Avô paterno: ${paternalGrandfather.name}` : '',
    maternalGrandfather ? `Avô materno: ${maternalGrandfather.name}` : '',
  ].filter(Boolean);

  return {
    animal,
    father,
    mother,
    paternalGrandfather,
    paternalGrandmother,
    maternalGrandfather,
    maternalGrandmother,
    generationDepth,
    knownAncestors,
    readableTrail,
  };
}

export function createLineageDiaryLine(animals: Animal[]): string {
  const summaries = createLineageSummaries(animals);
  const top = summaries[0];
  const risk = summaries.find(summary => summary.riskLevel === 'alto');
  if (!top) return 'O livro genealógico ainda não tem informação suficiente.';
  const riskText = risk ? ` Atenção à linha ${risk.name}, ainda curta na casa.` : '';
  return `A linha ${top.name} é hoje a mais influente da herdade (${top.influenceScore}/100).${riskText}`;
}
