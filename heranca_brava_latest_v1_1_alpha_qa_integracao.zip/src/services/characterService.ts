import type { GameState, Month } from '../store/gameTypes';
import type { CharacterAgendaStatus, CharacterMemory, CharacterMemoryType } from '../types/character';
import type { NarrativeCharacterId } from '../types/narrative';
import type { LocationId } from '../types/location';
import { CHARACTER_ROUTINES, getLivingCharacter } from '../data/characters';

function clamp(value: number, min = 0, max = 100): number {
  return Math.max(min, Math.min(max, value));
}

export function createCharacterMemory(
  characterId: NarrativeCharacterId,
  type: CharacterMemoryType,
  title: string,
  text: string,
  month: Month,
  year: number,
  weight = 1,
  locationId?: LocationId | null,
): CharacterMemory {
  return {
    id: `mem-${characterId}-${year}-${month}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
    characterId,
    type,
    title,
    text,
    month,
    year,
    weight,
    locationId: locationId ?? null,
  };
}

export function addCharacterMemory(state: GameState, memory: CharacterMemory): GameState {
  const memories = [memory, ...(state.characterMemories ?? [])]
    .sort((a, b) => b.weight - a.weight)
    .slice(0, 80);
  return { ...state, characterMemories: memories };
}

export function recentMemoriesForCharacter(
  state: Pick<GameState, 'characterMemories'>,
  characterId: NarrativeCharacterId,
  limit = 3,
): CharacterMemory[] {
  return (state.characterMemories ?? [])
    .filter(memory => memory.characterId === characterId)
    .slice(0, limit);
}

export function relationshipTone(state: GameState, characterId: NarrativeCharacterId): string {
  const relationship = state.relationships?.[characterId];
  const profile = getLivingCharacter(characterId);
  if (!relationship) return profile ? `${profile.name} ainda está a formar opinião sobre a casa.` : 'Relação por definir.';

  const score = relationship.trust + relationship.respect + relationship.loyalty - relationship.fatigue * 0.4 - (relationship.tension ?? 0) * 0.7;
  if (score >= 210) return `${profile?.name ?? 'A personagem'} fala com confiança e sentido de pertença.`;
  if (score >= 165) return `${profile?.name ?? 'A personagem'} mantém uma relação sólida com a casa.`;
  if (score >= 120) return `${profile?.name ?? 'A personagem'} cumpre o seu papel, mas observa as decisões com reserva.`;
  return `${profile?.name ?? 'A personagem'} começa a acumular dúvidas sobre a condução da herdade.`;
}

export function applyRelationshipShift(
  state: GameState,
  characterId: NarrativeCharacterId,
  shift: Partial<{ trust: number; respect: number; loyalty: number; fatigue: number; affinity: number; tension: number }>,
): GameState {
  const current = state.relationships[characterId];
  if (!current) return state;
  return {
    ...state,
    relationships: {
      ...state.relationships,
      [characterId]: {
        ...current,
        trust: clamp(current.trust + (shift.trust ?? 0)),
        respect: clamp(current.respect + (shift.respect ?? 0)),
        loyalty: clamp(current.loyalty + (shift.loyalty ?? 0)),
        fatigue: clamp(current.fatigue + (shift.fatigue ?? 0)),
        affinity: clamp((current.affinity ?? 50) + (shift.affinity ?? 0)),
        tension: clamp((current.tension ?? 10) + (shift.tension ?? 0)),
      },
    },
  };
}


export function getCharacterAgendaStatus(
  state: Pick<GameState, 'month' | 'season'>,
  characterId: NarrativeCharacterId,
): CharacterAgendaStatus {
  const matching = CHARACTER_ROUTINES
    .filter(routine => routine.characterId === characterId)
    .filter(routine => !routine.months || routine.months.includes(state.month))
    .filter(routine => !routine.seasons || routine.seasons.includes(state.season))
    .sort((a, b) => b.priority - a.priority)[0];

  const profile = getLivingCharacter(characterId);
  if (!matching) {
    return {
      characterId,
      availability: 'available',
      locationId: profile?.defaultLocationId ?? 'escritorio',
      label: 'Rotina normal',
      note: profile ? `${profile.name} está disponível dentro da rotina normal da herdade.` : 'Disponível.',
    };
  }

  return {
    characterId,
    availability: matching.availability,
    locationId: matching.locationId,
    label: matching.label,
    note: matching.note,
    substituteCharacterId: matching.substituteCharacterId,
  };
}

export function isCharacterAvailableForOffice(
  state: Pick<GameState, 'month' | 'season'>,
  characterId: NarrativeCharacterId,
): boolean {
  const agenda = getCharacterAgendaStatus(state, characterId);
  return agenda.availability === 'available';
}
