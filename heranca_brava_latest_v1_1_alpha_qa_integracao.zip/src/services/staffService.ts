import type { StaffMember, StaffMonthlyResult, StaffRole } from '../types/staff';

function clamp(value: number, min = 0, max = 100): number {
  return Math.max(min, Math.min(max, value));
}

export function roleLabel(role: StaffRole): string {
  const labels: Record<StaffRole, string> = {
    maioral: 'Maioral',
    campino: 'Campino',
    veterinario: 'Veterinário',
    administracao: 'Administração',
    motorista: 'Motorista',
  };
  return labels[role];
}

export function calculatePayroll(staff: StaffMember[]): number {
  return staff
    .filter(member => member.status !== 'indisponivel')
    .reduce((sum, member) => sum + member.monthlySalary, 0);
}

export function averageStaffScore(staff: StaffMember[]): number {
  if (staff.length === 0) return 50;
  const total = staff.reduce((sum, member) => (
    sum + member.competence * 0.45 + member.loyalty * 0.25 + member.morale * 0.2 - member.fatigue * 0.1
  ), 0);
  return clamp(Math.round(total / staff.length));
}

export function processMonthlyStaff(staff: StaffMember[]): StaffMonthlyResult {
  const events: string[] = [];
  const updated = staff.map(member => {
    const fatigueGain = member.status === 'descanso' ? -18 : member.role === 'maioral' ? 5 : 4;
    const moraleDrift = member.fatigue > 70 ? -4 : member.morale < 45 ? -2 : 1;
    const nextFatigue = clamp(member.fatigue + fatigueGain);
    const nextMorale = clamp(member.morale + moraleDrift);
    const nextStatus = member.status === 'descanso' ? 'ativo' : member.status;

    if (nextFatigue >= 80) events.push(`${member.name} acusa cansaço elevado. O rendimento da equipa pode cair.`);
    if (nextMorale <= 35) events.push(`${member.name} mostra desmotivação. Pode ser necessário intervir.`);

    return {
      ...member,
      fatigue: nextFatigue,
      morale: nextMorale,
      status: nextStatus,
    };
  });

  return {
    staff: updated,
    payroll: calculatePayroll(updated),
    events,
  };
}

export function giveStaffRest(staff: StaffMember[], id: string): StaffMember[] {
  return staff.map(member => member.id === id
    ? { ...member, status: 'descanso', fatigue: clamp(member.fatigue - 12), morale: clamp(member.morale + 4) }
    : member);
}

export function giveStaffBonus(staff: StaffMember[], id: string): StaffMember[] {
  return staff.map(member => member.id === id
    ? { ...member, morale: clamp(member.morale + 10), loyalty: clamp(member.loyalty + 5) }
    : member);
}

export function trainStaff(staff: StaffMember[], id: string): StaffMember[] {
  return staff.map(member => member.id === id
    ? { ...member, competence: clamp(member.competence + 4), fatigue: clamp(member.fatigue + 5), morale: clamp(member.morale + 2) }
    : member);
}
