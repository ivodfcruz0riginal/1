import type { GameState } from '../store/gameTypes';
import type { LocationId } from '../types/location';
import { createLineageSummaries } from './lineageService';

export type ChronicleScope = 'dia' | 'campanha' | 'linhagem' | 'pessoal' | 'territorio' | 'economia';
export type ChronicleTone = 'memoria' | 'alerta' | 'triunfo' | 'rotina' | 'risco';

export interface ChronicleEntry {
  id: string;
  year: number;
  month: string;
  dayOfMonth?: number;
  title: string;
  text: string;
  scope: ChronicleScope;
  tone: ChronicleTone;
  locationId?: LocationId | null;
  weight: number;
}

const scopeLabel: Record<ChronicleScope, string> = {
  dia: 'Dia',
  campanha: 'Campanha',
  linhagem: 'Linhagens',
  pessoal: 'Pessoas',
  territorio: 'Herdade',
  economia: 'Economia',
};

const toneWeight: Record<ChronicleTone, number> = {
  triunfo: 5,
  alerta: 4,
  risco: 4,
  memoria: 3,
  rotina: 1,
};

function includesAny(text: string, terms: string[]): boolean {
  const lower = text.toLowerCase();
  return terms.some(term => lower.includes(term));
}

function toneFromText(text: string): ChronicleTone {
  if (includesAny(text, ['prémio', 'triunfo', 'cumprido', 'reforçado', 'melhor', 'nasceu'])) return 'triunfo';
  if (includesAny(text, ['crítico', 'crítica', 'alerta', 'preocup', 'risco', 'falha', 'seca', 'doença', 'lesão'])) return 'alerta';
  if (includesAny(text, ['adiado', 'ficou por', 'ignorad', 'tensão', 'perda', 'morte', 'avaria'])) return 'risco';
  return 'memoria';
}

function scopeFromText(text: string): ChronicleScope {
  if (includesAny(text, ['linha', 'linhagem', 'semental', 'vaca fundadora', 'geneal'])) return 'linhagem';
  if (includesAny(text, ['antónio', 'duarte', 'beatriz', 'joaquim', 'maioral', 'veterinário', 'administradora', 'campino'])) return 'pessoal';
  if (includesAny(text, ['tesouraria', 'contrato', 'receita', 'despesa', '€', 'contas', 'pagamento'])) return 'economia';
  if (includesAny(text, ['cercado', 'currais', 'barragem', 'oficina', 'tentadero', 'vedação', 'bebedouro'])) return 'territorio';
  return 'campanha';
}

function sentenceFromDayRecord(description: string): string {
  return description.replace(/\s+/g, ' ').trim();
}

function createLineageChronicles(state: GameState): ChronicleEntry[] {
  const summaries = createLineageSummaries(state.animals).slice(0, 3);
  return summaries.map((summary, index) => ({
    id: `chron-lineage-${summary.id}`,
    year: state.year,
    month: state.month,
    title: index === 0 ? `Linha dominante: ${summary.name}` : `Linha observada: ${summary.name}`,
    text: `${summary.note} Mantém ${summary.activeAnimals} animal(is) ativo(s), ${summary.breedingAnimals} reprodutor(es) e influência ${summary.influenceScore}/100.`,
    scope: 'linhagem',
    tone: summary.riskLevel === 'alto' ? 'risco' : index === 0 ? 'triunfo' : 'memoria',
    weight: summary.riskLevel === 'alto' ? 5 : index === 0 ? 4 : 2,
  }));
}

export function createChronicleEntries(state: GameState): ChronicleEntry[] {
  const dayEntries: ChronicleEntry[] = (state.dayLog ?? [])
    .filter(record => record.type === 'day_closed' || record.type === 'location_event' || record.type === 'world_event' || record.type === 'morning_council')
    .slice(0, 80)
    .map(record => {
      const text = sentenceFromDayRecord(record.description);
      const tone = toneFromText(`${record.title} ${text}`);
      const scope = record.type === 'day_closed' ? 'dia' : scopeFromText(`${record.title} ${text}`);
      return {
        id: `chron-day-${record.id}`,
        year: record.year,
        month: record.month,
        dayOfMonth: record.dayOfMonth,
        title: record.title,
        text,
        scope,
        tone,
        locationId: record.locationId ?? null,
        weight: toneWeight[tone] + (record.type === 'day_closed' ? 1 : 0),
      };
    });

  const memoryEntries: ChronicleEntry[] = (state.characterMemories ?? [])
    .slice(0, 60)
    .filter(memory => memory.weight >= 2)
    .map(memory => {
      const tone = memory.type === 'meeting_postponed' || memory.type === 'warning' ? 'alerta' : memory.weight >= 4 ? 'triunfo' : 'memoria';
      return {
        id: `chron-memory-${memory.id}`,
        year: memory.year,
        month: memory.month,
        title: memory.title,
        text: memory.text,
        scope: 'pessoal',
        tone,
        locationId: memory.locationId ?? null,
        weight: Math.max(memory.weight, toneWeight[tone]),
      };
    });

  const annualEntries: ChronicleEntry[] = (state.annualReports ?? []).slice(0, 8).map(report => ({
    id: `chron-annual-${report.year}`,
    year: report.year,
    month: 'Dezembro',
    title: `Fecho do ano ${report.year}`,
    text: `Resultado anual de ${report.annualProfit.toLocaleString('pt-PT')}€. Objetivos cumpridos: ${report.objectiveResults.filter(result => result.achieved).length}/${report.objectiveResults.length}.`,
    scope: 'campanha',
    tone: report.annualProfit >= 0 ? 'triunfo' : 'risco',
    weight: report.annualProfit >= 0 ? 4 : 5,
  }));

  const eventEntries: ChronicleEntry[] = (state.eventLog ?? [])
    .slice(0, 40)
    .map(event => {
      const tone = toneFromText(event.text);
      return {
        id: `chron-event-${event.id}`,
        year: event.year,
        month: event.month,
        title: scopeLabel[scopeFromText(event.text)],
        text: event.text,
        scope: scopeFromText(event.text),
        tone,
        locationId: event.locationId ?? null,
        weight: toneWeight[tone],
      };
    });

  return [
    ...createLineageChronicles(state),
    ...dayEntries,
    ...memoryEntries,
    ...annualEntries,
    ...eventEntries,
  ]
    .sort((a, b) => b.year - a.year || b.weight - a.weight)
    .slice(0, 80);
}

export function getChronicleHighlights(state: GameState): ChronicleEntry[] {
  return createChronicleEntries(state)
    .filter(entry => entry.weight >= 4)
    .slice(0, 8);
}

export function getOpenChronicleThreads(state: GameState): ChronicleEntry[] {
  const pendingMeetings = state.morningCouncil
    .filter(item => item.status === 'pending' || item.status === 'postponed')
    .map(item => ({
      id: `chron-open-${item.id}`,
      year: state.year,
      month: state.month,
      dayOfMonth: state.dayOfMonth,
      title: `Por resolver: ${item.title}`,
      text: `${item.characterName} trouxe este assunto ao escritório. Enquanto não for tratado, a herdade carrega esta preocupação para os próximos dias.`,
      scope: item.locationId === 'escritorio' ? 'campanha' : 'territorio',
      tone: item.urgency === 'critica' || item.urgency === 'alta' ? 'alerta' : 'memoria',
      locationId: item.locationId,
      weight: item.urgency === 'critica' ? 5 : item.urgency === 'alta' ? 4 : 2,
    } satisfies ChronicleEntry));

  const pendingTasks = state.dailyTasks
    .filter(task => task.status === 'pending')
    .slice(0, 4)
    .map(task => ({
      id: `chron-task-${task.id}`,
      year: state.year,
      month: state.month,
      dayOfMonth: state.dayOfMonth,
      title: `Tarefa pendente: ${task.label}`,
      text: 'Ainda não foi concluída. Se ficar para trás, entrará no Diário como responsabilidade adiada.',
      scope: 'dia',
      tone: 'rotina',
      weight: 1,
    } satisfies ChronicleEntry));

  return [...pendingMeetings, ...pendingTasks].slice(0, 8);
}

export function describeChronicleTone(tone: ChronicleTone): string {
  switch (tone) {
    case 'triunfo': return 'Marco';
    case 'alerta': return 'Alerta';
    case 'risco': return 'Risco';
    case 'rotina': return 'Rotina';
    default: return 'Memória';
  }
}

export function describeChronicleScope(scope: ChronicleScope): string {
  return scopeLabel[scope];
}
