import type { GameState, Month } from '../store/gameTypes';
import type { AnnualObjective, AnnualReport, CampaignSnapshot, ObjectiveProgress, ObjectiveResult, RanchStatusTier } from '../types/campaign';
import { prestigeTier } from './prestigeService';
import { averageStaffScore } from './staffService';

const CAMPAIGN_START_YEAR = 1985;
const CAMPAIGN_TARGET_YEARS = 5;
const MONTHS_IN_YEAR = 12;

function clamp(value: number, min = 0, max = 100): number {
  return Math.max(min, Math.min(max, value));
}

function activeAnimals(state: GameState): number {
  return state.animals.filter(animal => animal.status === 'Ativo').length;
}

function activeContracts(state: GameState): number {
  return state.contracts.filter(contract => contract.status === 'active').length;
}

function staffMorale(state: GameState): number {
  if (!state.staff || state.staff.length === 0) return 50;
  return Math.round(state.staff.reduce((sum, member) => sum + member.morale, 0) / state.staff.length);
}

function yearRecords(state: GameState, year: number) {
  return state.economy.history.filter(record => record.year === year);
}

export function classifyRanchStatus(state: GameState): RanchStatusTier {
  const treasury = state.economy.treasury;
  const prestige = state.prestige;
  const recent = state.economy.history.slice(0, 6);
  const recentProfit = recent.reduce((sum, record) => sum + record.profit, 0);
  const staffScore = averageStaffScore(state.staff ?? []);

  if (treasury < 15_000 || recentProfit < -80_000 || staffScore < 35) return 'Em Crise';
  if (prestige >= 90 && treasury >= 220_000) return 'Lendária';
  if (prestige >= 75 && treasury >= 150_000) return 'Referência Nacional';
  if (prestige >= 58 && treasury >= 90_000) return 'Referência Regional';
  if (treasury >= 70_000 && recentProfit >= 0 && prestige >= 45) return 'Em Crescimento';
  return 'Estável';
}

export function getObjectiveCurrentValue(state: GameState, objective: AnnualObjective): number {
  switch (objective.metric) {
    case 'treasury': return Math.round(state.economy.treasury);
    case 'prestige': return Math.round(state.prestige);
    case 'animals': return activeAnimals(state);
    case 'activeContracts': return activeContracts(state);
    case 'staffMorale': return staffMorale(state);
    default: return 0;
  }
}

export function getObjectiveProgress(state: GameState, objective: AnnualObjective): ObjectiveProgress {
  const currentValue = getObjectiveCurrentValue(state, objective);
  const progress = objective.target <= 0 ? 100 : clamp(Math.round((currentValue / objective.target) * 100));
  return { ...objective, currentValue, progress, achieved: currentValue >= objective.target };
}

export function createAnnualObjectives(year: number, state: GameState, createdMonth: Month): AnnualObjective[] {
  const targetTreasury = Math.max(90_000, Math.round(state.economy.treasury + 18_000));
  const targetPrestige = Math.min(95, Math.max(45, Math.round(state.prestige + 4)));
  const targetAnimals = Math.max(activeAnimals(state) + 2, 35);
  const targetMorale = Math.min(85, Math.max(60, staffMorale(state) + 3));

  return [
    {
      id: `obj-${year}-treasury`,
      year,
      title: 'Casa com folga financeira',
      description: `Fechar o ano com pelo menos ${targetTreasury.toLocaleString('pt-PT')}€ em tesouraria.`,
      metric: 'treasury',
      target: targetTreasury,
      createdMonth,
    },
    {
      id: `obj-${year}-prestige`,
      year,
      title: 'Reforçar o nome da casa',
      description: `Atingir ${targetPrestige} pontos de prestígio.`,
      metric: 'prestige',
      target: targetPrestige,
      createdMonth,
    },
    {
      id: `obj-${year}-staff`,
      year,
      title: 'Equipa em condições',
      description: `Manter a moral média do pessoal acima de ${targetMorale}.`,
      metric: 'staffMorale',
      target: targetMorale,
      createdMonth,
    },
    {
      id: `obj-${year}-animals`,
      year,
      title: 'Efetivo em crescimento',
      description: `Chegar a ${targetAnimals} animais ativos.`,
      metric: 'animals',
      target: targetAnimals,
      createdMonth,
    },
  ];
}

export function evaluateObjectives(state: GameState, year: number): ObjectiveResult[] {
  return (state.annualObjectives ?? [])
    .filter(objective => objective.year === year)
    .map(objective => {
      const progress = getObjectiveProgress(state, objective);
      return {
        objectiveId: objective.id,
        title: objective.title,
        achieved: progress.achieved,
        currentValue: progress.currentValue,
        target: objective.target,
        rewardText: progress.achieved ? '+1 prestígio simbólico e registo positivo no relatório anual.' : 'Sem prémio anual.',
      };
    });
}

export function createAnnualReport(state: GameState, reportYear: number, generatedMonth: Month): AnnualReport {
  const records = yearRecords(state, reportYear);
  const annualIncome = records.reduce((sum, record) => sum + record.income, 0);
  const annualExpenses = records.reduce((sum, record) => sum + record.expenses, 0);
  const annualProfit = records.reduce((sum, record) => sum + record.profit, 0);
  const previousReport = state.annualReports?.[0];
  const treasuryDelta = previousReport ? state.economy.treasury - previousReport.treasury : annualProfit;
  const objectiveResults = evaluateObjectives(state, reportYear);
  const notableEvents = state.eventLog
    .filter(event => event.year === reportYear)
    .slice(0, 6)
    .map(event => event.text);

  return {
    id: `annual-${reportYear}-${Date.now()}`,
    year: reportYear,
    generatedMonth,
    treasury: Math.round(state.economy.treasury),
    treasuryDelta: Math.round(treasuryDelta),
    annualIncome,
    annualExpenses,
    annualProfit,
    prestige: state.prestige,
    prestigeTier: prestigeTier(state.prestige),
    activeAnimals: activeAnimals(state),
    births: state.animals.filter(animal => animal.age === 0 && animal.status === 'Ativo').length,
    deaths: state.eventLog.filter(event => event.year === reportYear && /morte|morreu|falecimento/i.test(event.text)).length,
    activeContracts: activeContracts(state),
    staffAverageMorale: staffMorale(state),
    ranchStatus: classifyRanchStatus(state),
    notableEvents,
    objectiveResults,
  };
}

export function getCampaignSnapshot(state: GameState): CampaignSnapshot {
  const monthsPlayed = Math.max(0, (state.year - CAMPAIGN_START_YEAR) * MONTHS_IN_YEAR);
  const campaignYear = Math.min(CAMPAIGN_TARGET_YEARS, Math.floor(monthsPlayed / MONTHS_IN_YEAR) + 1);
  const targetMonths = CAMPAIGN_TARGET_YEARS * MONTHS_IN_YEAR;
  const monthsRemaining = Math.max(0, targetMonths - monthsPlayed);

  return {
    campaignYear,
    monthsPlayed,
    targetYears: CAMPAIGN_TARGET_YEARS,
    monthsRemaining,
    completionPercent: clamp(Math.round((monthsPlayed / targetMonths) * 100)),
    ranchStatus: classifyRanchStatus(state),
    activeObjectives: (state.annualObjectives ?? [])
      .filter(objective => objective.year === state.year)
      .map(objective => getObjectiveProgress(state, objective)),
  };
}
