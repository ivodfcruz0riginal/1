import type { GameState } from '../store/gameTypes';
import type { DayPeriod } from '../types/day';
import type { LocationId } from '../types/location';
import type { NarrativeCharacterId } from '../types/narrative';
import { getLivingCharacter } from '../data/characters';

export interface RoutineStep {
  characterId: NarrativeCharacterId;
  characterName: string;
  period: DayPeriod;
  locationId: LocationId;
  activity: string;
  visibleToPlayer: boolean;
}

const ROUTINE_BY_PERIOD: Record<NarrativeCharacterId, Partial<Record<DayPeriod, Omit<RoutineStep, 'characterId' | 'characterName' | 'period'>>>> = {
  maioral: {
    manha: { locationId: 'escritorio', activity: 'prepara o Conselho da Manhã e revê os recados dos campinos', visibleToPlayer: true },
    meio_dia: { locationId: 'cercado_norte', activity: 'faz a ronda aos lotes e observa sinais de alteração no comportamento', visibleToPlayer: true },
    tarde: { locationId: 'currais', activity: 'confere portões, mangas e trabalhos de maneio previstos', visibleToPlayer: true },
    noite: { locationId: 'casa', activity: 'fecha o dia com notas para amanhã', visibleToPlayer: false },
  },
  veterinario: {
    manha: { locationId: 'currais', activity: 'passa pelos animais sinalizados para observação', visibleToPlayer: true },
    meio_dia: { locationId: 'cercado_sul', activity: 'observa à distância lotes com menor pressão de maneio', visibleToPlayer: false },
    tarde: { locationId: 'escritorio', activity: 'deixa pareceres clínicos e custos estimados', visibleToPlayer: true },
  },
  administrador: {
    manha: { locationId: 'escritorio', activity: 'organiza contas, contratos e pagamentos pendentes', visibleToPlayer: true },
    meio_dia: { locationId: 'armazem', activity: 'confere despesas de forragens e reservas', visibleToPlayer: false },
    tarde: { locationId: 'escritorio', activity: 'fecha notas financeiras para o diário da casa', visibleToPlayer: true },
  },
  campino: {
    manha: { locationId: 'cercado_norte', activity: 'abre cancelas, verifica bebedouros e acompanha o maioral', visibleToPlayer: true },
    meio_dia: { locationId: 'barragem', activity: 'confere água e pequenas avarias de bombagem', visibleToPlayer: true },
    tarde: { locationId: 'oficina', activity: 'arruma material e ajuda em reparações ligeiras', visibleToPlayer: false },
  },
  familia: {
    manha: { locationId: 'casa', activity: 'acompanha assuntos domésticos da herdade', visibleToPlayer: false },
    tarde: { locationId: 'escritorio', activity: 'passa pelo escritório quando há decisões de família', visibleToPlayer: false },
  },
  empresario: {
    meio_dia: { locationId: 'escritorio', activity: 'telefona quando existem propostas em aberto', visibleToPlayer: false },
    tarde: { locationId: 'escritorio', activity: 'aparece se houver oportunidade comercial urgente', visibleToPlayer: true },
  },
};

export function getRoutineStep(state: Pick<GameState, 'dayPeriod'>, characterId: NarrativeCharacterId): RoutineStep | null {
  const profile = getLivingCharacter(characterId);
  const base = ROUTINE_BY_PERIOD[characterId]?.[state.dayPeriod];
  if (!profile || !base) return null;
  return {
    characterId,
    characterName: profile.name,
    period: state.dayPeriod,
    ...base,
  };
}

export function getRoutineSnapshot(state: Pick<GameState, 'dayPeriod'>): RoutineStep[] {
  return (Object.keys(ROUTINE_BY_PERIOD) as NarrativeCharacterId[])
    .map(characterId => getRoutineStep(state, characterId))
    .filter((step): step is RoutineStep => Boolean(step));
}

export function describeVisibleRoutines(state: Pick<GameState, 'dayPeriod'>): string[] {
  return getRoutineSnapshot(state)
    .filter(step => step.visibleToPlayer)
    .map(step => `${step.characterName} está em ${step.locationId}: ${step.activity}.`);
}
