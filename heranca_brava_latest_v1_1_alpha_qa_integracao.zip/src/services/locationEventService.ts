import { LOCATION_EVENTS } from '../data/locationEvents';
import type { GameState } from '../store/gameTypes';
import type { LocationId } from '../types/location';
import type { ActiveLocationEvent, LocationEventTemplate } from '../types/locationEvent';

function occupationRatioForLocation(state: GameState, locationId: LocationId): number {
  const location = state.locations.find(item => item.id === locationId);
  if (!location || location.capacity <= 0) return 0;
  return location.currentOccupation / location.capacity;
}

function matchesCondition(template: LocationEventTemplate, state: GameState): boolean {
  const condition = template.condition;
  if (!condition) return true;
  const location = state.locations.find(item => item.id === template.locationId);
  if (!location) return false;

  if (condition.minTreasury !== undefined && state.economy.treasury < condition.minTreasury) return false;
  if (condition.maxTreasury !== undefined && state.economy.treasury > condition.maxTreasury) return false;
  if (condition.notification && !location.notifications.includes(condition.notification)) return false;
  if (condition.seasons && !condition.seasons.includes(state.season)) return false;

  const occupationRatio = occupationRatioForLocation(state, template.locationId);
  if (condition.minOccupationRatio !== undefined && occupationRatio < condition.minOccupationRatio) return false;
  if (condition.maxOccupationRatio !== undefined && occupationRatio > condition.maxOccupationRatio) return false;

  return true;
}

function recentlyResolved(state: GameState, eventId: string, locationId: LocationId): boolean {
  const needle = `Evento de quadro resolvido — ${eventId}`;
  return state.dayLog?.slice(0, 25).some(record => record.locationId === locationId && record.description.includes(needle)) ?? false;
}

export function createLocationEvent(state: GameState, locationId: LocationId): ActiveLocationEvent | null {
  const candidates = LOCATION_EVENTS.filter(event =>
    event.locationId === locationId &&
    matchesCondition(event, state) &&
    !recentlyResolved(state, event.id, locationId),
  );

  if (candidates.length === 0) return null;

  const priority = { critica: 4, alta: 3, media: 2, baixa: 1 } as const;
  const selected = candidates
    .slice()
    .sort((a, b) => priority[b.severity] - priority[a.severity])[0];

  return {
    ...selected,
    instanceId: `loc-${selected.id}-${state.year}-${state.month}-${state.dayOfMonth}-${Date.now()}`,
    dayOfMonth: state.dayOfMonth,
    month: state.month,
    year: state.year,
  };
}

export function getSeverityLabel(severity: ActiveLocationEvent['severity']): string {
  switch (severity) {
    case 'critica': return 'Crítica';
    case 'alta': return 'Alta';
    case 'media': return 'Média';
    default: return 'Baixa';
  }
}

export function getSeverityClass(severity: ActiveLocationEvent['severity']): string {
  switch (severity) {
    case 'critica': return 'bg-red-700/20 border-red-700/40 text-red-900';
    case 'alta': return 'bg-orange-700/20 border-orange-700/40 text-orange-900';
    case 'media': return 'bg-amber-700/20 border-amber-700/40 text-amber-900';
    default: return 'bg-emerald-700/15 border-emerald-700/30 text-emerald-900';
  }
}
