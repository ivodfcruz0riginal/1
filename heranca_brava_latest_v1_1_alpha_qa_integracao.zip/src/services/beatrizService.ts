import type { GameState } from '../store/gameTypes';
import type { CharacterMemory } from '../types/character';
import type { Contract } from '../types/contract';
import type { MorningCouncilItem, MeetingUrgency, OfficeTabKey } from '../types/meeting';
import { calculatePayroll } from './staffService';
import { recentMemoriesForCharacter } from './characterService';

export type BeatrizMood = 'serena' | 'vigilante' | 'alarmada' | 'severa' | 'satisfeita';

export interface BeatrizSnapshot {
  mood: BeatrizMood;
  headline: string;
  spokenLine: string;
  financialReading: string;
  recommendedTab: OfficeTabKey;
  urgency: MeetingUrgency;
  administrativeOpinion: string;
  memoryHook?: CharacterMemory;
}

function money(value: number): string {
  return `${Math.round(value).toLocaleString('pt-PT')}€`;
}

function getRecentMemoryHook(state: GameState): CharacterMemory | undefined {
  return recentMemoriesForCharacter(state, 'administrador', 1)[0];
}

function activeContractExposure(contracts: Contract[]): number {
  return contracts
    .filter(contract => contract.status === 'active')
    .reduce((sum, contract) => sum + (contract.monthlyExpense ?? 0) + Math.max(0, (contract.upfrontExpense ?? 0) - (contract.upfrontIncome ?? 0)), 0);
}

function offeredContractCount(contracts: Contract[]): number {
  return contracts.filter(contract => contract.status === 'offered').length;
}

function monthlyBurn(state: GameState): number {
  const payroll = calculatePayroll(state.staff ?? []);
  const lastExpenses = state.economy.history?.[0]?.expenses ?? 0;
  const activeExposure = activeContractExposure(state.contracts ?? []);
  return payroll + Math.round(lastExpenses * 0.35) + activeExposure;
}

export function getBeatrizSnapshot(state: GameState): BeatrizSnapshot {
  const relationship = state.relationships.administrador;
  const memoryHook = getRecentMemoryHook(state);
  const treasury = state.economy.treasury;
  const burn = monthlyBurn(state);
  const runwayMonths = burn > 0 ? treasury / burn : 99;
  const offers = offeredContractCount(state.contracts ?? []);
  const active = (state.contracts ?? []).filter(contract => contract.status === 'active').length;
  const lastProfit = state.economy.history?.[0]?.profit ?? 0;

  if (treasury < 18_000 || runwayMonths < 2) {
    return {
      mood: 'alarmada',
      headline: 'D. Beatriz entra com o livro de contas aberto',
      spokenLine: `Patrão, a casa tem ${money(treasury)} em caixa. Isto já não é prudência; é sobrevivência.`,
      financialReading: `A margem de tesouraria cobre cerca de ${Math.max(0, runwayMonths).toFixed(1)} mês(es) de encargos estimados.`,
      recommendedTab: 'economia',
      urgency: 'critica',
      administrativeOpinion: 'Congelar despesas não essenciais, rever contratos ativos e evitar decisões de prestígio que obriguem a pagamento imediato.',
      memoryHook,
    };
  }

  if (lastProfit < -8_000 || runwayMonths < 4) {
    return {
      mood: 'severa',
      headline: 'D. Beatriz pede contenção antes do próximo mês',
      spokenLine: 'As contas ainda respiram, mas já não aceitam improvisos. Uma casa respeitada também precisa de caixa.',
      financialReading: `Último resultado mensal: ${money(lastProfit)}. Margem estimada: ${runwayMonths.toFixed(1)} mês(es).`,
      recommendedTab: 'economia',
      urgency: 'alta',
      administrativeOpinion: 'Adiar investimento, negociar receitas seguras e cortar custos antes que o prestígio esconda fragilidade financeira.',
      memoryHook,
    };
  }

  if (offers >= 2) {
    return {
      mood: 'vigilante',
      headline: 'D. Beatriz separa as propostas por risco',
      spokenLine: 'Nem toda a proposta que entra merece ser aceite. Há contratos que compram dinheiro hoje e vendem problemas amanhã.',
      financialReading: `${offers} proposta(s) por decidir. ${active} contrato(s) ativo(s) já pesam no planeamento.`,
      recommendedTab: 'contratos',
      urgency: 'alta',
      administrativeOpinion: 'Escolher contratos com margem líquida clara e evitar acumular compromissos no mesmo período.',
      memoryHook,
    };
  }

  if ((relationship.tension ?? 0) >= 55 || relationship.trust < 45) {
    return {
      mood: 'severa',
      headline: 'D. Beatriz fala sem rodeios',
      spokenLine: 'Eu posso organizar números, patrão. Não posso organizar decisões tomadas contra eles.',
      financialReading: 'A relação administrativa está tensa e pode dificultar alertas antecipados sobre risco financeiro.',
      recommendedTab: 'pessoal',
      urgency: 'normal',
      administrativeOpinion: 'Restabelecer confiança na administração antes de abrir novas frentes de investimento.',
      memoryHook,
    };
  }

  if (treasury >= 120_000 && state.prestige >= 65) {
    return {
      mood: 'satisfeita',
      headline: 'D. Beatriz permite-se um raro elogio',
      spokenLine: 'A casa está equilibrada. É precisamente nestes momentos que não se deve confundir folga com licença para gastar.',
      financialReading: `Tesouraria: ${money(treasury)}. Prestígio: ${Math.round(state.prestige)}/100.`,
      recommendedTab: 'campanha',
      urgency: 'baixa',
      administrativeOpinion: 'Consolidar reservas e preparar investimento com retorno mensurável.',
      memoryHook,
    };
  }

  return {
    mood: 'serena',
    headline: 'D. Beatriz traz o ponto de contas',
    spokenLine: 'Hoje não trago alarme. Trago disciplina. É diferente, mas igualmente necessária.',
    financialReading: `Tesouraria atual: ${money(treasury)}. Encargo mensal estimado: ${money(burn)}.`,
    recommendedTab: 'economia',
    urgency: 'normal',
    administrativeOpinion: 'Manter despesas sob leitura mensal e não aceitar contratos sem comparar risco, prazo e impacto de caixa.',
    memoryHook,
  };
}

export function applyBeatrizVoiceToMeeting(state: GameState, meeting: MorningCouncilItem): MorningCouncilItem {
  if (meeting.characterId !== 'administrador') return meeting;
  const snapshot = getBeatrizSnapshot(state);
  const memoryText = snapshot.memoryHook
    ? ` Lembra-se de "${snapshot.memoryHook.title}".`
    : '';

  return {
    ...meeting,
    title: meeting.title.includes('Tesouraria') || meeting.title.includes('Contratos') || meeting.title.includes('Objetivos')
      ? snapshot.headline
      : meeting.title,
    summary: `${snapshot.spokenLine} ${snapshot.financialReading} Parecer: ${snapshot.administrativeOpinion}${memoryText}`,
    urgency: meeting.urgency === 'critica' || meeting.urgency === 'alta' ? meeting.urgency : snapshot.urgency,
    recommendedTab: snapshot.recommendedTab,
  };
}
