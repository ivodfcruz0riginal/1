import type { GameState } from '../store/gameTypes';
import type { DayPeriod, DayRecord } from '../types/day';
import { DAY_PERIOD_ORDER } from '../types/day';

export function getNextDayPeriod(period: DayPeriod): DayPeriod {
  const index = DAY_PERIOD_ORDER.indexOf(period);
  if (index < 0 || index === DAY_PERIOD_ORDER.length - 1) return 'noite';
  return DAY_PERIOD_ORDER[index + 1];
}

export function isLastDayPeriod(period: DayPeriod): boolean {
  return period === 'noite';
}

export function createDayRecord(
  state: Pick<GameState, 'dayOfMonth' | 'month' | 'year' | 'dayPeriod'>,
  type: DayRecord['type'],
  title: string,
  description: string,
  locationId?: DayRecord['locationId'],
): DayRecord {
  return {
    id: `day-${state.year}-${state.month}-${state.dayOfMonth}-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    dayOfMonth: state.dayOfMonth,
    month: state.month,
    year: state.year,
    period: state.dayPeriod,
    type,
    title,
    description,
    locationId,
  };
}

export function summarizeDay(state: GameState): string {
  const completed = state.dailyTasks.filter(task => task.status === 'completed').length;
  const ignored = state.dailyTasks.filter(task => task.status === 'ignored').length;
  const attended = state.morningCouncil.filter(item => item.status === 'attended').length;
  const postponed = state.morningCouncil.filter(item => item.status === 'postponed').length;
  const visits = state.dayLog.filter(record => record.dayOfMonth === state.dayOfMonth && record.type === 'location_visit').length;

  return `Dia ${state.dayOfMonth} de ${state.month}: ${attended} assunto(s) atendido(s), ${postponed} adiado(s), ${completed} tarefa(s) concluída(s), ${ignored} ignorada(s) e ${visits} deslocação(ões) registada(s).`;
}

export function getDayPressure(state: GameState): 'calmo' | 'normal' | 'exigente' | 'critico' {
  const pendingCritical = state.morningCouncil.some(item => item.status === 'pending' && item.urgency === 'critica');
  const pendingHigh = state.morningCouncil.filter(item => item.status === 'pending' && item.urgency === 'alta').length;
  const pendingTasks = state.dailyTasks.filter(task => task.status === 'pending').length;
  if (pendingCritical) return 'critico';
  if (pendingHigh >= 2 || pendingTasks >= 4) return 'exigente';
  if (pendingTasks <= 1 && pendingHigh === 0) return 'calmo';
  return 'normal';
}
