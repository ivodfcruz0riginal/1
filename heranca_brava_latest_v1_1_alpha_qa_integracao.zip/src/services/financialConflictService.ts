import type { GameState } from '../store/gameTypes';
import type { MorningCouncilItem } from '../types/meeting';
import type { NarrativeCharacterId } from '../types/narrative';
import { getBeatrizSnapshot } from './beatrizService';
import { relationshipTone, recentMemoriesForCharacter } from './characterService';

function monthKey(state: Pick<GameState, 'month' | 'year'>): string {
  return `${state.year}-${state.month}`;
}

function money(value: number): string {
  return `${Math.round(value).toLocaleString('pt-PT')}€`;
}

function bestOfferedContract(state: GameState) {
  return (state.contracts ?? [])
    .filter(contract => contract.status === 'offered')
    .sort((a, b) => ((b.upfrontIncome ?? 0) + (b.completionIncome ?? 0) + (b.monthlyIncome ?? 0) * b.durationMonths) - ((a.upfrontIncome ?? 0) + (a.completionIncome ?? 0) + (a.monthlyIncome ?? 0) * a.durationMonths))[0];
}

function shouldCreateBeatrizEmpresarioConflict(state: GameState): boolean {
  const offered = (state.contracts ?? []).filter(contract => contract.status === 'offered');
  if (offered.length === 0) return false;
  const treasuryPressure = state.economy.treasury < 65_000;
  const prestigeTemptation = state.prestige < 55 || offered.some(contract => (contract.prestigeEffect ?? 0) >= 4);
  const monthlyExposure = (state.contracts ?? [])
    .filter(contract => contract.status === 'active')
    .reduce((sum, contract) => sum + (contract.monthlyExpense ?? 0), 0);
  return treasuryPressure || prestigeTemptation || monthlyExposure > 4_000 || offered.length >= 2;
}

export function createBeatrizEmpresarioConflictMeeting(state: GameState): MorningCouncilItem | null {
  if (!shouldCreateBeatrizEmpresarioConflict(state)) return null;
  const contract = bestOfferedContract(state);
  if (!contract) return null;

  const beatriz = getBeatrizSnapshot(state);
  const beatrizMemory = recentMemoriesForCharacter(state, 'administrador', 1)[0];
  const empresarioMemory = recentMemoriesForCharacter(state, 'empresario', 1)[0];
  const estimatedValue = (contract.upfrontIncome ?? 0) + (contract.completionIncome ?? 0) + (contract.monthlyIncome ?? 0) * contract.durationMonths;
  const estimatedCost = (contract.upfrontExpense ?? 0) + (contract.monthlyExpense ?? 0) * contract.durationMonths;

  return {
    id: `council-${monthKey(state)}-conflito-beatriz-empresario`,
    monthKey: monthKey(state),
    characterId: 'administrador',
    characterName: 'D. Beatriz e Empresário',
    role: 'Conflito financeiro',
    title: 'Prudência ou oportunidade',
    summary: `A administração e o empresário não leem a proposta da mesma maneira. ${relationshipTone(state, 'administrador')} ${relationshipTone(state, 'empresario')}`,
    urgency: beatriz.urgency === 'critica' ? 'critica' : 'alta',
    locationId: 'escritorio',
    recommendedTab: 'contratos',
    status: 'pending',
    professionalConflict: {
      id: `conflict-${monthKey(state)}-beatriz-empresario`,
      type: 'prestigio_vs_prudencia',
      primaryCharacterId: 'administrador' as NarrativeCharacterId,
      primaryCharacterName: 'D. Beatriz',
      secondaryCharacterId: 'empresario' as NarrativeCharacterId,
      secondaryCharacterName: 'Empresário',
      primaryLine: `Patrão, "${contract.title}" pode trazer nome, mas antes de nome vem caixa. Receita prevista: ${money(estimatedValue)}. Encargo previsto: ${money(estimatedCost)}.`,
      secondaryLine: `Esta oportunidade não espera. Uma casa que quer subir tem de aparecer onde se fala de toiros. Se hesitarmos, chamam outra ganadaria.`,
      stakes: `Contrato em análise: ${contract.partner}. Risco declarado: ${contract.riskLabel ?? 'por avaliar'}. A decisão mexe com tesouraria, prestígio e confiança comercial.`,
      primaryChoiceLabel: 'Seguir D. Beatriz',
      secondaryChoiceLabel: 'Aceitar o risco do Empresário',
      memoryHint: [beatrizMemory?.title, empresarioMemory?.title].filter(Boolean).join(' · ') || undefined,
    },
  };
}
