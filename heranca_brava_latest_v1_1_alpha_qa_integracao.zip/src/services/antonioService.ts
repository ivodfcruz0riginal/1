import type { GameState } from '../store/gameTypes';
import type { CharacterMemory } from '../types/character';
import type { MorningCouncilItem, MeetingUrgency, OfficeTabKey } from '../types/meeting';
import { recentMemoriesForCharacter } from './characterService';

export type AntonioMood = 'sereno' | 'preocupado' | 'tenso' | 'orgulhoso' | 'reservado';

export interface AntonioSnapshot {
  mood: AntonioMood;
  headline: string;
  spokenLine: string;
  concern: string;
  recommendedTab: OfficeTabKey;
  urgency: MeetingUrgency;
  memoryHook?: CharacterMemory;
}

function money(value: number): string {
  return `${Math.round(value).toLocaleString('pt-PT')}€`;
}

function tiredStaffCount(state: GameState): number {
  return (state.staff ?? []).filter(member => member.fatigue >= 70 || member.morale <= 42).length;
}

function offeredContractsCount(state: GameState): number {
  return (state.contracts ?? []).filter(contract => contract.status === 'offered').length;
}

function unresolvedMeetingsCount(state: GameState): number {
  return (state.morningCouncil ?? []).filter(item => item.status === 'postponed').length;
}

function getRecentMemoryHook(state: GameState): CharacterMemory | undefined {
  return recentMemoriesForCharacter(state, 'maioral', 1)[0];
}

export function getAntonioSnapshot(state: GameState): AntonioSnapshot {
  const relationship = state.relationships.maioral;
  const memoryHook = getRecentMemoryHook(state);
  const tired = tiredStaffCount(state);
  const offers = offeredContractsCount(state);
  const postponed = unresolvedMeetingsCount(state);

  if (state.economy.treasury < 20_000) {
    return {
      mood: 'tenso',
      headline: 'António chega calado ao escritório',
      spokenLine: `Patrão, com ${money(state.economy.treasury)} em caixa, hoje não é dia para vaidades. É dia de proteger a casa.`,
      concern: 'Tesouraria crítica. António recomenda cortar risco antes de aceitar novos encargos.',
      recommendedTab: 'economia',
      urgency: 'critica',
      memoryHook,
    };
  }

  if (tired >= 2) {
    return {
      mood: 'preocupado',
      headline: 'António fala antes de se sentar',
      spokenLine: 'A equipa está a acusar o corpo. O campo não perdoa quando os homens entram cansados.',
      concern: `${tired} pessoa(s) da casa precisam de atenção antes dos próximos trabalhos.`,
      recommendedTab: 'pessoal',
      urgency: 'alta',
      memoryHook,
    };
  }

  if (state.prestige < 42) {
    return {
      mood: 'reservado',
      headline: 'António olha para os jornais antigos na parede',
      spokenLine: 'O nome da casa já pesou mais nas conversas. Temos de voltar a merecer respeito, passo a passo.',
      concern: `Prestígio em ${Math.round(state.prestige)}/100. A casa precisa de uma decisão que recupere autoridade.`,
      recommendedTab: 'prestigio',
      urgency: 'normal',
      memoryHook,
    };
  }

  if (offers >= 2) {
    return {
      mood: 'preocupado',
      headline: 'António pousa duas cartas em cima da secretária',
      spokenLine: 'Há propostas demais para decidir de ouvido. Uma boa praça também pode queimar um lote mal escolhido.',
      concern: `${offers} propostas por decidir. António recomenda rever contratos antes de avançar o mês.`,
      recommendedTab: 'contratos',
      urgency: 'alta',
      memoryHook,
    };
  }

  if (postponed >= 2 || relationship.tension >= 55) {
    return {
      mood: 'reservado',
      headline: 'António espera de pé, sem tirar o barrete',
      spokenLine: 'Há assuntos que foram ficando para trás. A herdade lembra-se disso, patrão.',
      concern: 'Assuntos adiados e tensão acumulada começam a pesar na relação com a casa.',
      recommendedTab: 'diario',
      urgency: 'normal',
      memoryHook,
    };
  }

  if (state.prestige >= 70 && relationship.respect >= 70) {
    return {
      mood: 'orgulhoso',
      headline: 'António entra com um raro sorriso',
      spokenLine: 'A casa está a ser falada com respeito. Agora é não estragar o que custou anos a levantar.',
      concern: 'Momento favorável. António recomenda consolidar antes de arriscar crescimento excessivo.',
      recommendedTab: 'campanha',
      urgency: 'baixa',
      memoryHook,
    };
  }

  return {
    mood: 'sereno',
    headline: 'António faz a ronda da manhã',
    spokenLine: 'Está tudo encaminhado por agora. Mesmo assim, convém olhar para os pequenos sinais antes que virem problemas.',
    concern: 'Rotina normal da herdade. Sem alerta crítico, mas com atenção ao mês em curso.',
    recommendedTab: 'diario',
    urgency: 'normal',
    memoryHook,
  };
}

export function applyAntonioVoiceToMeeting(state: GameState, meeting: MorningCouncilItem): MorningCouncilItem {
  if (meeting.characterId !== 'maioral') return meeting;
  const snapshot = getAntonioSnapshot(state);
  const memoryText = snapshot.memoryHook
    ? ` Lembra-se de "${snapshot.memoryHook.title}".`
    : '';

  return {
    ...meeting,
    title: meeting.title === 'Ronda da manhã' ? snapshot.headline : meeting.title,
    summary: `${snapshot.spokenLine} ${snapshot.concern}${memoryText}`,
    urgency: meeting.urgency === 'critica' || meeting.urgency === 'alta' ? meeting.urgency : snapshot.urgency,
    recommendedTab: snapshot.recommendedTab,
    availabilityNote: meeting.availabilityNote,
  };
}
