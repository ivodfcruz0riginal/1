import type { GameState } from '../store/gameTypes';
import type { Animal } from '../types/animal';
import type { CharacterMemory } from '../types/character';
import type { MorningCouncilItem, MeetingUrgency, OfficeTabKey } from '../types/meeting';
import { recentMemoriesForCharacter } from './characterService';

export type DuarteMood = 'clinico' | 'alerta' | 'prudente' | 'satisfeito' | 'contrariado';

export interface DuarteSnapshot {
  mood: DuarteMood;
  headline: string;
  spokenLine: string;
  diagnosis: string;
  recommendedTab: OfficeTabKey;
  urgency: MeetingUrgency;
  professionalOpinion: string;
  memoryHook?: CharacterMemory;
}

const HEALTH_RISK: Record<Animal['health'], number> = {
  Excelente: 0,
  Bom: 1,
  Regular: 2,
  Fraco: 4,
  Doente: 6,
};

function money(value: number): string {
  return `${Math.round(value).toLocaleString('pt-PT')}€`;
}

function healthRiskScore(animals: Animal[]): number {
  return animals
    .filter(animal => animal.status === 'Ativo')
    .reduce((sum, animal) => sum + (HEALTH_RISK[animal.health] ?? 1), 0);
}

function compromisedAnimals(animals: Animal[]): Animal[] {
  return animals.filter(animal => animal.status === 'Ativo' && ['Regular', 'Fraco', 'Doente'].includes(animal.health));
}

function oldBreedingAnimals(animals: Animal[]): Animal[] {
  return animals.filter(animal => (
    animal.status === 'Ativo'
    && ['Semental', 'Vaca'].includes(animal.category)
    && animal.ageYears >= 10
  ));
}

function getRecentMemoryHook(state: GameState): CharacterMemory | undefined {
  return recentMemoriesForCharacter(state, 'veterinario', 1)[0];
}

export function getDuarteSnapshot(state: GameState): DuarteSnapshot {
  const relationship = state.relationships.veterinario;
  const memoryHook = getRecentMemoryHook(state);
  const compromised = compromisedAnimals(state.animals);
  const oldBreeders = oldBreedingAnimals(state.animals);
  const riskScore = healthRiskScore(state.animals);
  const treasury = state.economy.treasury;

  if (compromised.some(animal => animal.health === 'Doente') || riskScore >= 18) {
    return {
      mood: 'alerta',
      headline: 'O Dr. Duarte chega com a pasta aberta',
      spokenLine: 'Patrão, isto não é assunto para deixar correr. Um problema sanitário pequeno vira prejuízo grande muito depressa.',
      diagnosis: `${compromised.length} animal(is) exigem observação clínica. O risco sanitário acumulado está alto.`,
      recommendedTab: 'diario',
      urgency: 'critica',
      professionalOpinion: 'Intervir já, mesmo com custo imediato. O risco de esperar é maior do que a despesa.',
      memoryHook,
    };
  }

  if (compromised.length >= 3) {
    return {
      mood: 'prudente',
      headline: 'O Dr. Duarte pede uma revisão preventiva',
      spokenLine: 'Não vejo alarme, mas vejo sinais. A medicina da herdade deve chegar antes da doença.',
      diagnosis: `${compromised.length} animal(is) estão abaixo do estado sanitário ideal.`,
      recommendedTab: 'diario',
      urgency: 'alta',
      professionalOpinion: 'Separar observação, rever alimentação e evitar movimentações desnecessárias esta semana.',
      memoryHook,
    };
  }

  if (treasury < 25_000) {
    return {
      mood: 'contrariado',
      headline: 'O Dr. Duarte mede as palavras antes de falar',
      spokenLine: `Eu sei que a caixa está curta — ${money(treasury)} não dá margem. Mas cortar prevenção é uma poupança falsa.`,
      diagnosis: 'Tesouraria frágil pode atrasar decisões sanitárias importantes.',
      recommendedTab: 'economia',
      urgency: 'alta',
      professionalOpinion: 'Escolher intervenções essenciais, mas não adiar o mínimo sanitário.',
      memoryHook,
    };
  }

  if (oldBreeders.length >= 4) {
    return {
      mood: 'clinico',
      headline: 'O Dr. Duarte traz notas sobre os reprodutores velhos',
      spokenLine: 'Há animais que deram muito à casa. Mas também precisam de ser vistos com outros olhos quando a idade pesa.',
      diagnosis: `${oldBreeders.length} reprodutor(es) veteranos devem ser avaliados antes da próxima campanha reprodutiva.`,
      recommendedTab: 'diario',
      urgency: 'normal',
      professionalOpinion: 'Avaliar fertilidade, aprumos e recuperação antes de insistir em cobrições ou trabalhos.',
      memoryHook,
    };
  }

  if (relationship.trust < 45 || (relationship.tension ?? 0) >= 55) {
    return {
      mood: 'contrariado',
      headline: 'O Dr. Duarte mantém distância profissional',
      spokenLine: 'Dou pareceres, patrão. A decisão é sua. Mas quando a ciência é ignorada, a herdade paga a fatura.',
      diagnosis: 'A relação técnica está tensa. Os conselhos clínicos podem começar a chegar mais tarde ou com menos insistência.',
      recommendedTab: 'pessoal',
      urgency: 'normal',
      professionalOpinion: 'Reconstruir confiança antes de surgir uma crise sanitária real.',
      memoryHook,
    };
  }

  return {
    mood: 'satisfeito',
    headline: 'O Dr. Duarte fecha o caderno sem alarme',
    spokenLine: 'Hoje não trago tragédias. O melhor trabalho veterinário é aquele que ninguém nota porque nada correu mal.',
    diagnosis: 'Estado sanitário global aceitável. Manter vigilância e prevenção.',
    recommendedTab: 'diario',
    urgency: 'baixa',
    professionalOpinion: 'Manter rotina preventiva e observar mudanças pequenas antes que sejam problemas grandes.',
    memoryHook,
  };
}

export function applyDuarteVoiceToMeeting(state: GameState, meeting: MorningCouncilItem): MorningCouncilItem {
  if (meeting.characterId !== 'veterinario') return meeting;
  const snapshot = getDuarteSnapshot(state);
  const memoryText = snapshot.memoryHook
    ? ` Lembra-se de "${snapshot.memoryHook.title}".`
    : '';

  return {
    ...meeting,
    title: meeting.title === 'Visita sanitária programada' ? snapshot.headline : meeting.title,
    summary: `${snapshot.spokenLine} ${snapshot.diagnosis} Parecer: ${snapshot.professionalOpinion}${memoryText}`,
    urgency: meeting.urgency === 'critica' || meeting.urgency === 'alta' ? meeting.urgency : snapshot.urgency,
    recommendedTab: snapshot.recommendedTab,
  };
}
