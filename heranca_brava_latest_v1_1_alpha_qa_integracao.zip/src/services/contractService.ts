import type { GameState, Month } from '../store/gameTypes';
import type { Contract, ContractProcessResult } from '../types/contract';
import { INITIAL_CONTRACTS } from '../data/contracts';

export function getInitialContracts(): Contract[] {
  return INITIAL_CONTRACTS.map(contract => ({ ...contract }));
}

export function hydrateContracts(contracts?: Contract[]): Contract[] {
  if (!contracts || contracts.length === 0) return getInitialContracts();
  const knownIds = new Set(contracts.map(c => c.id));
  const missing = getInitialContracts().filter(c => !knownIds.has(c.id));
  return [...contracts, ...missing];
}

export function canAcceptContract(contract: Contract, state: GameState): { ok: boolean; reason?: string } {
  const req = contract.requirements;
  if (!req) return { ok: true };
  if (req.minPrestige !== undefined && state.prestige < req.minPrestige) {
    return { ok: false, reason: `Prestígio mínimo: ${req.minPrestige}` };
  }
  if (req.minTreasury !== undefined && state.economy.treasury < req.minTreasury) {
    return { ok: false, reason: `Tesouraria mínima: ${req.minTreasury.toLocaleString('pt-PT')}€` };
  }
  if (req.minAnimals !== undefined && state.animals.length < req.minAnimals) {
    return { ok: false, reason: `Efetivo mínimo: ${req.minAnimals} animais` };
  }
  return { ok: true };
}

export function acceptContract(contracts: Contract[], contractId: string): Contract[] {
  return contracts.map(contract => {
    if (contract.id !== contractId || contract.status !== 'offered') return contract;
    return {
      ...contract,
      status: contract.durationMonths > 1 ? 'active' : 'completed',
      monthsRemaining: contract.durationMonths > 1 ? contract.durationMonths : 0,
    };
  });
}

export function rejectContract(contracts: Contract[], contractId: string): Contract[] {
  return contracts.map(contract =>
    contract.id === contractId && contract.status === 'offered'
      ? { ...contract, status: 'rejected' as const }
      : contract,
  );
}

export function processMonthlyContracts(contracts: Contract[], month: Month, year: number): ContractProcessResult {
  let income = 0;
  let expenses = 0;
  const events: string[] = [];

  const updated = contracts.map(contract => {
    if (contract.status !== 'active') return contract;

    const monthlyIncome = contract.monthlyIncome ?? 0;
    const monthlyExpense = contract.monthlyExpense ?? 0;
    income += monthlyIncome;
    expenses += monthlyExpense;

    if (monthlyIncome || monthlyExpense) {
      events.push(`Contrato ativo — ${contract.title}: +${monthlyIncome.toLocaleString('pt-PT')}€ / -${monthlyExpense.toLocaleString('pt-PT')}€ em ${month} ${year}.`);
    }

    const monthsRemaining = Math.max(0, contract.monthsRemaining - 1);
    if (monthsRemaining === 0) {
      const completionIncome = contract.completionIncome ?? 0;
      income += completionIncome;
      events.push(`Contrato concluído — ${contract.title}.`);
      return { ...contract, monthsRemaining, status: 'completed' as const };
    }

    return { ...contract, monthsRemaining };
  });

  return { contracts: updated, income, expenses, events };
}
