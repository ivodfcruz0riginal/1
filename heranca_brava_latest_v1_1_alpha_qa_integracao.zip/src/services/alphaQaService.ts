import type { GameState } from '../store/gameTypes';

export type AlphaQaStatus = 'aprovado' | 'afinar' | 'bloqueante';

export interface AlphaQaCheck {
  id: string;
  title: string;
  description: string;
  status: AlphaQaStatus;
  action?: string;
}

export interface AlphaQaSnapshot {
  score: number;
  status: AlphaQaStatus;
  summary: string;
  checks: AlphaQaCheck[];
}

function statusWeight(status: AlphaQaStatus): number {
  if (status === 'aprovado') return 2;
  if (status === 'afinar') return 1;
  return 0;
}

function statusFromScore(score: number): AlphaQaStatus {
  if (score >= 80) return 'aprovado';
  if (score >= 45) return 'afinar';
  return 'bloqueante';
}

function countToday(state: GameState, predicate: (type: string) => boolean): number {
  return (state.dayLog ?? []).filter(record =>
    record.dayOfMonth === state.dayOfMonth &&
    record.month === state.month &&
    record.year === state.year &&
    predicate(record.type),
  ).length;
}

function hasRecentChronicle(state: GameState): boolean {
  return (state.dayLog ?? []).some(record =>
    record.type === 'day_closed' ||
    record.title.toLowerCase().includes('crónica') ||
    record.description.toLowerCase().includes('amanhã'),
  );
}

export function createAlphaQaSnapshot(state: GameState): AlphaQaSnapshot {
  const pendingCouncil = (state.morningCouncil ?? []).filter(item => item.status === 'pending');
  const attendedCouncil = (state.morningCouncil ?? []).filter(item => item.status === 'attended');
  const postponedCouncil = (state.morningCouncil ?? []).filter(item => item.status === 'postponed');
  const locationVisitsToday = countToday(state, type => type === 'location_visit');
  const locationEventsToday = countToday(state, type => type === 'location_event');
  const worldEventsToday = countToday(state, type => type === 'world_event');
  const routineEventsToday = countToday(state, type => type === 'routine');
  const memories = state.characterMemories ?? [];
  const activeThreads = pendingCouncil.length + postponedCouncil.length + (state.activeLocationEvent ? 1 : 0);

  const checks: AlphaQaCheck[] = [
    {
      id: 'conselho',
      title: 'Conselho da Manhã',
      description: pendingCouncil.length + attendedCouncil.length + postponedCouncil.length > 0
        ? `${pendingCouncil.length} pendente(s), ${attendedCouncil.length} atendido(s), ${postponedCouncil.length} adiado(s).`
        : 'Não há assuntos de Conselho para orientar o dia.',
      status: pendingCouncil.length + attendedCouncil.length + postponedCouncil.length > 0 ? 'aprovado' : 'bloqueante',
      action: pendingCouncil.length + attendedCouncil.length + postponedCouncil.length > 0 ? undefined : 'Gerar pelo menos um assunto claro no início do dia.',
    },
    {
      id: 'quadro',
      title: 'Conselho → Quadro',
      description: state.activeLocationEvent
        ? `Existe um acontecimento ativo em ${state.activeLocationEvent.locationId}.`
        : locationVisitsToday > 0
          ? `${locationVisitsToday} deslocação(ões) registada(s) hoje.`
          : 'Ainda não há ligação visível entre o Conselho e um local da herdade.',
      status: state.activeLocationEvent || locationEventsToday > 0 ? 'aprovado' : locationVisitsToday > 0 ? 'afinar' : 'bloqueante',
      action: state.activeLocationEvent || locationEventsToday > 0 ? undefined : 'Encaminhar o assunto principal para um local com evento contextual.',
    },
    {
      id: 'diario',
      title: 'Diário do Dia',
      description: state.dayLog?.length
        ? `${state.dayLog.length} registo(s) no diário operacional.`
        : 'O Diário ainda não recebeu registos do dia.',
      status: state.dayLog?.length ? 'aprovado' : 'bloqueante',
      action: state.dayLog?.length ? undefined : 'Registar Conselho, visita, decisão ou rotina no Diário.',
    },
    {
      id: 'memoria',
      title: 'Memória das Personagens',
      description: memories.length > 0
        ? `${memories.length} memória(s) guardada(s) nas personagens.`
        : 'Ainda não existem memórias persistentes criadas pela campanha.',
      status: memories.length >= 3 ? 'aprovado' : memories.length > 0 ? 'afinar' : 'bloqueante',
      action: memories.length >= 3 ? undefined : 'Garantir que atender, adiar e resolver quadros geram memórias úteis.',
    },
    {
      id: 'mundo',
      title: 'Herdade Viva',
      description: worldEventsToday + routineEventsToday > 0
        ? `${worldEventsToday} acontecimento(s) autónomo(s) e ${routineEventsToday} rotina(s) registados hoje.`
        : 'A herdade ainda não mostrou vida autónoma neste dia.',
      status: worldEventsToday + routineEventsToday > 0 ? 'aprovado' : state.dayPeriod === 'manha' ? 'afinar' : 'bloqueante',
      action: worldEventsToday + routineEventsToday > 0 ? undefined : 'Avançar período deve gerar rotina ou acontecimento de baixa intensidade.',
    },
    {
      id: 'cronicas',
      title: 'Diário → Crónicas',
      description: hasRecentChronicle(state)
        ? 'Há pelo menos uma crónica/fecho de dia que pode alimentar o Livro da Casa.'
        : 'Ainda falta fechar o dia para transformar eventos em memória da casa.',
      status: hasRecentChronicle(state) ? 'aprovado' : activeThreads > 0 ? 'afinar' : 'bloqueante',
      action: hasRecentChronicle(state) ? undefined : 'Fechar o dia deve gerar uma crónica integrada com assuntos resolvidos e pendentes.',
    },
  ];

  const raw = checks.reduce((sum, check) => sum + statusWeight(check.status), 0);
  const score = Math.round((raw / (checks.length * 2)) * 100);
  const status = statusFromScore(score);
  const summary = status === 'aprovado'
    ? 'O First Play está integrado: há assunto, deslocação, registo, memória e continuidade.'
    : status === 'afinar'
      ? 'O First Play funciona parcialmente, mas ainda há elos que precisam de maior clareza.'
      : 'A cadeia principal ainda falha: o jogador pode perder o fio entre Conselho, Quadro e Diário.';

  return { score, status, summary, checks };
}
