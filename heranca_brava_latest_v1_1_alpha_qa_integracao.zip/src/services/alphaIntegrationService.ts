import type { GameState } from '../store/gameTypes';
import type { LocationId } from '../types/location';

export interface AlphaStoryThread {
  id: string;
  title: string;
  description: string;
  locationId?: LocationId | null;
  weight: number;
  source: 'conselho' | 'quadro' | 'memoria' | 'mundo' | 'diario';
}

export interface AlphaNextStep {
  title: string;
  description: string;
  locationId?: LocationId | null;
  urgency: 'baixa' | 'normal' | 'alta' | 'critica';
}

function locationName(state: GameState, locationId?: LocationId | null): string {
  if (!locationId) return 'Escritório';
  return state.locations.find(location => location.id === locationId)?.name ?? locationId;
}

function urgencyWeight(urgency: string): number {
  switch (urgency) {
    case 'critica': return 5;
    case 'alta': return 4;
    case 'normal': return 3;
    default: return 2;
  }
}

export function getAlphaStoryThreads(state: GameState, limit = 5): AlphaStoryThread[] {
  const councilThreads: AlphaStoryThread[] = (state.morningCouncil ?? [])
    .filter(item => item.status === 'pending' || item.status === 'postponed')
    .map(item => ({
      id: `council-${item.id}`,
      title: `${item.characterName}: ${item.title}`,
      description: item.status === 'postponed'
        ? `Ficou adiado. O assunto continua ligado a ${locationName(state, item.locationId)}.`
        : item.summary,
      locationId: item.locationId,
      weight: urgencyWeight(item.urgency) + (item.status === 'postponed' ? 1 : 0),
      source: 'conselho',
    }));

  const activeEventThreads: AlphaStoryThread[] = state.activeLocationEvent ? [{
    id: `active-event-${state.activeLocationEvent.instanceId}`,
    title: state.activeLocationEvent.title,
    description: `${state.activeLocationEvent.characterName} acompanha a situação em ${locationName(state, state.activeLocationEvent.locationId)}.`,
    locationId: state.activeLocationEvent.locationId,
    weight: urgencyWeight(state.activeLocationEvent.severity),
    source: 'quadro',
  }] : [];

  const memoryThreads: AlphaStoryThread[] = (state.characterMemories ?? [])
    .filter(memory => memory.weight >= 3)
    .slice(0, 12)
    .map(memory => ({
      id: `memory-${memory.id}`,
      title: memory.title,
      description: `${memory.description} ${memory.locationId ? `Ligado a ${locationName(state, memory.locationId)}.` : ''}`,
      locationId: memory.locationId,
      weight: memory.weight,
      source: 'memoria',
    }));

  const worldThreads: AlphaStoryThread[] = (state.dayLog ?? [])
    .filter(record => record.type === 'world_event' || record.type === 'location_event')
    .slice(0, 12)
    .map(record => ({
      id: `day-${record.id}`,
      title: record.title,
      description: record.description,
      locationId: record.locationId,
      weight: record.type === 'location_event' ? 4 : 2,
      source: record.type === 'location_event' ? 'quadro' : 'mundo',
    }));

  const all = [...activeEventThreads, ...councilThreads, ...memoryThreads, ...worldThreads];
  const seen = new Set<string>();
  return all
    .filter(thread => {
      const key = `${thread.title}-${thread.locationId ?? 'sem-local'}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    })
    .sort((a, b) => b.weight - a.weight)
    .slice(0, limit);
}

export function getAlphaNextStep(state: GameState): AlphaNextStep {
  const pendingCritical = (state.morningCouncil ?? [])
    .filter(item => item.status === 'pending')
    .sort((a, b) => urgencyWeight(b.urgency) - urgencyWeight(a.urgency))[0];

  if (pendingCritical) {
    return {
      title: `Ouvir ${pendingCritical.characterName}`,
      description: `${pendingCritical.title}. Se for atendido, o dia ganha um destino claro: ${locationName(state, pendingCritical.locationId)}.`,
      locationId: pendingCritical.locationId,
      urgency: pendingCritical.urgency,
    };
  }

  if (state.activeLocationEvent) {
    return {
      title: `Resolver situação em ${locationName(state, state.activeLocationEvent.locationId)}`,
      description: state.activeLocationEvent.description,
      locationId: state.activeLocationEvent.locationId,
      urgency: state.activeLocationEvent.severity === 'media' ? 'normal' : state.activeLocationEvent.severity,
    };
  }

  const postponed = (state.morningCouncil ?? []).find(item => item.status === 'postponed');
  if (postponed) {
    return {
      title: `Retomar assunto adiado`,
      description: `${postponed.characterName} ficou à espera: ${postponed.title}.`,
      locationId: postponed.locationId,
      urgency: 'alta',
    };
  }

  const recentThread = getAlphaStoryThreads(state, 1)[0];
  if (recentThread) {
    return {
      title: `Acompanhar: ${recentThread.title}`,
      description: recentThread.description,
      locationId: recentThread.locationId,
      urgency: recentThread.weight >= 4 ? 'alta' : 'normal',
    };
  }

  return {
    title: 'Observar a herdade',
    description: 'Não há uma urgência clara. Um bom ganadeiro também sabe usar os dias calmos para observar cercados, água e pessoal.',
    locationId: 'escritorio',
    urgency: 'baixa',
  };
}

export function createAlphaDayChronicle(state: GameState): string {
  const attended = (state.morningCouncil ?? []).filter(item => item.status === 'attended');
  const postponed = (state.morningCouncil ?? []).filter(item => item.status === 'postponed' || item.status === 'pending');
  const locationEvents = (state.dayLog ?? [])
    .filter(record => record.dayOfMonth === state.dayOfMonth && record.type === 'location_event')
    .slice(0, 3);
  const worldEvents = (state.dayLog ?? [])
    .filter(record => record.dayOfMonth === state.dayOfMonth && record.type === 'world_event')
    .slice(0, 2);

  const heard = attended.length > 0
    ? `No Conselho foram ouvidos ${attended.map(item => item.characterName).join(', ')}.`
    : 'O Conselho da Manhã não teve decisões de peso.';

  const unresolved = postponed.length > 0
    ? `Ficaram por fechar: ${postponed.map(item => `${item.characterName} — ${item.title}`).join('; ')}.`
    : 'Não ficaram assuntos principais por atender.';

  const field = locationEvents.length > 0
    ? `Nos quadros da herdade: ${locationEvents.map(record => record.title).join('; ')}.`
    : 'Nenhum quadro da herdade exigiu uma decisão definitiva.';

  const world = worldEvents.length > 0
    ? `Mesmo assim, a casa continuou a mexer: ${worldEvents.map(record => record.title).join('; ')}.`
    : 'A rotina da casa decorreu sem sobressaltos maiores.';

  const next = getAlphaNextStep(state);

  return `${heard} ${field} ${world} ${unresolved} Amanhã, o fio mais forte parece ser: ${next.title}.`;
}
