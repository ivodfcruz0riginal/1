import type { GameState } from '../store/gameTypes';
import {
  SAVE_STORAGE_KEY,
  SAVE_VERSION,
  type CampaignSave,
  type SaveSummary,
} from '../types/save';

function hasStorage(): boolean {
  return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';
}

export function createCampaignSave(state: GameState): CampaignSave {
  return {
    version: SAVE_VERSION,
    savedAt: new Date().toISOString(),
    state,
  };
}

export function saveCampaign(state: GameState): CampaignSave {
  const save = createCampaignSave(state);
  if (!hasStorage()) return save;
  window.localStorage.setItem(SAVE_STORAGE_KEY, JSON.stringify(save));
  return save;
}

export function loadCampaign(): CampaignSave | null {
  if (!hasStorage()) return null;
  const raw = window.localStorage.getItem(SAVE_STORAGE_KEY);
  if (!raw) return null;

  try {
    const parsed = JSON.parse(raw) as CampaignSave;
    if (!parsed || parsed.version !== SAVE_VERSION || !parsed.state) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function deleteCampaignSave(): void {
  if (!hasStorage()) return;
  window.localStorage.removeItem(SAVE_STORAGE_KEY);
}

export function getSaveSummary(): SaveSummary {
  const save = loadCampaign();
  if (!save) return { exists: false };

  return {
    exists: true,
    version: save.version,
    savedAt: save.savedAt,
    year: save.state.year,
    month: save.state.month,
    treasury: save.state.economy.treasury,
    prestige: save.state.prestige,
    animals: save.state.animals.length,
  };
}
