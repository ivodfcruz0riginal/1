import type { GameEvent, GameState } from '../store/gameTypes';
import type { NarrativeChoice, NarrativeEffect, NarrativeHistoryRecord } from '../types/narrative';
import type { LocationId } from '../types/location';
import { findNarrativeEvent } from '../data/narrativeEvents';

function clamp(value: number, min = 0, max = 100): number {
  return Math.max(min, Math.min(max, value));
}

export function applyNarrativeChoice(
  state: GameState,
  dialogueId: string,
  choiceLabel: string,
  makeEventId: () => string,
  locationId?: LocationId | null,
): {
  state: GameState;
  resultText: string | null;
  appliedEffects: NarrativeEffect[];
} {
  const narrativeEvent = findNarrativeEvent(dialogueId);
  const narrativeChoice: NarrativeChoice | undefined = narrativeEvent?.choices.find(
    choice => choice.label === choiceLabel,
  );

  if (!narrativeEvent || !narrativeChoice) {
    return { state, resultText: null, appliedEffects: [] };
  }

  let nextState: GameState = state;
  const extraEvents: GameEvent[] = [];

  narrativeChoice.effects.forEach(effect => {
    switch (effect.target) {
      case 'treasury': {
        const delta = effect.value ?? 0;
        nextState = {
          ...nextState,
          economy: {
            ...nextState.economy,
            treasury: nextState.economy.treasury + delta,
          },
        };
        if (effect.message) {
          extraEvents.push({ id: makeEventId(), month: state.month, year: state.year, text: `${effect.message} (${delta >= 0 ? '+' : ''}${delta.toLocaleString('pt-PT')}€)`, locationId: locationId ?? null });
        }
        break;
      }
      case 'relationship': {
        if (!effect.characterId) break;
        const current = nextState.relationships[effect.characterId];
        const delta = effect.value ?? 0;
        nextState = {
          ...nextState,
          relationships: {
            ...nextState.relationships,
            [effect.characterId]: {
              ...current,
              trust: clamp(current.trust + delta),
              respect: clamp(current.respect + Math.round(delta / 2)),
            },
          },
        };
        break;
      }
      case 'animalHealth': {
        const delta = effect.value ?? 0;
        let applied = false;
        nextState = {
          ...nextState,
          animals: nextState.animals.map(animal => {
            if (applied) return animal;
            if (effect.animalCategory && animal.category !== effect.animalCategory) return animal;
            applied = true;
            const healthOrder = ['Doente', 'Fraco', 'Regular', 'Bom', 'Excelente'] as const;
            const currentIndex = healthOrder.indexOf(animal.health);
            const step = delta >= 5 ? 1 : delta <= -4 ? -1 : 0;
            const nextIndex = clamp(currentIndex + step, 0, healthOrder.length - 1);
            return { ...animal, health: healthOrder[nextIndex] };
          }),
        };
        break;
      }
      case 'prestige': {
        const delta = effect.value ?? 0;
        nextState = {
          ...nextState,
          prestige: clamp(nextState.prestige + delta),
        };
        break;
      }
      case 'eventLog': {
        if (effect.message) {
          extraEvents.push({ id: makeEventId(), month: state.month, year: state.year, text: effect.message, locationId: locationId ?? null });
        }
        break;
      }
    }
  });

  const historyRecord: NarrativeHistoryRecord = {
    id: `narr-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    dialogueId,
    characterId: narrativeEvent.characterId,
    choice: choiceLabel,
    resultText: narrativeChoice.resultText,
    month: state.month,
    year: state.year,
    appliedEffects: narrativeChoice.effects,
    locationId: locationId ?? null,
  };

  return {
    state: {
      ...nextState,
      eventLog: [...extraEvents, ...nextState.eventLog].slice(0, 30),
      narrativeHistory: [historyRecord, ...nextState.narrativeHistory].slice(0, 50),
    },
    resultText: narrativeChoice.resultText,
    appliedEffects: narrativeChoice.effects,
    locationId: locationId ?? null,
  };
}
