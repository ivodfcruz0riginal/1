import type { GameState, Month, Season } from '../store/gameTypes';
import type { DayPeriod } from '../types/day';
import type { LocationCondition, LocationId, LocationNotification } from '../types/location';
import type { NarrativeCharacterId } from '../types/narrative';
import { describeVisibleRoutines } from './routineService';

export interface WorldEvent {
  id: string;
  title: string;
  description: string;
  locationId: LocationId;
  characterId?: NarrativeCharacterId;
  notification?: LocationNotification;
  condition?: LocationCondition;
  treasury?: number;
  prestige?: number;
  memoryWeight?: number;
}

export interface WorldSimulationResult {
  events: WorldEvent[];
  routineLines: string[];
}

function makeWorldEvent(
  state: Pick<GameState, 'year' | 'month' | 'dayOfMonth'>,
  period: DayPeriod,
  suffix: string,
  event: Omit<WorldEvent, 'id'>,
): WorldEvent {
  return {
    id: `world-${state.year}-${state.month}-${state.dayOfMonth}-${period}-${suffix}`,
    ...event,
  };
}

function isSummer(month: Month, season: Season): boolean {
  return season === 'Verão' || month === 'Junho' || month === 'Julho' || month === 'Agosto';
}

function isWinter(month: Month, season: Season): boolean {
  return season === 'Inverno' || month === 'Dezembro' || month === 'Janeiro' || month === 'Fevereiro';
}

export function simulateWorldStep(state: GameState, nextPeriod: DayPeriod): WorldSimulationResult {
  const events: WorldEvent[] = [];
  const routineLines = describeVisibleRoutines({ dayPeriod: nextPeriod });
  const north = state.locations.find(location => location.id === 'cercado_norte');
  const south = state.locations.find(location => location.id === 'cercado_sul');
  const barragem = state.locations.find(location => location.id === 'barragem');
  const oficina = state.locations.find(location => location.id === 'oficina');

  if (nextPeriod === 'meio_dia') {
    if (north?.notifications.includes('BrokenFence')) {
      events.push(makeWorldEvent(state, nextPeriod, 'cerca-norte', {
        title: 'Vedação revista no Cercado Norte',
        description: 'Joaquim passou pela linha da vedação. A reparação ainda não está concluída, mas a zona ficou sinalizada para evitar pressão do lote.',
        locationId: 'cercado_norte',
        characterId: 'campino',
        notification: 'WaitingInspection',
        memoryWeight: 2,
      }));
    } else if (north && north.currentOccupation > Math.floor(north.capacity * 0.55)) {
      events.push(makeWorldEvent(state, nextPeriod, 'lote-observado', {
        title: 'Lote observado à distância',
        description: 'António passou pelo Cercado Norte. Um macho ficou algum tempo afastado, mas voltou ao grupo sem sinais claros de lesão.',
        locationId: 'cercado_norte',
        characterId: 'maioral',
        notification: 'AnimalAttention',
        memoryWeight: 3,
      }));
    }
  }

  if (nextPeriod === 'tarde') {
    if (isSummer(state.month, state.season) && barragem) {
      events.push(makeWorldEvent(state, nextPeriod, 'agua-verao', {
        title: 'Água sob observação',
        description: 'Joaquim confirmou o nível da barragem. Ainda há margem, mas os cercados secos vão exigir atenção nos próximos dias.',
        locationId: 'barragem',
        characterId: 'campino',
        notification: 'WaitingInspection',
        memoryWeight: 2,
      }));
    } else if (south?.condition === 'Good' && south.currentOccupation > 0) {
      events.push(makeWorldEvent(state, nextPeriod, 'cercado-sul-calmo', {
        title: 'Cercado Sul em rotina calma',
        description: 'O lote do Cercado Sul manteve-se junto às sombras ao fim da tarde. Não houve necessidade de recolha nem intervenção.',
        locationId: 'cercado_sul',
        characterId: 'maioral',
        memoryWeight: 1,
      }));
    }
  }

  if (nextPeriod === 'noite') {
    if (oficina?.condition === 'Poor') {
      events.push(makeWorldEvent(state, nextPeriod, 'oficina-pendente', {
        title: 'Material ficou por arrumar',
        description: 'A oficina voltou a fechar com material fora do lugar. Não impede o trabalho de amanhã, mas aumenta o risco de pequenas avarias.',
        locationId: 'oficina',
        characterId: 'campino',
        notification: 'NeedsCleaning',
        memoryWeight: 1,
      }));
    }

    if (isWinter(state.month, state.season)) {
      events.push(makeWorldEvent(state, nextPeriod, 'noite-inverno', {
        title: 'Noite pesada na herdade',
        description: 'A lama junto aos currais tornou o fecho do dia mais lento. António deixou nota para verificar os acessos de manhã.',
        locationId: 'currais',
        characterId: 'maioral',
        notification: 'WaitingInspection',
        memoryWeight: 2,
      }));
    }
  }

  return { events: events.slice(0, 2), routineLines: routineLines.slice(0, 3) };
}
