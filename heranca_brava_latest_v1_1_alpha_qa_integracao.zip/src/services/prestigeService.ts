import type { GameState } from '../store/gameTypes';
import type { Animal } from '../types/animal';
import type { NarrativeEffect } from '../types/narrative';
import { averageStaffScore } from './staffService';

export type PrestigeTier = 'Desconhecida' | 'Regional' | 'Nacional' | 'Internacional' | 'Lendária';

export interface PrestigeBreakdownItem {
  id: string;
  label: string;
  value: number;
  max: number;
  description: string;
}

export interface PrestigeSnapshot {
  score: number;
  tier: PrestigeTier;
  trend: number;
  breakdown: PrestigeBreakdownItem[];
  drivers: string[];
}

const HEALTH_SCORE: Record<Animal['health'], number> = {
  Doente: 20,
  Fraco: 40,
  Regular: 60,
  Bom: 80,
  Excelente: 100,
};

function clamp(value: number, min = 0, max = 100): number {
  return Math.max(min, Math.min(max, value));
}

function average(values: number[]): number {
  if (values.length === 0) return 0;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function scoreAnimalQuality(animals: Animal[]): number {
  const active = animals.filter(animal => animal.status === 'Ativo');
  if (active.length === 0) return 0;

  const eliteCandidates = active
    .filter(animal => animal.category !== 'Cabresto')
    .map(animal => (animal.bravery + animal.nobility + animal.mobility + animal.stamina + animal.transmission) / 5)
    .sort((a, b) => b - a)
    .slice(0, 12);

  return average(eliteCandidates);
}

function scoreAnimalHealth(animals: Animal[]): number {
  const active = animals.filter(animal => animal.status === 'Ativo');
  return average(active.map(animal => HEALTH_SCORE[animal.health] ?? 50));
}

function scoreEconomy(state: GameState): number {
  const treasuryScore = clamp((state.economy.treasury / 200_000) * 100, 0, 100);
  const recent = state.economy.history.slice(0, 6);
  const profitScore = recent.length === 0
    ? 50
    : clamp(50 + (average(recent.map(record => record.profit)) / 20_000) * 50, 0, 100);

  return Math.round((treasuryScore * 0.55) + (profitScore * 0.45));
}

function scoreRelationships(state: GameState): number {
  const relationships = Object.values(state.relationships);
  if (relationships.length === 0) return 50;

  return average(relationships.map(rel => (rel.trust + rel.respect + rel.loyalty - rel.fatigue * 0.35) / 2.65));
}

function effectPrestigeValue(effect: NarrativeEffect): number {
  if (effect.target !== 'prestige') return 0;
  return effect.value ?? 0;
}

function scoreNarrativeReputation(state: GameState): number {
  const recentNarrative = state.narrativeHistory.slice(0, 12);
  const narrativeDelta = recentNarrative.reduce((sum, record) => (
    sum + record.appliedEffects.reduce((inner, effect) => inner + effectPrestigeValue(effect), 0)
  ), 0);

  const positivePublicEvents = state.eventLog.slice(0, 20).filter(event => (
    /prémio|indulto|convite|festival|visibilidade|excelente|parceria|reportagem/i.test(event.text)
  )).length;
  const negativePublicEvents = state.eventLog.slice(0, 20).filter(event => (
    /doença|seca|danos|problemas|lesão|incêndio|urgente/i.test(event.text)
  )).length;

  return clamp(50 + narrativeDelta * 4 + positivePublicEvents * 3 - negativePublicEvents * 4, 0, 100);
}

function computeTrend(state: GameState, currentScore: number): number {
  const recentPrestigeEffects = state.narrativeHistory.slice(0, 6).reduce((sum, record) => (
    sum + record.appliedEffects.reduce((inner, effect) => inner + effectPrestigeValue(effect), 0)
  ), 0);
  const latestProfit = state.economy.history[0]?.profit ?? 0;
  const profitTrend = latestProfit > 0 ? 1 : latestProfit < -10_000 ? -2 : 0;
  const healthTrend = scoreAnimalHealth(state.animals) >= 75 ? 1 : -1;

  return clamp(Math.round(recentPrestigeEffects + profitTrend + healthTrend), -10, 10);
}

export function prestigeTier(score: number): PrestigeTier {
  if (score >= 90) return 'Lendária';
  if (score >= 75) return 'Internacional';
  if (score >= 55) return 'Nacional';
  if (score >= 30) return 'Regional';
  return 'Desconhecida';
}

export function calculatePrestigeSnapshot(state: GameState): PrestigeSnapshot {
  const animalQuality = scoreAnimalQuality(state.animals);
  const animalHealth = scoreAnimalHealth(state.animals);
  const economy = scoreEconomy(state);
  const relationships = scoreRelationships(state);
  const staff = averageStaffScore(state.staff ?? []);
  const narrative = scoreNarrativeReputation(state);

  const breakdown: PrestigeBreakdownItem[] = [
    {
      id: 'animal-quality',
      label: 'Qualidade do efetivo',
      value: Math.round(animalQuality),
      max: 100,
      description: 'Média dos melhores animais ativos, excluindo cabrestos.',
    },
    {
      id: 'animal-health',
      label: 'Saúde e apresentação',
      value: Math.round(animalHealth),
      max: 100,
      description: 'Estado sanitário médio dos animais ativos.',
    },
    {
      id: 'economy',
      label: 'Solidez económica',
      value: Math.round(economy),
      max: 100,
      description: 'Tesouraria e resultados recentes da casa.',
    },
    {
      id: 'relationships',
      label: 'Confiança da casa',
      value: Math.round(relationships),
      max: 100,
      description: 'Confiança, respeito e lealdade das personagens.',
    },
    {
      id: 'staff',
      label: 'Equipa da casa',
      value: Math.round(staff),
      max: 100,
      description: 'Competência, moral, lealdade e cansaço do pessoal.',
    },
    {
      id: 'narrative',
      label: 'Reputação pública',
      value: Math.round(narrative),
      max: 100,
      description: 'Eventos, escolhas narrativas e exposição pública recente.',
    },
  ];

  const score = clamp(Math.round(
    animalQuality * 0.32
    + animalHealth * 0.16
    + economy * 0.16
    + relationships * 0.10
    + staff * 0.12
    + narrative * 0.20,
  ));

  const strongest = [...breakdown].sort((a, b) => b.value - a.value)[0];
  const weakest = [...breakdown].sort((a, b) => a.value - b.value)[0];
  const drivers = [
    strongest ? `Ponto forte: ${strongest.label.toLowerCase()} (${strongest.value}/100).` : 'Sem ponto forte definido.',
    weakest ? `Atenção: ${weakest.label.toLowerCase()} (${weakest.value}/100).` : 'Sem alerta definido.',
    state.narrativeHistory.length > 0
      ? `Última decisão relevante: ${state.narrativeHistory[0].resultText}`
      : 'Ainda não existem decisões narrativas suficientes para formar reputação pública.',
  ];

  return {
    score,
    tier: prestigeTier(score),
    trend: computeTrend(state, score),
    breakdown,
    drivers,
  };
}
