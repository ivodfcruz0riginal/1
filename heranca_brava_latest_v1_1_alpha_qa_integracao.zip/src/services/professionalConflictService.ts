import type { GameState } from '../store/gameTypes';
import type { MorningCouncilItem, MeetingUrgency, OfficeTabKey } from '../types/meeting';
import type { NarrativeCharacterId } from '../types/narrative';
import { getAntonioSnapshot } from './antonioService';
import { getDuarteSnapshot } from './duarteService';
import { relationshipTone, recentMemoriesForCharacter } from './characterService';

function monthKey(state: Pick<GameState, 'month' | 'year'>): string {
  return `${state.year}-${state.month}`;
}

function urgencyRank(urgency: MeetingUrgency): number {
  switch (urgency) {
    case 'critica': return 4;
    case 'alta': return 3;
    case 'normal': return 2;
    case 'baixa': return 1;
    default: return 0;
  }
}

function highestUrgency(a: MeetingUrgency, b: MeetingUrgency): MeetingUrgency {
  return urgencyRank(a) >= urgencyRank(b) ? a : b;
}

function compromisedAnimalCount(state: GameState): number {
  return state.animals.filter(animal => (
    animal.status === 'Ativo'
    && ['Regular', 'Fraco', 'Doente'].includes(animal.health)
  )).length;
}

function tiredStaffCount(state: GameState): number {
  return (state.staff ?? []).filter(member => member.fatigue >= 70 || member.morale <= 42).length;
}

function hasSanitaryPressure(state: GameState): boolean {
  return compromisedAnimalCount(state) > 0 || state.animals.some(animal => animal.status === 'Ativo' && animal.health === 'Doente');
}

function shouldCreateAntonioDuarteConflict(state: GameState): boolean {
  const duarte = getDuarteSnapshot(state);
  const antonio = getAntonioSnapshot(state);
  const treasuryPressure = state.economy.treasury < 45_000;
  const sanitaryPressure = hasSanitaryPressure(state);
  const teamPressure = tiredStaffCount(state) > 0;
  const relationshipTension = (state.relationships.maioral?.tension ?? 0) >= 45 || (state.relationships.veterinario?.tension ?? 0) >= 45;

  return (
    sanitaryPressure
    && (treasuryPressure || teamPressure || relationshipTension || urgencyRank(duarte.urgency) >= urgencyRank('alta') || urgencyRank(antonio.urgency) >= urgencyRank('alta'))
  );
}

export function createAntonioDuarteConflictMeeting(state: GameState): MorningCouncilItem | null {
  if (!shouldCreateAntonioDuarteConflict(state)) return null;

  const antonio = getAntonioSnapshot(state);
  const duarte = getDuarteSnapshot(state);
  const count = compromisedAnimalCount(state);
  const antonioMemory = recentMemoriesForCharacter(state, 'maioral', 1)[0];
  const duarteMemory = recentMemoriesForCharacter(state, 'veterinario', 1)[0];
  const urgency = highestUrgency(duarte.urgency, antonio.urgency);
  const recommendedTab: OfficeTabKey = duarte.recommendedTab === 'economia' || antonio.recommendedTab === 'economia'
    ? 'economia'
    : 'diario';

  const antonioLine = state.economy.treasury < 35_000
    ? 'Patrão, eu não deixo um animal a sofrer, mas também não podemos abrir a torneira quando a casa está curta. Primeiro separava-se e observava-se com cabeça.'
    : 'Patrão, eu punha o lote quieto, via o comportamento mais um dia e só apertava a mão se houver sinal claro. Gado bravo também se estraga com maneio a mais.';

  const duarteLine = `${duarte.spokenLine} ${duarte.professionalOpinion}`;
  const stakes = count > 0
    ? `${count} animal(is) com sinais sanitários ou físicos por acompanhar. A decisão mexe com risco clínico, custos e confiança técnica.`
    : 'Há sinais de risco clínico baixo, mas a decisão cria precedente entre tradição e prevenção.';

  return {
    id: `council-${monthKey(state)}-conflito-antonio-duarte`,
    monthKey: monthKey(state),
    characterId: 'maioral',
    characterName: 'António e Dr. Duarte',
    role: 'Conflito técnico',
    title: 'Tradição ou prevenção sanitária',
    summary: `O maioral e o veterinário não leem o risco da mesma maneira. ${relationshipTone(state, 'maioral')} ${relationshipTone(state, 'veterinario')}`,
    urgency,
    locationId: 'escritorio',
    recommendedTab,
    status: 'pending',
    professionalConflict: {
      id: `conflict-${monthKey(state)}-antonio-duarte`,
      type: 'sanidade_vs_maneio',
      primaryCharacterId: 'maioral' as NarrativeCharacterId,
      primaryCharacterName: 'António',
      secondaryCharacterId: 'veterinario' as NarrativeCharacterId,
      secondaryCharacterName: 'Dr. Duarte',
      primaryLine: antonioLine,
      secondaryLine: duarteLine,
      stakes,
      primaryChoiceLabel: 'Confiar no António',
      secondaryChoiceLabel: 'Seguir o Dr. Duarte',
      memoryHint: [antonioMemory?.title, duarteMemory?.title].filter(Boolean).join(' · ') || undefined,
    },
  };
}
