import type { GameState } from '../store/gameTypes';
import type { MorningCouncilItem, MeetingUrgency, OfficeTabKey } from '../types/meeting';
import type { NarrativeCharacterId } from '../types/narrative';
import { getCharacterAgendaStatus, relationshipTone } from './characterService';
import { buildMemoryLineForCharacter, getPendingFollowUpMemories } from './characterMemoryService';
import { applyAntonioVoiceToMeeting } from './antonioService';
import { applyDuarteVoiceToMeeting, getDuarteSnapshot } from './duarteService';
import { createAntonioDuarteConflictMeeting } from './professionalConflictService';
import { applyBeatrizVoiceToMeeting } from './beatrizService';
import { createBeatrizEmpresarioConflictMeeting } from './financialConflictService';

function monthKey(state: Pick<GameState, 'month' | 'year'> & Partial<Pick<GameState, 'dayOfMonth'>>): string {
  return `${state.year}-${state.month}-dia-${state.dayOfMonth ?? 1}`;
}

function urgencyRank(urgency: MeetingUrgency): number {
  switch (urgency) {
    case 'critica': return 4;
    case 'alta': return 3;
    case 'normal': return 2;
    case 'baixa': return 1;
    default: return 0;
  }
}

function inferMeetingLocation(dialogueId: string | undefined, recommendedTab: OfficeTabKey): GameState['activeLocationId'] {
  if (dialogueId?.startsWith('loc_currais')) return 'currais';
  if (dialogueId?.startsWith('loc_cercado_norte')) return 'cercado_norte';
  if (dialogueId?.startsWith('loc_cercado_sul')) return 'cercado_sul';
  if (dialogueId?.startsWith('loc_tentadero')) return 'tentadero';
  if (dialogueId?.startsWith('loc_embarque')) return 'embarque';
  if (recommendedTab === 'contratos' || recommendedTab === 'economia' || recommendedTab === 'campanha' || recommendedTab === 'prestigio') return 'escritorio';
  return 'escritorio';
}

function makeMeeting(
  state: GameState,
  suffix: string,
  characterId: NarrativeCharacterId,
  characterName: string,
  role: string,
  title: string,
  summary: string,
  urgency: MeetingUrgency,
  recommendedTab: OfficeTabKey,
  dialogueId?: string,
  availabilityNote?: string,
  substituteFor?: NarrativeCharacterId,
): MorningCouncilItem {
  const key = monthKey(state);
  const meetingLocation = inferMeetingLocation(dialogueId, recommendedTab) ?? 'escritorio';
  const memoryLine = buildMemoryLineForCharacter(state, characterId, meetingLocation);
  const toneLine = relationshipTone(state, characterId);
  return {
    id: `council-${key}-${suffix}`,
    monthKey: key,
    characterId,
    characterName,
    role,
    title,
    summary: `${summary} ${toneLine}${memoryLine ? ` ${memoryLine}` : ''}`,
    urgency,
    locationId: meetingLocation,
    dialogueId,
    recommendedTab,
    status: 'pending',
    availabilityNote,
    substituteFor,
  };
}


function resolveOfficeCharacter(state: GameState, preferred: NarrativeCharacterId): { characterId: NarrativeCharacterId; note?: string; substituteFor?: NarrativeCharacterId } {
  const agenda = getCharacterAgendaStatus(state, preferred);
  if (agenda.availability === 'available') return { characterId: preferred, note: agenda.note };
  if (agenda.substituteCharacterId) {
    const subAgenda = getCharacterAgendaStatus(state, agenda.substituteCharacterId);
    return {
      characterId: agenda.substituteCharacterId,
      note: `${agenda.note} ${subAgenda.characterId !== preferred ? 'O assunto chega por substituição.' : ''}`,
      substituteFor: preferred,
    };
  }
  return { characterId: preferred, note: agenda.note };
}

const CHARACTER_LABELS: Record<NarrativeCharacterId, { name: string; role: string }> = {
  maioral: { name: 'António', role: 'Maioral' },
  veterinario: { name: 'Dr. Duarte', role: 'Veterinário' },
  administrador: { name: 'D. Beatriz', role: 'Administração' },
  campino: { name: 'Joaquim', role: 'Campino' },
  familia: { name: 'Família', role: 'Família' },
  empresario: { name: 'Empresário', role: 'Empresário' },
};

function characterMeeting(
  state: GameState,
  suffix: string,
  preferred: NarrativeCharacterId,
  title: string,
  summary: string,
  urgency: MeetingUrgency,
  recommendedTab: OfficeTabKey,
  dialogueId?: string,
): MorningCouncilItem {
  const resolved = resolveOfficeCharacter(state, preferred);
  const labels = CHARACTER_LABELS[resolved.characterId];
  return makeMeeting(
    state,
    suffix,
    resolved.characterId,
    labels.name,
    labels.role,
    title,
    summary,
    urgency,
    recommendedTab,
    dialogueId,
    resolved.note,
    resolved.substituteFor,
  );
}

export function createMorningCouncil(state: GameState): MorningCouncilItem[] {
  const meetings: MorningCouncilItem[] = [];
  const offeredContracts = (state.contracts ?? []).filter(contract => contract.status === 'offered');
  const activeContracts = (state.contracts ?? []).filter(contract => contract.status === 'active');
  const tiredStaff = (state.staff ?? []).filter(member => member.fatigue >= 72 || member.morale <= 42);
  const lowTreasury = state.economy.treasury < 35_000;
  const weakPrestige = state.prestige < 45;
  const campaignRisk = state.annualObjectives?.some(objective => objective.year === state.year) ?? false;
  const professionalConflict = createAntonioDuarteConflictMeeting(state);
  const financialConflict = createBeatrizEmpresarioConflictMeeting(state);
  const followUpMemories = getPendingFollowUpMemories(state, 2);

  followUpMemories.forEach((memory, index) => {
    meetings.push(characterMeeting(
      state,
      `memoria-retomada-${index}-${memory.id}`,
      memory.characterId,
      `Retomar: ${memory.title}`,
      `${memory.text} Este assunto continua a pesar na leitura da herdade.`,
      memory.weight >= 5 ? 'alta' : 'normal',
      'diario',
    ));
  });

  if (professionalConflict) {
    meetings.push(professionalConflict);
  } else if (financialConflict) {
    meetings.push(financialConflict);
  }

  if (lowTreasury) {
    meetings.push(characterMeeting(
      state,
      'administradora-tesouraria',
      'administrador',
      'Tesouraria sob pressão',
      `A conta da casa está em ${Math.round(state.economy.treasury).toLocaleString('pt-PT')}€. Há decisões de despesa que devem ser revistas antes de avançar o mês.`,
      'critica',
      'economia',
      'loc_escritorio_1',
    ));
  }

  if (offeredContracts.length > 0) {
    const best = offeredContracts[0];
    meetings.push(characterMeeting(
      state,
      'empresario-contratos',
      'empresario',
      'Proposta em cima da mesa',
      `Há ${offeredContracts.length} proposta(s) por decidir. A mais urgente é "${best.title}".`,
      offeredContracts.length >= 2 ? 'alta' : 'normal',
      'contratos',
      'news_4',
    ));
  } else if (activeContracts.length > 0) {
    meetings.push(characterMeeting(
      state,
      'administradora-contratos-ativos',
      'administrador',
      'Contratos ativos a acompanhar',
      `Existem ${activeContracts.length} contrato(s) ativo(s). Convém acompanhar o impacto mensal na tesouraria.`,
      'baixa',
      'contratos',
    ));
  }

  if (tiredStaff.length > 0) {
    const mostUrgent = tiredStaff[0];
    meetings.push(characterMeeting(
      state,
      'maioral-pessoal',
      'maioral',
      'Equipa cansada',
      `${mostUrgent.name} está a acusar desgaste. Se a casa apertar demais, o trabalho começa a sair caro.`,
      tiredStaff.length >= 2 ? 'alta' : 'normal',
      'pessoal',
      'monthly_winter',
    ));
  }

  if (weakPrestige) {
    meetings.push(characterMeeting(
      state,
      'maioral-prestigio',
      'maioral',
      'O nome da casa precisa de força',
      `O prestígio está em ${Math.round(state.prestige)}. A herdade precisa de uma decisão que volte a pôr a casa nas conversas certas.`,
      'normal',
      'prestigio',
      'news_3',
    ));
  }

  if (campaignRisk) {
    meetings.push(characterMeeting(
      state,
      'administradora-campanha',
      'administrador',
      'Objetivos do ano',
      'Os objetivos anuais estão abertos. Há que decidir se este ano é de prudência, crescimento ou recuperação.',
      'normal',
      'campanha',
    ));
  }

  const duarteSnapshot = getDuarteSnapshot(state);
  if (!professionalConflict && (duarteSnapshot.urgency === 'critica' || duarteSnapshot.urgency === 'alta')) {
    meetings.push(characterMeeting(
      state,
      'veterinario-parecer-clinico',
      'veterinario',
      duarteSnapshot.headline,
      `${duarteSnapshot.spokenLine} ${duarteSnapshot.diagnosis}`,
      duarteSnapshot.urgency,
      duarteSnapshot.recommendedTab,
      'loc_currais_1',
    ));
  }




  const vetAgenda = getCharacterAgendaStatus(state, 'veterinario');
  if (vetAgenda.availability === 'available' && vetAgenda.label !== 'Rotina normal') {
    meetings.push(characterMeeting(
      state,
      'veterinario-agenda',
      'veterinario',
      vetAgenda.label,
      vetAgenda.note,
      'normal',
      'diario',
      'loc_currais_1',
    ));
  }

  const familyAgenda = getCharacterAgendaStatus(state, 'familia');
  if (familyAgenda.availability === 'available' && familyAgenda.label !== 'Rotina normal' && meetings.length < 3) {
    meetings.push(characterMeeting(
      state,
      'familia-agenda',
      'familia',
      familyAgenda.label,
      familyAgenda.note,
      'baixa',
      'diario',
    ));
  }

  if (!professionalConflict) {
  meetings.push(characterMeeting(
    state,
    'maioral-rotina',
    'maioral',
    'Ronda da manhã',
    'O maioral quer fazer o ponto de situação da herdade antes de se avançar para os trabalhos do dia.',
    'normal',
    'diario',
    'monthly_1',
  ));
  }

  const deduped = meetings.filter((meeting, index, list) =>
    list.findIndex(item => item.characterId === meeting.characterId && item.recommendedTab === meeting.recommendedTab) === index,
  );

  return deduped
    .map(meeting => applyAntonioVoiceToMeeting(state, meeting))
    .map(meeting => applyDuarteVoiceToMeeting(state, meeting))
    .map(meeting => applyBeatrizVoiceToMeeting(state, meeting))
    .sort((a, b) => urgencyRank(b.urgency) - urgencyRank(a.urgency))
    .slice(0, 3);
}

export function shouldRefreshMorningCouncil(state: GameState): boolean {
  const key = monthKey(state);
  return !state.morningCouncil || state.morningCouncil.length === 0 || state.morningCouncil[0]?.monthKey !== key;
}
