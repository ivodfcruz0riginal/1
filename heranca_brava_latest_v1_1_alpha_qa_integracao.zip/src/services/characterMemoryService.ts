import type { GameState } from '../store/gameTypes';
import type { CharacterMemory } from '../types/character';
import type { LocationId } from '../types/location';
import type { NarrativeCharacterId } from '../types/narrative';
import { getLivingCharacter } from '../data/characters';

const MEMORY_WEIGHT_LABEL: Record<number, string> = {
  1: 'nota menor',
  2: 'recordação recente',
  3: 'assunto sensível',
  4: 'memória importante',
  5: 'marca forte na relação',
};

function memoryAgeScore(memory: CharacterMemory, state: Pick<GameState, 'year' | 'month'>): number {
  // A memória não tem dia; mantemos uma heurística simples e estável.
  return memory.year === state.year && memory.month === state.month ? 2 : 0;
}

export function relevantMemoriesForCharacter(
  state: Pick<GameState, 'characterMemories' | 'year' | 'month'>,
  characterId: NarrativeCharacterId,
  limit = 3,
  locationId?: LocationId | null,
): CharacterMemory[] {
  return (state.characterMemories ?? [])
    .filter(memory => memory.characterId === characterId)
    .filter(memory => !locationId || !memory.locationId || memory.locationId === locationId)
    .slice()
    .sort((a, b) => (b.weight + memoryAgeScore(b, state)) - (a.weight + memoryAgeScore(a, state)))
    .slice(0, limit);
}

export function buildMemoryLineForCharacter(
  state: Pick<GameState, 'characterMemories' | 'year' | 'month'>,
  characterId: NarrativeCharacterId,
  locationId?: LocationId | null,
): string {
  const [memory] = relevantMemoriesForCharacter(state, characterId, 1, locationId);
  if (!memory) return '';
  const profile = getLivingCharacter(characterId);
  const label = MEMORY_WEIGHT_LABEL[Math.max(1, Math.min(5, Math.round(memory.weight)))] ?? 'memória recente';
  return `${profile?.name ?? 'A personagem'} lembra-se de ${memory.title.toLowerCase()} (${label}).`;
}

export function getPendingFollowUpMemories(
  state: Pick<GameState, 'characterMemories' | 'year' | 'month'>,
  limit = 2,
): CharacterMemory[] {
  const followable = new Set(['meeting_postponed', 'warning', 'location_event', 'professional_conflict']);
  return (state.characterMemories ?? [])
    .filter(memory => followable.has(memory.type))
    .filter(memory => memory.weight >= 3)
    .slice()
    .sort((a, b) => (b.weight + memoryAgeScore(b, state)) - (a.weight + memoryAgeScore(a, state)))
    .slice(0, limit);
}

export function buildDiaryContinuityLine(state: GameState): string {
  const pendingMeetings = state.morningCouncil.filter(item => item.status === 'pending' || item.status === 'postponed');
  const heavyMemories = getPendingFollowUpMemories(state, 3);

  const pendingText = pendingMeetings.length > 0
    ? `Assuntos por fechar: ${pendingMeetings.map(item => `${item.characterName} — ${item.title}`).join('; ')}.`
    : 'Não ficaram assuntos urgentes por fechar no Conselho da Manhã.';

  const memoryText = heavyMemories.length > 0
    ? `Memórias que podem regressar: ${heavyMemories.map(memory => memory.title).join('; ')}.`
    : 'Nenhuma memória crítica ficou a marcar o dia.';

  return `${pendingText} ${memoryText}`;
}
