import React from 'react';
import { useGameState } from '../store/gameState';
import type { NarrativeEffect } from '../types/narrative';

function effectLabel(effect: NarrativeEffect): string | null {
  if (effect.message) return effect.message;
  switch (effect.target) {
    case 'treasury':
      return effect.value ? `Tesouraria ${effect.value > 0 ? '+' : ''}${effect.value.toLocaleString('pt-PT')}€` : null;
    case 'prestige':
      return effect.value ? `Prestígio ${effect.value > 0 ? '+' : ''}${effect.value}` : null;
    case 'relationship':
      return effect.value ? `Relação alterada ${effect.value > 0 ? '+' : ''}${effect.value}` : null;
    case 'animalHealth':
      return effect.value ? `Saúde animal ${effect.value > 0 ? '+' : ''}${effect.value}` : null;
    case 'eventLog':
      return null;
    default:
      return null;
  }
}

const MaioralDialogue: React.FC = () => {
  const { state, answerDialogue, dismissNarrativeResult } = useGameState();
  const { pendingDialogue, lastNarrativeResult } = state;

  if (!pendingDialogue && !lastNarrativeResult) return null;

  const isResult = !pendingDialogue && !!lastNarrativeResult;
  const effects = lastNarrativeResult?.appliedEffects
    .map(effectLabel)
    .filter((label): label is string => Boolean(label))
    .slice(0, 4) ?? [];

  return (
    <div className="absolute inset-0 z-40 flex items-end justify-center pb-10 px-6 pointer-events-none">
      <div className="absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-black/50 via-black/15 to-transparent pointer-events-none" />

      <div
        className="relative pointer-events-auto w-full max-w-xl rounded-lg shadow-2xl overflow-hidden"
        style={{
          background: 'linear-gradient(160deg, #1f1609 0%, #170e06 100%)',
          border: '1px solid rgba(180,140,55,0.38)',
        }}
      >
        <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-gold/50 pointer-events-none" />
        <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-gold/50 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-gold/50 pointer-events-none" />
        <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-gold/50 pointer-events-none" />

        <div className="flex items-center gap-3 px-5 pt-4 pb-3 border-b border-leather-700/40">
          <div className="relative shrink-0">
            <div className="w-10 h-10 rounded-full bg-leather-700/70 border-2 border-gold/30 flex items-center justify-center overflow-hidden">
              <div className="absolute bottom-0 inset-x-0 h-5 bg-leather-800/80" />
              <div className="absolute bottom-3.5 left-1/2 -translate-x-1/2 w-4 h-4 bg-amber-800/70 rounded-full" />
              <div className="absolute top-1.5 left-1/2 -translate-x-1/2 w-6 h-1.5 bg-leather-900/80 rounded-full" />
              <div className="absolute top-2.5 left-1/2 -translate-x-1/2 w-4 h-2 bg-leather-800/70 rounded-t-sm" />
            </div>
            <div className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-gold/80 border border-leather-900 flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-leather-900" />
            </div>
          </div>

          <div>
            <p className="font-display text-sm text-gold tracking-widest uppercase leading-none">
              {isResult ? 'Consequência' : 'Manuel'}
            </p>
            <p className="text-ivory/35 text-[10px] font-body uppercase tracking-wider mt-0.5">
              {isResult ? 'Resultado da decisão' : 'Maioral · Herdade da Ferraria'}
            </p>
          </div>

          <div className="ml-auto flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-gold/60 animate-pulse" />
            <span className="text-ivory/20 text-[9px] font-body uppercase tracking-widest">
              {isResult ? 'Registado no diário' : 'À sua espera'}
            </span>
          </div>
        </div>

        <div className="px-5 pt-4 pb-3">
          <div className="relative pl-3 border-l-2 border-gold/25">
            <p className="text-ivory/80 text-sm font-body leading-relaxed italic">
              "{isResult ? lastNarrativeResult?.resultText : pendingDialogue?.text}"
            </p>
          </div>

          {isResult && effects.length > 0 && (
            <div className="mt-3 rounded border border-leather-600/30 bg-black/15 px-3 py-2">
              <p className="text-gold/70 text-[10px] uppercase tracking-widest mb-1">Efeitos aplicados</p>
              <ul className="space-y-1">
                {effects.map((effect, index) => (
                  <li key={index} className="text-ivory/55 text-xs font-body">• {effect}</li>
                ))}
              </ul>
            </div>
          )}
        </div>

        <div className="mx-5 h-px bg-gradient-to-r from-transparent via-leather-600/40 to-transparent" />

        <div className="px-5 py-4 flex flex-col gap-2">
          {pendingDialogue?.choices.map((choice, i) => (
            <button
              key={i}
              onClick={() => answerDialogue(choice)}
              className="text-left flex items-center gap-2.5 px-3.5 py-2.5 border border-leather-600/40 rounded transition-all duration-200 hover:border-gold/50 hover:bg-gold/10 group"
            >
              <span className="text-gold/35 text-xs font-body group-hover:text-gold/70 transition-colors shrink-0">›</span>
              <span className="text-ivory/65 text-xs font-body group-hover:text-ivory/90 transition-colors">
                {choice}
              </span>
            </button>
          ))}

          {isResult && (
            <button
              onClick={dismissNarrativeResult}
              className="text-left flex items-center gap-2.5 px-3.5 py-2.5 border border-gold/40 rounded transition-all duration-200 hover:border-gold/70 hover:bg-gold/10 group"
            >
              <span className="text-gold/60 text-xs font-body group-hover:text-gold transition-colors shrink-0">›</span>
              <span className="text-ivory/75 text-xs font-body group-hover:text-ivory transition-colors">
                Continuar
              </span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default MaioralDialogue;
