import React from 'react';
import type { Animal } from '../types/animal';
import type { LineageSummary } from '../types/lineage';
import { createLineageSummaries } from '../services/lineageService';

interface TraitChipProps {
  label: string;
  value: number;
}

const TraitChip: React.FC<TraitChipProps> = ({ label, value }) => (
  <div className="rounded-md border border-leather-600/40 bg-leather-800/40 px-2 py-1">
    <span className="block text-[9px] uppercase tracking-wider text-ivory/35 font-body">{label}</span>
    <span className="font-display text-sm text-gold">{value}</span>
  </div>
);

const riskStyles: Record<LineageSummary['riskLevel'], string> = {
  baixo: 'text-emerald-300 border-emerald-600/30 bg-emerald-900/20',
  medio: 'text-amber-300 border-amber-600/30 bg-amber-900/20',
  alto: 'text-red-300 border-red-600/30 bg-red-900/20',
};

interface LineageCardProps {
  summary: LineageSummary;
}

const LineageCard: React.FC<LineageCardProps> = ({ summary }) => (
  <div className="rounded-lg border border-leather-600/40 bg-leather-800/45 p-3 space-y-3">
    <div className="flex items-start justify-between gap-3">
      <div>
        <h4 className="font-display text-gold text-base tracking-wider uppercase">{summary.name}</h4>
        <p className="text-ivory/45 text-xs font-body mt-0.5">
          {summary.totalAnimals} animais · {summary.breedingAnimals} reprodutores · idade média {summary.averageAgeYears} anos
        </p>
      </div>
      <div className="text-right shrink-0">
        <span className="block text-[9px] uppercase tracking-wider text-ivory/35 font-body">Influência</span>
        <span className="font-display text-xl text-gold">{summary.influenceScore}</span>
      </div>
    </div>

    <p className="text-ivory/60 text-xs font-body leading-relaxed italic">{summary.note}</p>

    <div className="grid grid-cols-3 gap-2">
      <TraitChip label="Bravura" value={summary.averageTraits.bravery} />
      <TraitChip label="Nobreza" value={summary.averageTraits.nobility} />
      <TraitChip label="Mobilidade" value={summary.averageTraits.mobility} />
    </div>

    <div className="flex items-center justify-between gap-3 text-xs font-body">
      <span className={`px-2 py-1 rounded-full border ${riskStyles[summary.riskLevel]}`}>
        Risco {summary.riskLevel}
      </span>
      <span className="text-ivory/40">{summary.sementais} sementais · {summary.vacas} vacas · {summary.youngAnimals} jovens</span>
    </div>

    {(summary.keySires.length > 0 || summary.foundingFemales.length > 0) && (
      <div className="grid grid-cols-2 gap-2 pt-2 border-t border-leather-700/30">
        <div>
          <span className="block text-[9px] uppercase tracking-wider text-ivory/35 font-body mb-1">Sementais chave</span>
          <p className="text-ivory/65 text-xs font-body">
            {summary.keySires.map(animal => animal.name).join(', ') || 'Sem registo'}
          </p>
        </div>
        <div>
          <span className="block text-[9px] uppercase tracking-wider text-ivory/35 font-body mb-1">Vacas de base</span>
          <p className="text-ivory/65 text-xs font-body">
            {summary.foundingFemales.map(animal => animal.name).join(', ') || 'Sem registo'}
          </p>
        </div>
      </div>
    )}
  </div>
);

interface LineagePanelProps {
  animals: Animal[];
}

const LineagePanel: React.FC<LineagePanelProps> = ({ animals }) => {
  const summaries = createLineageSummaries(animals);
  const top = summaries[0];
  const atRisk = summaries.filter(summary => summary.riskLevel === 'alto').length;

  if (summaries.length === 0) return null;

  return (
    <div className="px-6 py-4 border-b border-leather-700/30 bg-leather-900/50 shrink-0">
      <div className="flex items-start justify-between gap-4 mb-3">
        <div>
          <h3 className="font-display text-lg text-gold tracking-widest uppercase">Livro de Linhagens</h3>
          <p className="text-ivory/45 text-sm font-body mt-0.5">
            A leitura da casa por origens, vacas de base e sementais de influência.
          </p>
        </div>
        {top && (
          <div className="hidden md:block text-right">
            <span className="block text-[10px] uppercase tracking-wider text-ivory/35 font-body">Linha dominante</span>
            <span className="font-display text-gold text-xl tracking-wider">{top.name}</span>
            <p className="text-ivory/45 text-xs font-body">{top.influenceScore}/100 influência</p>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">
        {summaries.slice(0, 3).map(summary => (
          <LineageCard key={summary.id} summary={summary} />
        ))}
      </div>

      {atRisk > 0 && (
        <p className="mt-3 text-amber-300/80 text-xs font-body">
          ⚠ {atRisk} linha(s) com pouca base reprodutiva. Proteger diversidade evita perder história genética da casa.
        </p>
      )}
    </div>
  );
};

export default LineagePanel;
