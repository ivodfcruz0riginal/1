import React, { useRef } from 'react';
import { useGameState } from '../store/gameState';
import type { Season, GamePhase } from '../store/gameState';
import { DAY_PERIOD_LABELS } from '../types/day';
import { formatEuro } from '../store/economyEngine';

// ── StatBadge ─────────────────────────────────────────────────────────────────

interface StatBadgeProps {
  icon: string;
  value: string | number;
  label?: string;
  highlight?: boolean;
}

const StatBadge: React.FC<StatBadgeProps> = ({ icon, value, label, highlight }) => (
  <div className={`flex items-center gap-2.5 px-4 py-2 rounded-md border transition-all duration-300 ${
    highlight
      ? 'bg-gold/15 border-gold/50 hover:border-gold'
      : 'bg-leather-800/60 border-leather-600/50 hover:border-gold/40'
  }`}>
    <span className="text-lg">{icon}</span>
    <div className="flex flex-col">
      {label && <span className="text-ivory/50 text-[10px] font-body uppercase tracking-wider">{label}</span>}
      <span className={`font-display text-lg font-semibold ${highlight ? 'text-gold' : 'text-ivory'}`}>
        {value}
      </span>
    </div>
  </div>
);

// ── Phase indicator ───────────────────────────────────────────────────────────

const PHASE_ORDER: GamePhase[] = [
  'MonthStart',
  'DailyPlanning',
  'EstateManagement',
  'Decisions',
  'EndOfMonth',
  'Simulation',
];

const PHASE_LABELS: Record<GamePhase, string> = {
  MonthStart:       'Início do Mês',
  DailyPlanning:    'Planeamento',
  EstateManagement: 'Gestão',
  Decisions:        'Decisões',
  EndOfMonth:       'Fim do Mês',
  Simulation:       'Simulação',
};

const PhaseIndicator: React.FC<{ current: GamePhase }> = ({ current }) => (
  <div className="flex items-center justify-center gap-1 mt-2 pt-2 border-t border-leather-700/40">
    {PHASE_ORDER.flatMap((phase, i) => {
      const isActive = phase === current;
      const pill = (
        <div
          key={phase}
          className={`px-2.5 py-0.5 rounded text-[9px] font-body uppercase tracking-wider border transition-all duration-300 ${
            isActive
              ? 'bg-gold/20 border-gold/50 text-gold shadow-[0_0_8px_rgba(201,162,39,0.2)]'
              : 'border-leather-600/25 text-ivory/18'
          }`}
        >
          {PHASE_LABELS[phase]}
        </div>
      );
      if (i < PHASE_ORDER.length - 1) {
        return [
          pill,
          <span key={`sep-${i}`} className="text-leather-600/35 text-[8px] select-none leading-none">›</span>,
        ];
      }
      return [pill];
    })}
  </div>
);

// ── Season icons ──────────────────────────────────────────────────────────────

const SEASON_ICONS: Record<Season, string> = {
  Primavera: '❀',
  Verão: '☀',
  Outono: '🍂',
  Inverno: '❄',
};

// ── Header ────────────────────────────────────────────────────────────────────

const Header: React.FC = () => {
  const { state, advanceMonth, advanceDayPeriod, closeDay, setPhase } = useGameState();
  const advanceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const handleAdvanceMonth = () => {
    if (advanceTimerRef.current) return; // prevent double-click

    setPhase('EndOfMonth');
    advanceTimerRef.current = setTimeout(() => {
      setPhase('Simulation');
      advanceTimerRef.current = setTimeout(() => {
        advanceTimerRef.current = null;
        advanceMonth();
      }, 500);
    }, 500);
  };

  const handleAdvancePeriod = () => {
    advanceDayPeriod();
  };

  const handleCloseDay = () => {
    closeDay();
  };

  const isAdvancing = state.phase === 'EndOfMonth' || state.phase === 'Simulation';

  return (
    <header className="bg-leather-900 border-b-2 border-gold/20 px-6 pt-3 pb-2">
      <div className="flex items-center justify-between">
        {/* Left: Title */}
        <div className="flex items-center gap-6">
          <div>
            <h1 className="font-display text-2xl text-gold tracking-widest uppercase">HERANÇA BRAVA</h1>
            <p className="text-ivory/40 text-xs font-body tracking-wide">GESTÃO DE TOURO BRAVO</p>
          </div>
        </div>

        {/* Center: Year, Month & Season + Advance button */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 bg-leather-800/50 border-2 border-gold/30 rounded-lg px-5 py-2">
            <div className="flex flex-col items-center">
              <span className="text-ivory/40 text-[10px] font-body uppercase tracking-wider">Ano</span>
              <span className="font-display text-2xl text-ivory font-bold">{state.year}</span>
            </div>
            <div className="w-px h-8 bg-gold/20 mx-2" />
            <div className="flex flex-col items-center min-w-[4.5rem]">
              <span className="text-ivory/40 text-[10px] font-body uppercase tracking-wider">Mês</span>
              <span className="font-display text-base text-ivory font-semibold">{state.month}</span>
            </div>
            <div className="w-px h-8 bg-gold/20 mx-2" />
            <div className="flex flex-col items-center">
              <span className="text-ivory/40 text-[10px] font-body uppercase tracking-wider">Estação</span>
              <div className="flex items-center gap-1.5">
                <span className="text-gold">{SEASON_ICONS[state.season]}</span>
                <span className="font-display text-base text-gold font-semibold">{state.season}</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-1.5 bg-leather-800/50 border-2 border-gold/20 rounded-lg px-4 py-2">
            <div className="flex flex-col items-center">
              <span className="text-ivory/40 text-[10px] font-body uppercase tracking-wider">Dia</span>
              <span className="font-display text-xl text-ivory font-bold">{state.dayOfMonth}</span>
            </div>
            <div className="w-px h-7 bg-gold/15 mx-1" />
            <div className="flex flex-col items-center min-w-[4.5rem]">
              <span className="text-ivory/40 text-[10px] font-body uppercase tracking-wider">Período</span>
              <span className="font-display text-sm text-gold font-semibold">{DAY_PERIOD_LABELS[state.dayPeriod]}</span>
            </div>
          </div>

          <button
            onClick={handleAdvancePeriod}
            disabled={isAdvancing || state.dayPeriod === 'noite'}
            className="group relative flex items-center gap-2 px-3 py-2.5 border-2 rounded-lg transition-all duration-200 bg-leather-800/60 border-gold/25 hover:border-gold/50 hover:bg-gold/8 disabled:opacity-35 disabled:cursor-not-allowed"
          >
            <span className="font-display text-xs text-gold tracking-wider uppercase">Avançar Período</span>
            <span className="text-gold/60">›</span>
          </button>

          <button
            onClick={handleCloseDay}
            disabled={isAdvancing}
            className="group relative flex items-center gap-2 px-3 py-2.5 border-2 rounded-lg transition-all duration-200 bg-leather-800/60 border-gold/35 hover:border-gold hover:bg-gold/10 disabled:opacity-60"
          >
            <span className="font-display text-xs text-gold tracking-wider uppercase">Fechar Dia</span>
            <span className="text-gold/70">🌙</span>
          </button>

          {/* Advance Month button */}
          <button
            onClick={handleAdvanceMonth}
            disabled={isAdvancing}
            className={`group relative flex items-center gap-2 px-4 py-2.5 border-2 rounded-lg transition-all duration-200 ${
              isAdvancing
                ? 'bg-gold/5 border-gold/20 cursor-not-allowed opacity-60'
                : 'bg-leather-800/60 border-gold/40 hover:border-gold hover:bg-gold/10 cursor-pointer'
            }`}
          >
            {isAdvancing ? (
              <>
                <span className="font-display text-sm text-gold/60 tracking-wider uppercase">
                  {state.phase === 'EndOfMonth' ? 'Fim do Mês...' : 'Simulando...'}
                </span>
                <span className="text-gold/40 animate-spin text-xs">◌</span>
              </>
            ) : (
              <>
                <span className="font-display text-sm text-gold tracking-wider uppercase">Fechar Mês</span>
                <span className="text-gold/70 group-hover:translate-x-0.5 transition-transform">▶</span>
              </>
            )}
          </button>
        </div>

        {/* Right: Stats */}
        <div className="flex items-center gap-3">
          <StatBadge icon="👑" value="250" label="Prestígio" />
          <StatBadge icon="💶" value={formatEuro(state.economy.treasury)} label="Tesouraria" highlight />
          <StatBadge icon="🐂" value="42" label="Efetivo" />
        </div>
      </div>

      {/* Phase indicator */}
      <PhaseIndicator current={state.phase} />
    </header>
  );
};

export default Header;
