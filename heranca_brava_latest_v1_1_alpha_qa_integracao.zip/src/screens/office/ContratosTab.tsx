import React from 'react';
import { useGameState } from '../../store/gameState';
import { formatEuro } from '../../store/economyEngine';
import { canAcceptContract } from '../../services/contractService';
import type { Contract, ContractStatus, ContractType } from '../../types/contract';
import { SectionTitle, EmptyState, PaperCard, Pill, StatBlock } from './OfficePrimitives';

function typeLabel(type: ContractType): string {
  const labels: Record<ContractType, string> = {
    corrida: 'Corrida',
    venda: 'Venda',
    avenca: 'Avença',
    servico: 'Serviço',
    visita: 'Visita',
  };
  return labels[type];
}

function statusPill(status: ContractStatus): { label: string; variant: 'gold' | 'green' | 'amber' | 'red' | 'muted' } {
  if (status === 'offered') return { label: 'Proposta', variant: 'gold' };
  if (status === 'active') return { label: 'Ativo', variant: 'green' };
  if (status === 'completed') return { label: 'Concluído', variant: 'muted' };
  if (status === 'rejected') return { label: 'Recusado', variant: 'red' };
  return { label: 'Expirado', variant: 'amber' };
}

const ContractCard: React.FC<{ contract: Contract; mode: 'offer' | 'active' | 'archive' }> = ({ contract, mode }) => {
  const game = useGameState();
  const validation = canAcceptContract(contract, game.state);
  const status = statusPill(contract.status);
  const income = (contract.upfrontIncome ?? 0) + (contract.monthlyIncome ?? 0) * Math.max(1, contract.durationMonths);
  const expenses = (contract.upfrontExpense ?? 0) + (contract.monthlyExpense ?? 0) * Math.max(1, contract.durationMonths);
  const net = income - expenses;

  return (
    <PaperCard>
      <div className="flex items-start justify-between gap-3 mb-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <p className="font-display text-sm text-ivory/85">{contract.title}</p>
            <Pill label={typeLabel(contract.type)} variant="amber" />
          </div>
          <p className="text-ivory/35 text-[10px] font-body uppercase tracking-wider">{contract.partner}</p>
        </div>
        <Pill label={status.label} variant={status.variant} />
      </div>

      <p className="text-ivory/55 text-xs font-body leading-relaxed mb-4">{contract.description}</p>

      <div className="grid grid-cols-3 gap-2 mb-4">
        <div className="bg-leather-900/30 rounded-md p-2 border border-leather-600/20">
          <p className="text-ivory/30 text-[9px] font-body uppercase tracking-wider">Saldo</p>
          <p className={`font-display text-sm ${net >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>{net >= 0 ? '+' : ''}{formatEuro(net)}</p>
        </div>
        <div className="bg-leather-900/30 rounded-md p-2 border border-leather-600/20">
          <p className="text-ivory/30 text-[9px] font-body uppercase tracking-wider">Duração</p>
          <p className="font-display text-sm text-ivory/75">{contract.durationMonths} mês(es)</p>
        </div>
        <div className="bg-leather-900/30 rounded-md p-2 border border-leather-600/20">
          <p className="text-ivory/30 text-[9px] font-body uppercase tracking-wider">Risco</p>
          <p className="font-display text-sm text-gold/80">{contract.riskLabel ?? 'Normal'}</p>
        </div>
      </div>

      {mode === 'active' && (
        <p className="text-ivory/40 text-xs font-body mb-3">Restam {contract.monthsRemaining} mês(es) de execução.</p>
      )}

      {mode === 'offer' && !validation.ok && (
        <p className="text-red-400/80 text-xs font-body mb-3">Não cumpre requisitos: {validation.reason}</p>
      )}

      {mode === 'offer' && (
        <div className="flex gap-2">
          <button
            onClick={() => game.acceptContract(contract.id)}
            disabled={!validation.ok}
            className="px-3 py-2 rounded-md border border-gold/40 bg-gold/10 text-gold text-xs font-display uppercase tracking-wider disabled:opacity-30 disabled:cursor-not-allowed hover:bg-gold/15 transition-colors"
          >
            Aceitar
          </button>
          <button
            onClick={() => game.rejectContract(contract.id)}
            className="px-3 py-2 rounded-md border border-leather-500/40 bg-leather-800/30 text-ivory/50 text-xs font-display uppercase tracking-wider hover:text-ivory/70 transition-colors"
          >
            Recusar
          </button>
        </div>
      )}
    </PaperCard>
  );
};

const ContratosTab: React.FC = () => {
  const { state } = useGameState();
  const offers = state.contracts.filter(c => c.status === 'offered');
  const active = state.contracts.filter(c => c.status === 'active');
  const archive = state.contracts.filter(c => c.status === 'completed' || c.status === 'rejected' || c.status === 'expired');
  const activeMonthlyIncome = active.reduce((sum, c) => sum + (c.monthlyIncome ?? 0), 0);
  const activeMonthlyExpenses = active.reduce((sum, c) => sum + (c.monthlyExpense ?? 0), 0);

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <SectionTitle>Livro de Contratos</SectionTitle>

      <div className="grid grid-cols-3 gap-3 mb-5 shrink-0">
        <StatBlock label="Propostas" value={offers.length} sub="Aguardam decisão" />
        <StatBlock label="Contratos Ativos" value={active.length} sub="Em execução" />
        <StatBlock
          label="Saldo Mensal"
          value={<span className={(activeMonthlyIncome - activeMonthlyExpenses) >= 0 ? 'text-emerald-400' : 'text-red-400'}>{formatEuro(activeMonthlyIncome - activeMonthlyExpenses)}</span>}
          sub="Contratos ativos"
        />
      </div>

      <div className="grid grid-cols-2 gap-5 flex-1 min-h-0">
        <div className="overflow-y-auto pr-1">
          <SectionTitle>Propostas na Secretária</SectionTitle>
          {offers.length === 0 ? (
            <EmptyState icon="📜" title="Sem propostas" subtitle="Novos contratos aparecerão aqui conforme o prestígio e os eventos." />
          ) : (
            <div className="space-y-3">
              {offers.map(contract => <ContractCard key={contract.id} contract={contract} mode="offer" />)}
            </div>
          )}
        </div>

        <div className="overflow-y-auto pr-1">
          <SectionTitle>Ativos e Arquivo</SectionTitle>
          {active.length === 0 && archive.length === 0 ? (
            <EmptyState icon="🗄️" title="Arquivo vazio" subtitle="Aceita uma proposta para iniciar o histórico contratual da casa." />
          ) : (
            <div className="space-y-3">
              {active.map(contract => <ContractCard key={contract.id} contract={contract} mode="active" />)}
              {archive.slice(0, 6).map(contract => <ContractCard key={contract.id} contract={contract} mode="archive" />)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ContratosTab;
