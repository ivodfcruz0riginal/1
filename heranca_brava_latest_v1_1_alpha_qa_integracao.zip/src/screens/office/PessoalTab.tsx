import React from 'react';
import { useGameState } from '../../store/gameState';
import { formatEuro } from '../../store/economyEngine';
import { averageStaffScore, calculatePayroll, roleLabel } from '../../services/staffService';
import type { StaffMember, StaffStatus } from '../../types/staff';
import { LIVING_CHARACTERS } from '../../data/characters';
import { getCharacterAgendaStatus, recentMemoriesForCharacter, relationshipTone } from '../../services/characterService';
import { getAntonioSnapshot } from '../../services/antonioService';
import { getDuarteSnapshot } from '../../services/duarteService';
import { getBeatrizSnapshot } from '../../services/beatrizService';
import { SectionTitle, EmptyState, PaperCard, Pill, StatBlock } from './OfficePrimitives';

function statusPill(status: StaffStatus): { label: string; variant: 'green' | 'amber' | 'red' | 'muted' } {
  if (status === 'ativo') return { label: 'Ativo', variant: 'green' };
  if (status === 'descanso') return { label: 'Descanso', variant: 'amber' };
  if (status === 'doente') return { label: 'Doente', variant: 'red' };
  return { label: 'Indisponível', variant: 'muted' };
}

const Bar: React.FC<{ label: string; value: number }> = ({ label, value }) => (
  <div>
    <div className="flex justify-between text-[10px] font-body uppercase tracking-wider mb-1">
      <span className="text-ivory/35">{label}</span>
      <span className="text-ivory/60">{value}/100</span>
    </div>
    <div className="h-1.5 bg-leather-900/60 rounded overflow-hidden border border-leather-700/30">
      <div className="h-full bg-gold/60" style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
    </div>
  </div>
);

const StaffCard: React.FC<{ member: StaffMember }> = ({ member }) => {
  const { giveStaffRest, giveStaffBonus, trainStaff } = useGameState();
  const status = statusPill(member.status);

  return (
    <PaperCard>
      <div className="flex items-start justify-between gap-3 mb-3">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <p className="font-display text-sm text-ivory/85">{member.name}</p>
            <Pill label={roleLabel(member.role)} variant="amber" />
          </div>
          <p className="text-ivory/35 text-[10px] font-body uppercase tracking-wider">
            {member.age} anos · {member.seniority} anos de casa · {formatEuro(member.monthlySalary)}/mês
          </p>
        </div>
        <Pill label={status.label} variant={status.variant} />
      </div>

      <div className="grid grid-cols-2 gap-3 mb-4">
        <Bar label="Competência" value={member.competence} />
        <Bar label="Lealdade" value={member.loyalty} />
        <Bar label="Moral" value={member.morale} />
        <Bar label="Cansaço" value={member.fatigue} />
      </div>

      <div className="space-y-1 mb-4">
        {member.notes.slice(0, 2).map(note => (
          <p key={note} className="text-ivory/45 text-xs font-body leading-relaxed">• {note}</p>
        ))}
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => giveStaffRest(member.id)}
          className="px-3 py-2 rounded-md border border-leather-500/40 bg-leather-800/30 text-ivory/55 text-[10px] font-display uppercase tracking-wider hover:text-ivory/75 transition-colors"
        >
          Dar descanso
        </button>
        <button
          onClick={() => giveStaffBonus(member.id)}
          className="px-3 py-2 rounded-md border border-gold/40 bg-gold/10 text-gold text-[10px] font-display uppercase tracking-wider hover:bg-gold/15 transition-colors"
        >
          Bónus 1.000€
        </button>
        <button
          onClick={() => trainStaff(member.id)}
          className="px-3 py-2 rounded-md border border-emerald-500/35 bg-emerald-900/10 text-emerald-300 text-[10px] font-display uppercase tracking-wider hover:bg-emerald-900/20 transition-colors"
        >
          Formação 1.500€
        </button>
      </div>
    </PaperCard>
  );
};


const CharacterCard: React.FC<{ characterId: string }> = ({ characterId }) => {
  const { state } = useGameState();
  const profile = LIVING_CHARACTERS.find(character => character.id === characterId);
  if (!profile) return null;
  const rel = state.relationships[profile.id];
  const memories = recentMemoriesForCharacter(state, profile.id, 2);
  const agenda = getCharacterAgendaStatus(state, profile.id);
  const antonioSnapshot = profile.id === 'maioral' ? getAntonioSnapshot(state) : null;
  const duarteSnapshot = profile.id === 'veterinario' ? getDuarteSnapshot(state) : null;
  const beatrizSnapshot = profile.id === 'administrador' ? getBeatrizSnapshot(state) : null;
  return (
    <PaperCard>
      <div className="flex items-start justify-between gap-3 mb-3">
        <div>
          <p className="font-display text-sm text-ivory/85">{profile.displayName}</p>
          <p className="text-ivory/35 text-[10px] font-body uppercase tracking-wider">
            {profile.age > 0 ? `${profile.age} anos · ` : ''}{profile.yearsAtRanch > 0 ? `${profile.yearsAtRanch} anos de casa · ` : ''}{profile.temperament}
          </p>
        </div>
        <Pill label={profile.role} variant="amber" />
      </div>

      <p className="text-ivory/50 text-xs font-body leading-relaxed mb-3">{profile.shortBio}</p>
      {antonioSnapshot && (
        <div className="mb-3 rounded border border-gold/25 bg-gold/8 px-3 py-2">
          <p className="text-[10px] uppercase tracking-widest text-gold/55 font-body">Leitura de hoje</p>
          <p className="text-ivory/70 text-xs font-body leading-relaxed mt-1 italic">“{antonioSnapshot.spokenLine}”</p>
          <p className="text-ivory/40 text-[11px] font-body leading-relaxed mt-1">{antonioSnapshot.concern}</p>
        </div>
      )}
      {duarteSnapshot && (
        <div className="mb-3 rounded border border-emerald-400/25 bg-emerald-950/10 px-3 py-2">
          <p className="text-[10px] uppercase tracking-widest text-emerald-300/55 font-body">Parecer clínico</p>
          <p className="text-ivory/70 text-xs font-body leading-relaxed mt-1 italic">“{duarteSnapshot.spokenLine}”</p>
          <p className="text-ivory/40 text-[11px] font-body leading-relaxed mt-1">{duarteSnapshot.diagnosis}</p>
          <p className="text-emerald-200/50 text-[11px] font-body leading-relaxed mt-1">{duarteSnapshot.professionalOpinion}</p>
        </div>
      )}

      {beatrizSnapshot && (
        <div className="mb-3 rounded border border-sky-300/25 bg-sky-950/10 px-3 py-2">
          <p className="text-[10px] uppercase tracking-widest text-sky-200/55 font-body">Leitura administrativa</p>
          <p className="text-ivory/70 text-xs font-body leading-relaxed mt-1 italic">“{beatrizSnapshot.spokenLine}”</p>
          <p className="text-ivory/40 text-[11px] font-body leading-relaxed mt-1">{beatrizSnapshot.financialReading}</p>
          <p className="text-sky-100/50 text-[11px] font-body leading-relaxed mt-1">{beatrizSnapshot.administrativeOpinion}</p>
        </div>
      )}
      <div className="mb-3 rounded border border-leather-600/30 bg-black/10 px-3 py-2">
        <p className="text-[10px] uppercase tracking-widest text-gold/45 font-body">Agenda atual</p>
        <p className="text-ivory/60 text-xs font-body mt-1">{agenda.label} · {agenda.locationId}</p>
        <p className="text-ivory/35 text-[11px] font-body leading-relaxed mt-1">{agenda.note}</p>
      </div>
      <p className="text-gold/65 text-xs font-body leading-relaxed mb-4">{relationshipTone(state, profile.id)}</p>

      {rel && (
        <div className="grid grid-cols-2 gap-3 mb-4">
          <Bar label="Confiança" value={rel.trust} />
          <Bar label="Respeito" value={rel.respect} />
          <Bar label="Lealdade" value={rel.loyalty} />
          <Bar label="Tensão" value={rel.tension ?? 10} />
        </div>
      )}

      <div className="space-y-2">
        <p className="text-[10px] uppercase tracking-widest text-ivory/30 font-body">Memórias recentes</p>
        {memories.length === 0 ? (
          <p className="text-ivory/35 text-xs font-body">Ainda não existem memórias marcantes com esta personagem.</p>
        ) : memories.map(memory => (
          <div key={memory.id} className="border-l border-gold/25 pl-3">
            <p className="text-ivory/65 text-xs font-body">{memory.title}</p>
            <p className="text-ivory/35 text-[11px] font-body leading-relaxed">{memory.text}</p>
          </div>
        ))}
      </div>
    </PaperCard>
  );
};

const PessoalTab: React.FC = () => {
  const { state } = useGameState();
  const staff = state.staff ?? [];
  const payroll = calculatePayroll(staff);
  const averageScore = averageStaffScore(staff);
  const tired = staff.filter(member => member.fatigue >= 70).length;

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <SectionTitle>Livro do Pessoal</SectionTitle>

      <div className="grid grid-cols-4 gap-3 mb-5 shrink-0">
        <StatBlock label="Equipa" value={staff.length} sub="Pessoas da casa" />
        <StatBlock label="Folha Salarial" value={formatEuro(payroll)} sub="Custo mensal explícito" />
        <StatBlock label="Força da Equipa" value={averageScore} sub="Competência, moral e lealdade" />
        <StatBlock label="Cansaço Elevado" value={tired} sub="Requer atenção" />
      </div>

      <div className="flex-1 overflow-y-auto pr-1 space-y-6">
        <div>
          <SectionTitle>Personagens Principais</SectionTitle>
          <div className="grid grid-cols-2 gap-4">
            {LIVING_CHARACTERS.slice(0, 4).map(character => <CharacterCard key={character.id} characterId={character.id} />)}
          </div>
        </div>

        <div>
          <SectionTitle>Equipa da Casa</SectionTitle>
          {staff.length === 0 ? (
            <EmptyState icon="👥" title="Sem pessoal registado" subtitle="A equipa da ganadaria aparecerá aqui." />
          ) : (
            <div className="grid grid-cols-2 gap-4">
              {staff.map(member => <StaffCard key={member.id} member={member} />)}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PessoalTab;
