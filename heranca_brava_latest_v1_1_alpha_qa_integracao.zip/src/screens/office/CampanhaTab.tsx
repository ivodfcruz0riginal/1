import React from 'react';
import { useGameState } from '../../store/gameState';
import { formatEuro } from '../../store/economyEngine';
import { getCampaignSnapshot } from '../../services/campaignService';
import type { RanchStatusTier } from '../../types/campaign';
import { SectionTitle, PaperCard, StatBlock, Pill, EmptyState } from './OfficePrimitives';

const statusVariant: Record<RanchStatusTier, 'red' | 'amber' | 'green' | 'gold' | 'sky' | 'muted'> = {
  'Em Crise': 'red',
  'Estável': 'muted',
  'Em Crescimento': 'green',
  'Referência Regional': 'amber',
  'Referência Nacional': 'gold',
  'Lendária': 'sky',
};

const ProgressBar: React.FC<{ value: number }> = ({ value }) => (
  <div className="h-2 bg-leather-700/50 rounded-full overflow-hidden">
    <div className="h-full bg-gold/70 rounded-full transition-all" style={{ width: `${Math.max(0, Math.min(100, value))}%` }} />
  </div>
);

const CampanhaTab: React.FC = () => {
  const { state, advanceMonth } = useGameState();
  const snapshot = getCampaignSnapshot(state);
  const latestReport = state.annualReports[0];

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <SectionTitle>Campanha 5 Anos</SectionTitle>

      <div className="grid grid-cols-4 gap-3 mb-5 shrink-0">
        <StatBlock label="Ano da Campanha" value={`${snapshot.campaignYear}/${snapshot.targetYears}`} sub={`${snapshot.completionPercent}% concluído`} />
        <StatBlock label="Estado da Casa" value={<span>{snapshot.ranchStatus}</span>} sub="Classificação produtiva" />
        <StatBlock label="Tesouraria" value={formatEuro(state.economy.treasury)} sub="Saldo atual" />
        <StatBlock label="Prestígio" value={state.prestige} sub="Índice dinâmico" />
      </div>

      <PaperCard className="mb-5 shrink-0">
        <div className="flex items-center justify-between gap-4 mb-3">
          <div>
            <p className="font-display text-sm text-gold uppercase tracking-widest">Progresso da Campanha</p>
            <p className="text-ivory/40 text-xs font-body mt-1">
              Objetivo de validação: manter a ganadaria ativa durante 5 anos completos.
            </p>
          </div>
          <Pill label={snapshot.ranchStatus} variant={statusVariant[snapshot.ranchStatus]} />
        </div>
        <ProgressBar value={snapshot.completionPercent} />
        <div className="flex justify-between text-[10px] text-ivory/30 font-body mt-2">
          <span>Início</span>
          <span>{snapshot.monthsPlayed} meses jogados</span>
          <span>{snapshot.monthsRemaining} meses restantes</span>
        </div>
      </PaperCard>

      <div className="grid grid-cols-2 gap-5 flex-1 min-h-0">
        <div className="overflow-y-auto pr-1">
          <div className="flex items-center justify-between mb-3">
            <SectionTitle>Objetivos do Ano</SectionTitle>
            <button
              onClick={advanceMonth}
              className="bg-gold/15 border border-gold/40 text-gold rounded px-3 py-1.5 text-[10px] font-body uppercase tracking-wider hover:bg-gold/25 transition-colors"
            >
              Avançar Mês
            </button>
          </div>
          <div className="space-y-3">
            {snapshot.activeObjectives.length === 0 ? (
              <EmptyState icon="🎯" title="Sem objetivos" subtitle="Os objetivos anuais serão criados no início da campanha." />
            ) : snapshot.activeObjectives.map(objective => (
              <PaperCard key={objective.id}>
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div>
                    <p className="font-display text-sm text-ivory/85">{objective.title}</p>
                    <p className="text-ivory/35 text-[10px] font-body mt-1 leading-relaxed">{objective.description}</p>
                  </div>
                  <Pill label={objective.achieved ? 'Cumprido' : 'Em curso'} variant={objective.achieved ? 'green' : 'amber'} />
                </div>
                <ProgressBar value={objective.progress} />
                <div className="flex justify-between text-[10px] text-ivory/35 font-body mt-2">
                  <span>Atual: {objective.currentValue.toLocaleString('pt-PT')}</span>
                  <span>Meta: {objective.target.toLocaleString('pt-PT')}</span>
                </div>
              </PaperCard>
            ))}
          </div>
        </div>

        <div className="overflow-y-auto pr-1">
          <SectionTitle>Relatórios Anuais</SectionTitle>
          {!latestReport ? (
            <EmptyState icon="📜" title="Sem relatórios" subtitle="O primeiro relatório será gerado ao fechar o Ano 1." />
          ) : (
            <div className="space-y-3">
              {state.annualReports.map(report => (
                <PaperCard key={report.id}>
                  <div className="flex items-center justify-between gap-3 mb-3">
                    <div>
                      <p className="font-display text-sm text-gold uppercase tracking-widest">Relatório {report.year}</p>
                      <p className="text-ivory/35 text-[10px] font-body">{report.prestigeTier} · {report.activeAnimals} animais ativos</p>
                    </div>
                    <Pill label={report.ranchStatus} variant={statusVariant[report.ranchStatus]} />
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs font-body mb-3">
                    <div className="border border-leather-600/25 rounded p-2">
                      <p className="text-ivory/35 text-[9px] uppercase tracking-wider">Resultado anual</p>
                      <p className={report.annualProfit >= 0 ? 'text-emerald-400' : 'text-red-400'}>
                        {report.annualProfit >= 0 ? '+' : ''}{formatEuro(report.annualProfit)}
                      </p>
                    </div>
                    <div className="border border-leather-600/25 rounded p-2">
                      <p className="text-ivory/35 text-[9px] uppercase tracking-wider">Moral média</p>
                      <p className="text-ivory/75">{report.staffAverageMorale}/100</p>
                    </div>
                  </div>

                  {report.objectiveResults.length > 0 && (
                    <div className="space-y-1.5 mb-3">
                      {report.objectiveResults.map(result => (
                        <div key={result.objectiveId} className="flex items-center justify-between gap-2 text-[10px] font-body">
                          <span className="text-ivory/55 truncate">{result.title}</span>
                          <Pill label={result.achieved ? 'OK' : 'Falhou'} variant={result.achieved ? 'green' : 'red'} />
                        </div>
                      ))}
                    </div>
                  )}

                  {report.notableEvents.length > 0 && (
                    <div className="border-t border-leather-600/25 pt-2">
                      <p className="text-ivory/30 text-[9px] uppercase tracking-wider font-body mb-1">Eventos marcantes</p>
                      <ul className="space-y-1">
                        {report.notableEvents.slice(0, 3).map((event, idx) => (
                          <li key={idx} className="text-ivory/55 text-[10px] font-body leading-snug">• {event}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                </PaperCard>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CampanhaTab;
