import React from 'react';
import { useGameState } from '../../store/gameState';
import { calculatePrestigeSnapshot } from '../../services/prestigeService';
import { SectionTitle, StatBlock, PaperCard, Pill } from './OfficePrimitives';

function tierVariant(tier: string): 'gold' | 'green' | 'amber' | 'sky' | 'muted' {
  if (tier === 'Lendária') return 'gold';
  if (tier === 'Internacional') return 'sky';
  if (tier === 'Nacional') return 'green';
  if (tier === 'Regional') return 'amber';
  return 'muted';
}

const MiniMeter: React.FC<{ value: number }> = ({ value }) => (
  <div className="h-2 bg-leather-700/50 rounded-full overflow-hidden">
    <div
      className="h-full bg-gold/70 rounded-full transition-all duration-700"
      style={{ width: `${Math.max(0, Math.min(100, value))}%` }}
    />
  </div>
);

const PrestigioTab: React.FC = () => {
  const { state } = useGameState();
  const snapshot = calculatePrestigeSnapshot(state);
  const pct = snapshot.score;
  const segments = 20;
  const trendLabel = snapshot.trend > 0 ? `+${snapshot.trend}` : `${snapshot.trend}`;
  const trendColor = snapshot.trend > 0 ? 'text-emerald-400' : snapshot.trend < 0 ? 'text-red-400' : 'text-ivory/45';

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <SectionTitle>Prestígio da Ganadaria</SectionTitle>

      <div className="bg-leather-800/40 border border-leather-600/40 rounded-lg p-5 mb-5 shrink-0">
        <div className="flex items-end gap-6">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-3">
              <p className="text-ivory/30 text-[10px] font-body uppercase tracking-wider">Prestígio Atual</p>
              <Pill label={snapshot.tier} variant={tierVariant(snapshot.tier)} />
            </div>
            <div className="flex gap-0.5 mb-2">
              {Array.from({ length: segments }).map((_, i) => (
                <div
                  key={i}
                  className={`flex-1 h-4 rounded-sm transition-all duration-700 ${
                    i < Math.round((pct / 100) * segments)
                      ? i < 7  ? 'bg-leather-500/70'
                      : i < 12 ? 'bg-amber-600/70'
                      : i < 17 ? 'bg-gold/70'
                      :          'bg-gold'
                      : 'bg-leather-700/40'
                  }`}
                />
              ))}
            </div>
            <div className="flex justify-between text-[9px] text-ivory/25 font-body">
              <span>Desconhecida</span>
              <span>Regional</span>
              <span>Nacional</span>
              <span>Internacional</span>
              <span>Lendária</span>
            </div>
          </div>
          <div className="text-right shrink-0">
            <p className="font-display text-4xl text-gold">{pct}</p>
            <p className="text-ivory/30 text-[10px] font-body uppercase tracking-wider">/ 100</p>
            <p className={`text-xs font-body mt-2 ${trendColor}`}>Tendência {trendLabel}</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-3 mb-5 shrink-0">
        <StatBlock label="Classificação Regional" value={snapshot.tier === 'Desconhecida' ? '—' : snapshot.tier} sub="Calculada pela reputação atual" />
        <StatBlock label="Tendência" value={<span className={trendColor}>{trendLabel}</span>} sub="Últimos eventos e economia" />
        <StatBlock label="Efetivo Ativo" value={state.animals.filter(animal => animal.status === 'Ativo').length} sub="Animais em produção" />
      </div>

      <div className="grid grid-cols-2 gap-5 flex-1 min-h-0">
        <div className="overflow-y-auto pr-1">
          <SectionTitle>Fatores de Prestígio</SectionTitle>
          <div className="space-y-3">
            {snapshot.breakdown.map(item => (
              <PaperCard key={item.id}>
                <div className="flex items-center justify-between gap-4 mb-2">
                  <div>
                    <p className="font-display text-sm text-ivory/80">{item.label}</p>
                    <p className="text-ivory/35 text-[10px] font-body mt-0.5">{item.description}</p>
                  </div>
                  <p className="font-display text-lg text-gold shrink-0">{item.value}</p>
                </div>
                <MiniMeter value={(item.value / item.max) * 100} />
              </PaperCard>
            ))}
          </div>
        </div>

        <div className="overflow-y-auto pr-1">
          <SectionTitle>Leitura da Casa</SectionTitle>
          <PaperCard className="mb-4">
            <p className="font-display text-gold text-sm uppercase tracking-widest mb-3">Diagnóstico</p>
            <div className="space-y-2">
              {snapshot.drivers.map(driver => (
                <p key={driver} className="text-ivory/60 text-xs font-body leading-relaxed border-b border-leather-600/20 last:border-b-0 pb-2 last:pb-0">
                  {driver}
                </p>
              ))}
            </div>
          </PaperCard>

          <SectionTitle>Conquistas</SectionTitle>
          <div className="space-y-2">
            <PaperCard>
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="font-display text-sm text-ivory/80">Casa Reconhecida</p>
                  <p className="text-ivory/35 text-[10px] font-body">Atingir 55 pontos de prestígio.</p>
                </div>
                <Pill label={pct >= 55 ? 'Desbloqueada' : 'Pendente'} variant={pct >= 55 ? 'green' : 'muted'} />
              </div>
            </PaperCard>
            <PaperCard>
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="font-display text-sm text-ivory/80">Nome Nacional</p>
                  <p className="text-ivory/35 text-[10px] font-body">Atingir 75 pontos de prestígio.</p>
                </div>
                <Pill label={pct >= 75 ? 'Desbloqueada' : 'Pendente'} variant={pct >= 75 ? 'green' : 'muted'} />
              </div>
            </PaperCard>
            <PaperCard>
              <div className="flex items-center justify-between gap-3">
                <div>
                  <p className="font-display text-sm text-ivory/80">Lenda da Casa</p>
                  <p className="text-ivory/35 text-[10px] font-body">Atingir 90 pontos de prestígio.</p>
                </div>
                <Pill label={pct >= 90 ? 'Desbloqueada' : 'Pendente'} variant={pct >= 90 ? 'green' : 'muted'} />
              </div>
            </PaperCard>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrestigioTab;
