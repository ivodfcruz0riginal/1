import React, { useMemo, useState } from 'react';
import { SectionTitle, PaperCard, StatBlock } from './OfficePrimitives';
import { useGameState } from '../../store/gameState';
import { deleteCampaignSave, getSaveSummary, loadCampaign, saveCampaign } from '../../services/saveService';
import { formatEuro } from '../../store/economyEngine';

function formatDate(value?: string): string {
  if (!value) return 'Sem registo';
  return new Intl.DateTimeFormat('pt-PT', {
    dateStyle: 'short',
    timeStyle: 'short',
  }).format(new Date(value));
}

const AdministracaoTab: React.FC = () => {
  const { state, loadGame } = useGameState();
  const [message, setMessage] = useState<string>('');
  const [summaryRefresh, setSummaryRefresh] = useState(0);

  const saveSummary = useMemo(() => getSaveSummary(), [summaryRefresh]);

  const refreshSummary = () => setSummaryRefresh(value => value + 1);

  const handleSave = () => {
    const save = saveCampaign(state);
    refreshSummary();
    setMessage(`Campanha guardada em ${formatDate(save.savedAt)}.`);
  };

  const handleLoad = () => {
    const save = loadCampaign();
    if (!save) {
      setMessage('Não existe campanha guardada.');
      return;
    }
    loadGame(save.state);
    refreshSummary();
    setMessage(`Campanha carregada: ${save.state.month} ${save.state.year}.`);
  };

  const handleDelete = () => {
    deleteCampaignSave();
    refreshSummary();
    setMessage('Campanha guardada apagada.');
  };

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <SectionTitle>Administração</SectionTitle>

      <div className="grid grid-cols-3 gap-4 mb-5">
        <StatBlock label="Campanha Atual" value={`${state.month} ${state.year}`} sub={state.season} />
        <StatBlock label="Tesouraria" value={formatEuro(state.economy.treasury)} sub="Estado financeiro atual" />
        <StatBlock label="Prestígio" value={state.prestige} sub="Reputação da casa" />
      </div>

      <div className="grid grid-cols-2 gap-5 flex-1 overflow-auto pr-1">
        <PaperCard className="flex flex-col gap-4">
          <div>
            <p className="font-display text-gold text-sm uppercase tracking-widest mb-1">Campanha</p>
            <p className="text-ivory/45 text-xs font-body leading-relaxed">
              Guarda, carrega ou apaga a campanha local. O autosave fica ativo e atualiza a campanha
              quando o estado principal muda.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              onClick={handleSave}
              className="bg-gold/15 border border-gold/45 text-gold rounded px-4 py-2 text-xs font-body uppercase tracking-wider hover:bg-gold/25 transition-colors"
            >
              Guardar Campanha
            </button>
            <button
              onClick={handleLoad}
              className="bg-leather-700/60 border border-leather-500/60 text-ivory/75 rounded px-4 py-2 text-xs font-body uppercase tracking-wider hover:border-gold/40 transition-colors"
            >
              Carregar
            </button>
            <button
              onClick={handleDelete}
              className="bg-red-950/25 border border-red-500/35 text-red-300 rounded px-4 py-2 text-xs font-body uppercase tracking-wider hover:bg-red-900/30 transition-colors"
            >
              Apagar Save
            </button>
          </div>

          {message && (
            <div className="border border-gold/20 bg-gold/5 rounded p-3 text-xs text-ivory/70 font-body">
              {message}
            </div>
          )}
        </PaperCard>

        <PaperCard>
          <p className="font-display text-gold text-sm uppercase tracking-widest mb-4">Último Save</p>
          {saveSummary.exists ? (
            <div className="space-y-3 text-xs font-body">
              <div className="flex justify-between border-b border-leather-600/25 pb-2">
                <span className="text-ivory/40">Guardado em</span>
                <span className="text-ivory/75">{formatDate(saveSummary.savedAt)}</span>
              </div>
              <div className="flex justify-between border-b border-leather-600/25 pb-2">
                <span className="text-ivory/40">Data de jogo</span>
                <span className="text-ivory/75">{saveSummary.month} {saveSummary.year}</span>
              </div>
              <div className="flex justify-between border-b border-leather-600/25 pb-2">
                <span className="text-ivory/40">Tesouraria</span>
                <span className="text-ivory/75">{formatEuro(saveSummary.treasury ?? 0)}</span>
              </div>
              <div className="flex justify-between border-b border-leather-600/25 pb-2">
                <span className="text-ivory/40">Prestígio</span>
                <span className="text-ivory/75">{saveSummary.prestige}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-ivory/40">Efetivo</span>
                <span className="text-ivory/75">{saveSummary.animals} animais</span>
              </div>
            </div>
          ) : (
            <p className="text-ivory/35 text-xs font-body">Ainda não existe campanha guardada.</p>
          )}
        </PaperCard>
      </div>
    </div>
  );
};

export default AdministracaoTab;
