import React, { useState, useMemo } from 'react';
import { useGameState } from '../../store/gameState';
import type { GameEvent } from '../../store/gameState';
import type { LocationId } from '../../types/location';
import type { NarrativeHistoryRecord } from '../../types/narrative';
import type { DayRecord } from '../../types/day';
import { DAY_PERIOD_LABELS } from '../../types/day';
import { SectionTitle, EmptyState } from './OfficePrimitives';

type FilterKey = 'Todos' | 'Animais' | 'Economia' | 'Pessoal' | 'Meteorologia' | 'Saúde' | 'Narrativa' | 'Dia';
type LocationFilterKey = 'Todos' | 'Sem local' | LocationId;

const FILTERS: FilterKey[] = ['Todos', 'Animais', 'Economia', 'Pessoal', 'Meteorologia', 'Saúde', 'Narrativa', 'Dia'];

const FILTER_KEYWORDS: Record<FilterKey, string[]> = {
  Todos: [],
  Animais: ['vitelo', 'animal', 'novilho', 'toiro', 'vaca', 'semental', 'efetivo', 'cercado', 'bravura', 'peso', 'saúde', 'sanitário', 'condição'],
  Economia: ['€', 'subsídio', 'receita', 'despesa', 'lucro', 'financ', 'econom', 'venda', 'compra', 'leilão', 'preço'],
  Pessoal: ['trabalhador', 'pessoal', 'reforma', 'visita', 'ganadeiro', 'veterinário', 'parceria', 'acordo', 'maioral', 'campino'],
  Meteorologia: ['seca', 'chuva', 'húmid', 'quente', 'frio', 'vento', 'tempo', 'pastage', 'feno'],
  Saúde: ['doença', 'saúde', 'veterinário', 'recuperação', 'lesão', 'sanitário', 'anomalia', 'respiratória'],
  Narrativa: [],
  Dia: [],
};

type DiarySource = 'event' | 'narrative' | 'day';

interface DiaryEntryModel {
  id: string;
  month: GameEvent['month'];
  year: number;
  text: string;
  locationId?: LocationId | null;
  source: DiarySource;
  characterId?: NarrativeHistoryRecord['characterId'];
  dayOfMonth?: DayRecord['dayOfMonth'];
  period?: DayRecord['period'];
}

function matchesFilter(entry: DiaryEntryModel, filter: FilterKey): boolean {
  if (filter === 'Todos') return true;
  if (filter === 'Narrativa') return entry.source === 'narrative';
  if (filter === 'Dia') return entry.source === 'day';
  const kw = FILTER_KEYWORDS[filter];
  const text = entry.text.toLowerCase();
  return kw.some(k => text.includes(k));
}

function matchesLocation(entry: DiaryEntryModel, locationFilter: LocationFilterKey): boolean {
  if (locationFilter === 'Todos') return true;
  if (locationFilter === 'Sem local') return !entry.locationId;
  return entry.locationId === locationFilter;
}

const DiarioEntry: React.FC<{
  entry: DiaryEntryModel;
  isFirst: boolean;
  locationName?: string;
}> = ({ entry, isFirst, locationName }) => (
  <div className={`flex items-start gap-4 p-3 rounded-lg border transition-all duration-200
    ${isFirst
      ? 'bg-gold/6 border-gold/20 shadow-sm'
      : 'bg-leather-800/20 border-leather-700/20 hover:bg-leather-800/40 hover:border-leather-600/40'
    }`}
  >
    <div className="shrink-0 w-12 text-center">
      <p className="text-gold/60 text-[9px] font-body uppercase tracking-widest leading-none">{entry.month.slice(0, 3)}</p>
      <p className="text-ivory/40 text-[11px] font-display mt-0.5">{entry.year}</p>
    </div>
    <div className="w-px self-stretch bg-gradient-to-b from-gold/20 via-leather-600/30 to-transparent shrink-0" />
    <div className="flex-1 min-w-0">
      <div className="flex items-center gap-2 mb-1 flex-wrap">
        {locationName && (
          <span className="px-2 py-0.5 rounded-full bg-leather-900/50 border border-leather-600/30 text-[9px] text-gold/70 font-body uppercase tracking-wider">
            {locationName}
          </span>
        )}
        {entry.source === 'day' && entry.dayOfMonth && entry.period && (
          <span className="px-2 py-0.5 rounded-full bg-emerald-500/10 border border-emerald-400/20 text-[9px] text-emerald-200/75 font-body uppercase tracking-wider">
            Dia {entry.dayOfMonth} · {DAY_PERIOD_LABELS[entry.period]}
          </span>
        )}
        {entry.source === 'narrative' && (
          <span className="px-2 py-0.5 rounded-full bg-gold/10 border border-gold/20 text-[9px] text-gold/80 font-body uppercase tracking-wider">
            Diálogo
          </span>
        )}
      </div>
      <p className={`text-sm font-body leading-relaxed ${isFirst ? 'text-ivory' : 'text-ivory/75'}`}>
        {entry.text}
      </p>
    </div>
  </div>
);

const DiarioTab: React.FC = () => {
  const { state } = useGameState();
  const [activeFilter, setActiveFilter] = useState<FilterKey>('Todos');
  const [locationFilter, setLocationFilter] = useState<LocationFilterKey>('Todos');

  const locationNameById = useMemo(
    () => new Map(state.locations.map(location => [location.id, location.name])),
    [state.locations],
  );

  const entries = useMemo<DiaryEntryModel[]>(() => {
    const eventEntries: DiaryEntryModel[] = state.eventLog.map(event => ({
      id: event.id,
      month: event.month,
      year: event.year,
      text: event.text,
      locationId: event.locationId ?? null,
      source: 'event',
    }));

    const narrativeEntries: DiaryEntryModel[] = state.narrativeHistory.map(record => ({
      id: record.id,
      month: record.month,
      year: record.year,
      text: `${record.resultText} Escolha: ${record.choice}`,
      locationId: record.locationId ?? null,
      source: 'narrative',
      characterId: record.characterId,
    }));

    const dayEntries: DiaryEntryModel[] = (state.dayLog ?? []).map(record => ({
      id: record.id,
      month: record.month as GameEvent['month'],
      year: record.year,
      text: `${record.title} — ${record.description}`,
      locationId: record.locationId ?? null,
      source: 'day',
      dayOfMonth: record.dayOfMonth,
      period: record.period,
    }));

    return [...dayEntries, ...eventEntries, ...narrativeEntries];
  }, [state.eventLog, state.narrativeHistory, state.dayLog]);

  const filtered = useMemo(
    () => entries.filter(entry => matchesFilter(entry, activeFilter) && matchesLocation(entry, locationFilter)),
    [entries, activeFilter, locationFilter],
  );

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <SectionTitle>Diário da Herdade</SectionTitle>

      <div className="space-y-3 mb-4 shrink-0">
        <div className="flex items-center gap-1.5 flex-wrap">
          {FILTERS.map(f => (
            <button
              key={f}
              onClick={() => setActiveFilter(f)}
              className={`px-3 py-1 rounded-full text-[11px] font-body border transition-all duration-150 ${
                activeFilter === f
                  ? 'bg-gold/15 border-gold/50 text-gold'
                  : 'bg-leather-800/30 border-leather-600/30 text-ivory/50 hover:text-ivory/70 hover:border-leather-500/50'
              }`}
            >
              {f}
            </button>
          ))}
          <span className="ml-auto text-ivory/25 text-[10px] font-body">{filtered.length} entradas</span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-ivory/35 text-[10px] font-body uppercase tracking-wider">Quadro</span>
          <select
            value={locationFilter}
            onChange={event => setLocationFilter(event.target.value as LocationFilterKey)}
            className="bg-leather-900/70 border border-leather-600/40 rounded-lg px-3 py-1.5 text-xs text-ivory/75 font-body outline-none focus:border-gold/50"
          >
            <option value="Todos">Todos os quadros</option>
            <option value="Sem local">Sem local</option>
            {state.locations.map(location => (
              <option key={location.id} value={location.id}>{location.name}</option>
            ))}
          </select>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-1.5 pr-1">
        {filtered.length === 0
          ? <EmptyState icon="📋" title="Sem entradas" subtitle="Nenhum evento corresponde aos filtros seleccionados." />
          : filtered.map((entry, idx) => (
            <DiarioEntry
              key={entry.id}
              entry={entry}
              isFirst={idx === 0}
              locationName={entry.locationId ? locationNameById.get(entry.locationId) : undefined}
            />
          ))
        }
      </div>
    </div>
  );
};

export default DiarioTab;
