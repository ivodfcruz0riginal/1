import React, { useMemo, useState } from 'react';
import { useGameState } from '../../store/gameState';
import { SectionTitle, PaperCard, Pill, EmptyState, StatBlock } from './OfficePrimitives';
import {
  createChronicleEntries,
  describeChronicleScope,
  describeChronicleTone,
  getChronicleHighlights,
  getOpenChronicleThreads,
  type ChronicleScope,
} from '../../services/chronicleService';
import { createLineageSummaries } from '../../services/lineageService';

const FOUNDING_MILESTONES = [
  { year: 1947, text: 'Fundação da Herdade da Ferraria por D. João Nobre da Costa.' },
  { year: 1952, text: 'Primeira corrida com animais da ganadaria na Praça de Lisboa.' },
  { year: 1971, text: 'Construção do atual tentadero.' },
  { year: 1985, text: 'A casa passa para a geração atual com prestígio respeitado, mas contas delicadas.' },
];

const SCOPE_FILTERS: Array<'Todos' | ChronicleScope> = ['Todos', 'dia', 'campanha', 'linhagem', 'pessoal', 'territorio', 'economia'];

function pillVariantForTone(tone: string): 'gold' | 'green' | 'amber' | 'red' | 'sky' | 'rose' | 'muted' {
  if (tone === 'triunfo') return 'gold';
  if (tone === 'alerta') return 'amber';
  if (tone === 'risco') return 'red';
  if (tone === 'rotina') return 'muted';
  return 'sky';
}

const LivroTab: React.FC = () => {
  const { state } = useGameState();
  const [scopeFilter, setScopeFilter] = useState<'Todos' | ChronicleScope>('Todos');

  const chronicles = useMemo(() => createChronicleEntries(state), [state]);
  const highlights = useMemo(() => getChronicleHighlights(state), [state]);
  const openThreads = useMemo(() => getOpenChronicleThreads(state), [state]);
  const lineages = useMemo(() => createLineageSummaries(state.animals), [state.animals]);
  const locationNameById = useMemo(() => new Map(state.locations.map(location => [location.id, location.name])), [state.locations]);
  const filteredChronicles = scopeFilter === 'Todos'
    ? chronicles
    : chronicles.filter(entry => entry.scope === scopeFilter);

  const topLineage = lineages[0];
  const endangeredLineages = lineages.filter(lineage => lineage.riskLevel === 'alto').length;

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <SectionTitle>Crónicas da Herdade — Herdade da Ferraria</SectionTitle>

      <div className="grid grid-cols-4 gap-3 mb-5 shrink-0">
        <StatBlock label="Fundação" value="1947" sub="Casa recebida, não criada" />
        <StatBlock label="Efectivo" value={state.animals.length} sub="Animais registados" />
        <StatBlock label="Linha Dominante" value={topLineage?.name ?? '—'} sub={topLineage ? `${topLineage.influenceScore}/100 influência` : 'Sem leitura'} />
        <StatBlock label="Linhas em Risco" value={endangeredLineages} sub="Requerem proteção genética" />
      </div>

      <div className="flex-1 overflow-y-auto pr-1 space-y-6">
        <div>
          <SectionTitle>Assuntos vivos</SectionTitle>
          {openThreads.length === 0 ? (
            <PaperCard>
              <p className="text-ivory/55 text-sm font-body leading-relaxed">
                Não há responsabilidades pendentes de relevo. A casa respira com normalidade, mas o campo nunca fica parado.
              </p>
            </PaperCard>
          ) : (
            <div className="grid grid-cols-2 gap-3">
              {openThreads.map(thread => (
                <PaperCard key={thread.id}>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <p className="font-display text-sm text-ivory/85">{thread.title}</p>
                    <Pill label={describeChronicleTone(thread.tone)} variant={pillVariantForTone(thread.tone)} />
                  </div>
                  <p className="text-ivory/55 text-xs font-body leading-relaxed">{thread.text}</p>
                  {thread.locationId && (
                    <p className="text-gold/45 text-[10px] font-body uppercase tracking-wider mt-3">
                      {locationNameById.get(thread.locationId) ?? thread.locationId}
                    </p>
                  )}
                </PaperCard>
              ))}
            </div>
          )}
        </div>

        <div>
          <SectionTitle>Marcos recentes da casa</SectionTitle>
          {highlights.length === 0 ? (
            <EmptyState icon="📚" title="Sem marcos recentes" subtitle="As grandes memórias da campanha aparecerão aqui." />
          ) : (
            <div className="space-y-2">
              {highlights.map(entry => (
                <PaperCard key={entry.id}>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-gold/55 text-[10px] font-body uppercase tracking-widest mb-1">
                        {entry.dayOfMonth ? `Dia ${entry.dayOfMonth} · ` : ''}{entry.month} {entry.year}
                      </p>
                      <p className="font-display text-sm text-ivory/85">{entry.title}</p>
                    </div>
                    <div className="flex gap-1.5 shrink-0">
                      <Pill label={describeChronicleScope(entry.scope)} variant="muted" />
                      <Pill label={describeChronicleTone(entry.tone)} variant={pillVariantForTone(entry.tone)} />
                    </div>
                  </div>
                  <p className="text-ivory/58 text-xs font-body leading-relaxed mt-2">{entry.text}</p>
                </PaperCard>
              ))}
            </div>
          )}
        </div>

        <div>
          <SectionTitle>Livro genealógico vivo</SectionTitle>
          <div className="grid grid-cols-2 gap-3">
            {lineages.slice(0, 4).map(lineage => (
              <PaperCard key={lineage.id}>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <p className="font-display text-sm text-gold">{lineage.name}</p>
                  <Pill
                    label={lineage.riskLevel === 'alto' ? 'Risco' : lineage.riskLevel === 'medio' ? 'A vigiar' : 'Estável'}
                    variant={lineage.riskLevel === 'alto' ? 'red' : lineage.riskLevel === 'medio' ? 'amber' : 'green'}
                  />
                </div>
                <p className="text-ivory/55 text-xs font-body leading-relaxed mb-3">{lineage.note}</p>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="rounded border border-leather-600/25 bg-black/10 p-2">
                    <p className="text-ivory/30 text-[9px] uppercase tracking-wider">Ativos</p>
                    <p className="text-ivory/75 font-display text-sm">{lineage.activeAnimals}</p>
                  </div>
                  <div className="rounded border border-leather-600/25 bg-black/10 p-2">
                    <p className="text-ivory/30 text-[9px] uppercase tracking-wider">Reprod.</p>
                    <p className="text-ivory/75 font-display text-sm">{lineage.breedingAnimals}</p>
                  </div>
                  <div className="rounded border border-leather-600/25 bg-black/10 p-2">
                    <p className="text-ivory/30 text-[9px] uppercase tracking-wider">Influência</p>
                    <p className="text-ivory/75 font-display text-sm">{lineage.influenceScore}</p>
                  </div>
                </div>
              </PaperCard>
            ))}
          </div>
        </div>

        <div>
          <SectionTitle>Arquivo da campanha</SectionTitle>
          <div className="flex items-center gap-1.5 flex-wrap mb-3">
            {SCOPE_FILTERS.map(scope => (
              <button
                key={scope}
                onClick={() => setScopeFilter(scope)}
                className={`px-3 py-1 rounded-full text-[11px] font-body border transition-all duration-150 ${
                  scopeFilter === scope
                    ? 'bg-gold/15 border-gold/50 text-gold'
                    : 'bg-leather-800/30 border-leather-600/30 text-ivory/50 hover:text-ivory/70 hover:border-leather-500/50'
                }`}
              >
                {scope === 'Todos' ? 'Todos' : describeChronicleScope(scope)}
              </button>
            ))}
          </div>
          <div className="relative pl-5">
            <div className="absolute left-0 top-2 bottom-2 w-px bg-gradient-to-b from-gold/30 via-leather-600/30 to-transparent" />
            <div className="space-y-3">
              {filteredChronicles.length === 0 ? (
                <EmptyState icon="🕯️" title="Sem crónicas" subtitle="Ainda não há memória registada para este filtro." />
              ) : filteredChronicles.slice(0, 30).map(entry => (
                <div key={entry.id} className="relative rounded-lg border border-leather-700/30 bg-leather-800/20 p-3">
                  <div className="absolute -left-5 top-4 w-2 h-2 rounded-full border border-gold/40 bg-leather-900" />
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-gold/55 font-display text-[10px] uppercase tracking-widest mb-0.5">
                        {entry.dayOfMonth ? `Dia ${entry.dayOfMonth} · ` : ''}{entry.month} {entry.year}
                      </p>
                      <p className="text-ivory/78 text-sm font-display">{entry.title}</p>
                    </div>
                    <div className="flex gap-1.5 shrink-0">
                      <Pill label={describeChronicleScope(entry.scope)} variant="muted" />
                      <Pill label={describeChronicleTone(entry.tone)} variant={pillVariantForTone(entry.tone)} />
                    </div>
                  </div>
                  <p className="text-ivory/55 text-xs font-body leading-relaxed mt-2">{entry.text}</p>
                  {entry.locationId && (
                    <p className="text-ivory/30 text-[10px] font-body uppercase tracking-wider mt-2">
                      {locationNameById.get(entry.locationId) ?? entry.locationId}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        <div>
          <SectionTitle>Memória antiga da casa</SectionTitle>
          <div className="relative pl-5">
            <div className="absolute left-0 top-2 bottom-2 w-px bg-gradient-to-b from-gold/20 via-leather-600/20 to-transparent" />
            <div className="space-y-3">
              {FOUNDING_MILESTONES.map(m => (
                <div key={m.year} className="relative">
                  <div className="absolute -left-5 top-1.5 w-2 h-2 rounded-full border border-gold/30 bg-leather-900" />
                  <p className="text-gold/45 font-display text-[10px] uppercase tracking-widest mb-0.5">{m.year}</p>
                  <p className="text-ivory/45 text-xs font-body leading-relaxed">{m.text}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LivroTab;
