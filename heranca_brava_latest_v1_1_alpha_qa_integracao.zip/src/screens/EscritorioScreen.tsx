import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useGameState } from '../store/gameState';
import DiarioTab from './office/DiarioTab';
import JornalTab from './office/JornalTab';
import EconomiaTab from './office/EconomiaTab';
import CalendarioTab from './office/CalendarioTab';
import ContratosTab from './office/ContratosTab';
import LivroTab from './office/LivroTab';
import PrestigioTab from './office/PrestigioTab';
import AdministracaoTab from './office/AdministracaoTab';
import PessoalTab from './office/PessoalTab';
import CampanhaTab from './office/CampanhaTab';
import { DAY_PERIOD_LABELS } from '../types/day';
import { getDayPressure } from '../services/dayCycleService';
import { getAlphaNextStep, getAlphaStoryThreads } from '../services/alphaIntegrationService';
import { createAlphaQaSnapshot } from '../services/alphaQaService';

// ── Tab config ────────────────────────────────────────────────────────────────

type TabKey = 'diario' | 'jornal' | 'economia' | 'calendario' | 'contratos' | 'pessoal' | 'campanha' | 'livro' | 'prestigio' | 'administracao';

const TABS: { key: TabKey; icon: string; label: string }[] = [
  { key: 'diario',        icon: '📖', label: 'Diário' },
  { key: 'jornal',        icon: '📰', label: 'Jornal' },
  { key: 'economia',      icon: '💰', label: 'Economia' },
  { key: 'calendario',    icon: '📅', label: 'Calendário' },
  { key: 'contratos',     icon: '📜', label: 'Contratos' },
  { key: 'pessoal',       icon: '👥', label: 'Pessoal' },
  { key: 'campanha',     icon: '🎯', label: 'Campanha' },
  { key: 'livro',         icon: '📚', label: 'Livro da Casa' },
  { key: 'prestigio',     icon: '🏆', label: 'Prestígio' },
  { key: 'administracao', icon: '⚙️', label: 'Administração' },
];

// ── Office wall decorations ───────────────────────────────────────────────────

const WallDecoration: React.FC = () => (
  <div className="absolute inset-0 pointer-events-none overflow-hidden">
    {/* Wood wainscoting at bottom */}
    <div className="absolute bottom-0 inset-x-0 h-24 bg-gradient-to-t from-amber-950/25 to-transparent" />

    {/* Bull painting – top left */}
    <div className="absolute top-6 left-6 w-20 h-16 opacity-20">
      <div className="w-full h-full bg-leather-700/60 border border-leather-500/30 rounded flex items-center justify-center">
        <span className="text-3xl">🐂</span>
      </div>
      {/* Frame */}
      <div className="absolute -inset-1 border border-gold/20 rounded pointer-events-none" />
      <div className="absolute -inset-2 border border-leather-600/20 rounded pointer-events-none" />
    </div>

    {/* Map sketch – top right */}
    <div className="absolute top-5 right-5 w-24 h-18 opacity-15">
      <div className="w-full h-full bg-amber-950/40 border border-leather-500/20 rounded p-1.5">
        <svg viewBox="0 0 100 80" className="w-full h-full">
          <rect x="10" y="10" width="80" height="60" fill="none" stroke="#c9a227" strokeWidth="1" opacity="0.5" />
          <path d="M10,40 Q30,35 50,40 Q70,45 90,40" fill="none" stroke="#c9a227" strokeWidth="0.8" opacity="0.4" />
          <path d="M50,10 Q48,25 50,40 Q52,55 50,70" fill="none" stroke="#c9a227" strokeWidth="0.8" opacity="0.4" />
          <circle cx="50" cy="40" r="3" fill="#c9a227" opacity="0.4" />
          <text x="52" y="38" fontSize="6" fill="#c9a227" opacity="0.5">HF</text>
        </svg>
      </div>
      <div className="absolute -inset-1 border border-gold/15 rounded pointer-events-none" />
    </div>

    {/* Bookshelf hint – right side centre */}
    <div className="absolute top-1/2 -translate-y-1/2 right-3 flex flex-col gap-0.5 opacity-10">
      {['bg-amber-800/60', 'bg-leather-600/60', 'bg-amber-900/60', 'bg-leather-700/60', 'bg-amber-700/60'].map((c, i) => (
        <div key={i} className={`w-3 ${c} rounded-sm`} style={{ height: `${28 + i * 4}px` }} />
      ))}
    </div>

    {/* Subtle vignette */}
    <div className="absolute inset-0 bg-gradient-to-br from-black/10 via-transparent to-black/15" />
  </div>
);

// ── Tab navigation ────────────────────────────────────────────────────────────

interface TabBarProps {
  active: TabKey;
  onChange: (key: TabKey) => void;
}

const TabBar: React.FC<TabBarProps> = ({ active, onChange }) => (
  <div className="flex items-end gap-0 overflow-x-auto shrink-0 border-b border-leather-700/50">
    {TABS.map(tab => (
      <button
        key={tab.key}
        onClick={() => onChange(tab.key)}
        className={`relative flex items-center gap-1.5 px-4 py-3 text-xs font-body whitespace-nowrap transition-all duration-200 border-b-2 ${
          active === tab.key
            ? 'border-gold text-gold bg-gradient-to-t from-gold/8 to-transparent'
            : 'border-transparent text-ivory/45 hover:text-ivory/70 hover:bg-leather-700/20'
        }`}
      >
        <span className="text-sm">{tab.icon}</span>
        <span className="uppercase tracking-wider text-[11px]">{tab.label}</span>
      </button>
    ))}
  </div>
);



// ── Day flow panel ───────────────────────────────────────────────────────────

function pressureLabel(pressure: string): string {
  switch (pressure) {
    case 'critico': return 'Crítico';
    case 'exigente': return 'Exigente';
    case 'calmo': return 'Calmo';
    default: return 'Normal';
  }
}

function pressureClass(pressure: string): string {
  switch (pressure) {
    case 'critico': return 'border-red-500/45 text-red-200/80 bg-red-950/20';
    case 'exigente': return 'border-amber-400/45 text-amber-100/80 bg-amber-950/20';
    case 'calmo': return 'border-emerald-400/35 text-emerald-100/70 bg-emerald-950/15';
    default: return 'border-gold/25 text-gold/75 bg-gold/8';
  }
}

const DayFlowPanel: React.FC = () => {
  const { state, advanceDayPeriod, closeDay } = useGameState();
  const pendingMeetings = state.morningCouncil.filter(item => item.status === 'pending').length;
  const pendingTasks = state.dailyTasks.filter(task => task.status === 'pending').length;
  const completedTasks = state.dailyTasks.filter(task => task.status === 'completed').length;
  const visitsToday = (state.dayLog ?? []).filter(record => record.dayOfMonth === state.dayOfMonth && record.type === 'location_visit').length;
  const pressure = getDayPressure(state);
  const canAdvancePeriod = state.dayPeriod !== 'noite';

  return (
    <div className="mb-4 rounded-lg border border-leather-700/35 bg-black/15 px-4 py-3">
      <div className="flex items-center justify-between gap-4 flex-wrap">
        <div>
          <p className="text-gold/80 text-xs font-display uppercase tracking-widest">Dia na Herdade</p>
          <p className="text-ivory/50 text-xs font-body mt-1">
            Dia {state.dayOfMonth} de {state.month} · {DAY_PERIOD_LABELS[state.dayPeriod]}
          </p>
        </div>
        <div className={`rounded-full border px-3 py-1 text-[10px] font-body uppercase tracking-wider ${pressureClass(pressure)}`}>
          Pressão: {pressureLabel(pressure)}
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3">
        <div className="rounded border border-leather-600/25 bg-leather-900/25 px-3 py-2">
          <p className="text-ivory/30 text-[9px] uppercase tracking-wider font-body">Assuntos pendentes</p>
          <p className="text-ivory/75 text-sm font-display">{pendingMeetings}</p>
        </div>
        <div className="rounded border border-leather-600/25 bg-leather-900/25 px-3 py-2">
          <p className="text-ivory/30 text-[9px] uppercase tracking-wider font-body">Tarefas pendentes</p>
          <p className="text-ivory/75 text-sm font-display">{pendingTasks}</p>
        </div>
        <div className="rounded border border-leather-600/25 bg-leather-900/25 px-3 py-2">
          <p className="text-ivory/30 text-[9px] uppercase tracking-wider font-body">Tarefas feitas</p>
          <p className="text-ivory/75 text-sm font-display">{completedTasks}/{state.dailyTasks.length}</p>
        </div>
        <div className="rounded border border-leather-600/25 bg-leather-900/25 px-3 py-2">
          <p className="text-ivory/30 text-[9px] uppercase tracking-wider font-body">Deslocações</p>
          <p className="text-ivory/75 text-sm font-display">{visitsToday}</p>
        </div>
      </div>

      <div className="flex items-center gap-2 mt-3">
        <button
          onClick={advanceDayPeriod}
          disabled={!canAdvancePeriod}
          className={`px-3 py-1.5 rounded border text-[10px] font-body uppercase tracking-wider transition-colors ${canAdvancePeriod ? 'border-gold/35 text-gold/75 hover:border-gold hover:text-gold hover:bg-gold/10' : 'border-leather-600/20 text-ivory/20 cursor-not-allowed'}`}
        >
          Avançar Período
        </button>
        <button
          onClick={closeDay}
          className="px-3 py-1.5 rounded border border-amber-300/35 text-amber-100/75 text-[10px] font-body uppercase tracking-wider hover:border-amber-200 hover:text-amber-100 hover:bg-amber-200/10 transition-colors"
        >
          Fechar Dia
        </button>
        {(pendingMeetings > 0 || pendingTasks > 0) && (
          <p className="text-ivory/35 text-[10px] font-body">
            Fechar o dia agora transforma o que ficou pendente em memória e registo no diário.
          </p>
        )}
      </div>
    </div>
  );
};


// ── Alpha integration panel ───────────────────────────────────────────────────

function alphaUrgencyClass(urgency: string): string {
  switch (urgency) {
    case 'critica': return 'border-red-500/45 bg-red-950/20 text-red-100/85';
    case 'alta': return 'border-amber-400/40 bg-amber-950/20 text-amber-100/85';
    case 'normal': return 'border-gold/25 bg-gold/8 text-ivory/75';
    default: return 'border-leather-600/30 bg-black/10 text-ivory/50';
  }
}

const AlphaFirstPlayPanel: React.FC = () => {
  const { state, setActiveLocation } = useGameState();
  const nextStep = getAlphaNextStep(state);
  const threads = getAlphaStoryThreads(state, 4);

  return (
    <div className="mb-4 rounded-lg border border-gold/20 bg-gradient-to-br from-black/20 to-leather-900/30 px-4 py-3">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-gold/80 text-xs font-display uppercase tracking-widest">Fio do Dia</p>
          <p className="text-ivory/45 text-xs font-body mt-1">
            A build Alpha liga Conselho, Quadro, Diário e Crónicas. O objetivo não é fazer tudo: é não perder o fio da herdade.
          </p>
        </div>
        <div className={`rounded border px-3 py-1 text-[10px] font-body uppercase tracking-wider ${alphaUrgencyClass(nextStep.urgency)}`}>
          {nextStep.urgency}
        </div>
      </div>

      <div className="mt-3 rounded border border-leather-600/25 bg-leather-900/25 p-3">
        <p className="text-ivory/30 text-[9px] uppercase tracking-wider font-body">Próximo passo sugerido</p>
        <p className="text-gold/85 text-sm font-display mt-1">{nextStep.title}</p>
        <p className="text-ivory/50 text-xs font-body leading-relaxed mt-1">{nextStep.description}</p>
        {nextStep.locationId && nextStep.locationId !== 'escritorio' && (
          <button
            onClick={() => setActiveLocation(nextStep.locationId ?? null)}
            className="mt-2 px-3 py-1.5 rounded border border-gold/30 text-gold/80 text-[10px] font-body uppercase tracking-wider hover:border-gold hover:bg-gold/10 transition-colors"
          >
            Ir ao quadro
          </button>
        )}
      </div>

      {threads.length > 0 && (
        <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2">
          {threads.map(thread => (
            <div key={thread.id} className="rounded border border-leather-600/20 bg-black/10 px-3 py-2">
              <div className="flex items-center justify-between gap-2">
                <p className="text-ivory/70 text-xs font-display truncate">{thread.title}</p>
                <span className="text-[9px] text-gold/45 uppercase tracking-wider font-body">{thread.source}</span>
              </div>
              <p className="text-ivory/40 text-[11px] font-body leading-relaxed mt-1 line-clamp-2">{thread.description}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};


// ── Alpha QA panel ───────────────────────────────────────────────────────────

function qaStatusClass(status: string): string {
  switch (status) {
    case 'aprovado': return 'border-emerald-400/35 text-emerald-100/75 bg-emerald-950/15';
    case 'afinar': return 'border-amber-400/40 text-amber-100/80 bg-amber-950/20';
    default: return 'border-red-500/45 text-red-100/80 bg-red-950/20';
  }
}

const AlphaQaPanel: React.FC = () => {
  const { state } = useGameState();
  const qa = createAlphaQaSnapshot(state);

  return (
    <div className="mb-4 rounded-lg border border-leather-700/35 bg-black/15 px-4 py-3">
      <div className="flex items-start justify-between gap-4">
        <div>
          <p className="text-gold/80 text-xs font-display uppercase tracking-widest">Alpha QA · Integração</p>
          <p className="text-ivory/45 text-xs font-body mt-1">{qa.summary}</p>
        </div>
        <div className={`rounded border px-3 py-1 text-[10px] font-body uppercase tracking-wider ${qaStatusClass(qa.status)}`}>
          {qa.score}% · {qa.status}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-2 mt-3">
        {qa.checks.map(check => (
          <div key={check.id} className={`rounded border px-3 py-2 ${qaStatusClass(check.status)}`}>
            <div className="flex items-center justify-between gap-2">
              <p className="text-xs font-display text-ivory/80">{check.title}</p>
              <span className="text-[9px] uppercase tracking-wider font-body">{check.status}</span>
            </div>
            <p className="text-[11px] font-body leading-relaxed text-ivory/50 mt-1">{check.description}</p>
            {check.action && <p className="text-[10px] font-body leading-relaxed text-gold/55 mt-1">Ação: {check.action}</p>}
          </div>
        ))}
      </div>
    </div>
  );
};

// ── Morning Council ──────────────────────────────────────────────────────────

function urgencyClass(urgency: string): string {
  switch (urgency) {
    case 'critica': return 'border-red-500/45 bg-red-950/20 text-red-200/85';
    case 'alta': return 'border-amber-500/45 bg-amber-950/20 text-amber-100/85';
    case 'normal': return 'border-gold/30 bg-gold/8 text-ivory/75';
    default: return 'border-leather-600/35 bg-black/10 text-ivory/55';
  }
}

interface MorningCouncilPanelProps {
  onOpenTab: (tab: TabKey) => void;
}

const MorningCouncilPanel: React.FC<MorningCouncilPanelProps> = ({ onOpenTab }) => {
  const { state, attendMorningMeeting, postponeMorningMeeting, resolveProfessionalConflict } = useGameState();
  const pendingMeetings = (state.morningCouncil ?? []).filter(item => item.status === 'pending');

  if (pendingMeetings.length === 0) {
    return (
      <div className="mb-4 rounded-lg border border-leather-700/35 bg-black/15 px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full border border-gold/20 bg-leather-800/50 flex items-center justify-center text-sm">☕</div>
          <div>
            <p className="text-gold/80 text-xs font-display uppercase tracking-widest">Conselho da Manhã</p>
            <p className="text-ivory/45 text-xs font-body mt-0.5">Hoje ninguém ficou à espera no escritório. A casa segue em rotina.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mb-4 rounded-lg border border-gold/25 bg-gradient-to-br from-leather-900/60 to-black/25 p-4 shadow-lg">
      <div className="flex items-start justify-between gap-4 mb-3">
        <div>
          <p className="text-gold text-xs font-display uppercase tracking-[0.22em]">Conselho da Manhã</p>
          <p className="text-ivory/45 text-xs font-body mt-1">
            {pendingMeetings.length} assunto(s) à espera no escritório. Atender primeiro também é uma decisão.
          </p>
        </div>
        <div className="text-right text-[10px] text-ivory/30 font-body uppercase tracking-widest">
          {state.month} {state.year}
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-3">
        {pendingMeetings.map(meeting => (
          <div key={meeting.id} className={`rounded border px-3 py-3 ${urgencyClass(meeting.urgency)}`}>
            <div className="flex items-start gap-3">
              <div className="w-9 h-9 rounded-full bg-leather-800/60 border border-gold/20 flex items-center justify-center shrink-0">
                <span className="text-lg">{meeting.characterId === 'maioral' ? '🐎' : meeting.characterId === 'veterinario' ? '⚕️' : meeting.characterId === 'administrador' ? '📒' : meeting.characterId === 'empresario' ? '📜' : '👤'}</span>
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <p className="text-ivory/85 text-sm font-display leading-none">{meeting.characterName}</p>
                  <span className="text-[9px] uppercase tracking-widest text-gold/45 font-body">{meeting.role}</span>
                </div>
                <p className="text-gold/75 text-xs font-body mt-2">{meeting.title}</p>
                <p className="text-ivory/55 text-xs font-body leading-relaxed mt-1.5">{meeting.summary}</p>
                {meeting.availabilityNote && (
                  <p className="text-ivory/35 text-[11px] font-body leading-relaxed mt-1.5 italic">Agenda: {meeting.availabilityNote}</p>
                )}
                {meeting.substituteFor && (
                  <p className="text-amber-200/50 text-[10px] font-body uppercase tracking-wider mt-1">Assunto trazido por substituição</p>
                )}
                {meeting.professionalConflict && (
                  <div className="mt-3 rounded border border-amber-400/25 bg-black/20 p-3 space-y-2">
                    <p className="text-amber-100/70 text-[10px] font-body uppercase tracking-[0.18em]">Pareceres em conflito</p>
                    <p className="text-ivory/60 text-[11px] leading-relaxed"><span className="text-gold/70">{meeting.professionalConflict.primaryCharacterName}:</span> {meeting.professionalConflict.primaryLine}</p>
                    <p className="text-ivory/60 text-[11px] leading-relaxed"><span className="text-gold/70">{meeting.professionalConflict.secondaryCharacterName}:</span> {meeting.professionalConflict.secondaryLine}</p>
                    <p className="text-ivory/35 text-[11px] italic">Risco: {meeting.professionalConflict.stakes}</p>
                    {meeting.professionalConflict.memoryHint && (
                      <p className="text-ivory/30 text-[10px]">Memória: {meeting.professionalConflict.memoryHint}</p>
                    )}
                  </div>
                )}
              </div>
            </div>

            {meeting.professionalConflict ? (
              <div className="mt-3 grid grid-cols-1 gap-2">
                <button
                  onClick={() => {
                    resolveProfessionalConflict(meeting.id, 'primary');
                    if (meeting.recommendedTab) onOpenTab(meeting.recommendedTab as TabKey);
                  }}
                  className="px-3 py-2 rounded border border-gold/35 hover:border-gold/70 hover:bg-gold/10 text-gold/85 text-[11px] font-body uppercase tracking-wider transition-colors"
                >
                  {meeting.professionalConflict.primaryChoiceLabel}
                </button>
                <button
                  onClick={() => {
                    resolveProfessionalConflict(meeting.id, 'secondary');
                    if (meeting.recommendedTab) onOpenTab(meeting.recommendedTab as TabKey);
                  }}
                  className="px-3 py-2 rounded border border-amber-300/30 hover:border-amber-200/60 hover:bg-amber-200/10 text-amber-100/80 text-[11px] font-body uppercase tracking-wider transition-colors"
                >
                  {meeting.professionalConflict.secondaryChoiceLabel}
                </button>
                <button
                  onClick={() => postponeMorningMeeting(meeting.id)}
                  className="px-3 py-2 rounded border border-leather-600/35 hover:border-ivory/30 hover:bg-ivory/5 text-ivory/45 text-[11px] font-body uppercase tracking-wider transition-colors"
                >
                  Adiar conflito
                </button>
              </div>
            ) : (
              <div className="mt-3 flex gap-2">
                <button
                  onClick={() => {
                    attendMorningMeeting(meeting.id);
                    if (meeting.recommendedTab) onOpenTab(meeting.recommendedTab as TabKey);
                  }}
                  className="flex-1 px-3 py-2 rounded border border-gold/35 hover:border-gold/70 hover:bg-gold/10 text-gold/85 text-[11px] font-body uppercase tracking-wider transition-colors"
                >
                  Atender
                </button>
                <button
                  onClick={() => postponeMorningMeeting(meeting.id)}
                  className="px-3 py-2 rounded border border-leather-600/35 hover:border-ivory/30 hover:bg-ivory/5 text-ivory/45 text-[11px] font-body uppercase tracking-wider transition-colors"
                >
                  Adiar
                </button>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

// ── Main screen ───────────────────────────────────────────────────────────────

const EscritorioScreen: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabKey>('diario');
  const navigate = useNavigate();
  const { state, dismissNotification } = useGameState();

  useEffect(() => {
    dismissNotification('escritorio');
  }, []); // eslint-disable-line react-hooks/exhaustive-deps

  return (
    <div className="h-full flex flex-col overflow-hidden relative"
      style={{ background: 'linear-gradient(160deg, #1a130e 0%, #150f0a 60%, #1c1108 100%)' }}>

      <WallDecoration />

      {/* Header — aged wood look */}
      <div className="relative z-10 shrink-0 border-b border-leather-600/50"
        style={{ background: 'linear-gradient(180deg, #2a1c12 0%, #1e1409 100%)' }}>
        <div className="px-6 py-4 flex items-center gap-4">
          <button
            onClick={() => navigate('/herdade')}
            className="text-ivory/35 hover:text-gold/80 transition-colors text-xs font-body flex items-center gap-1.5 mr-2"
          >
            ← Herdade
          </button>
          <div className="h-4 w-px bg-leather-600/40" />

          {/* Office nameplate */}
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-leather-700/60 border border-gold/20 flex items-center justify-center shrink-0">
              <span className="text-gold/60 text-sm">🏛️</span>
            </div>
            <div>
              <h2 className="font-display text-lg text-gold tracking-widest uppercase leading-none">Escritório</h2>
              <p className="text-ivory/35 text-[11px] font-body mt-0.5">Herdade da Ferraria · {state.month} {state.year}</p>
            </div>
          </div>

          {/* Season badge */}
          <div className="ml-auto bg-leather-800/60 border border-leather-600/30 rounded px-3 py-1.5">
            <p className="text-ivory/30 text-[9px] font-body uppercase tracking-widest">{state.season}</p>
          </div>
        </div>

        <TabBar active={activeTab} onChange={setActiveTab} />
      </div>

      {/* Content area — two-panel layout: ambient sidebar + main content */}
      <div className="relative z-10 flex-1 flex overflow-hidden">

        {/* Left ambient panel — wood texture, wall art */}
        <div className="w-48 shrink-0 border-r border-leather-700/40 flex flex-col relative overflow-hidden"
          style={{ background: 'linear-gradient(180deg, #1e1409 0%, #170f08 100%)' }}>

          {/* Wood grain lines */}
          <div className="absolute inset-0 pointer-events-none opacity-[0.06]">
            {Array.from({ length: 18 }).map((_, i) => (
              <div key={i} className="absolute inset-x-0 h-px bg-amber-800"
                style={{ top: `${(i + 1) * 5.5}%`, transform: `skewY(${i % 2 === 0 ? 0.3 : -0.3}deg)` }} />
            ))}
          </div>

          {/* Bull silhouette painting */}
          <div className="mx-4 mt-4 mb-3 relative">
            <div className="h-28 bg-gradient-to-b from-leather-800/40 to-leather-900/60 border border-leather-600/30 rounded flex items-center justify-center overflow-hidden">
              <span className="text-5xl opacity-25">🐂</span>
              <div className="absolute inset-0 bg-gradient-to-t from-leather-900/30 to-transparent" />
            </div>
            {/* Painting frame */}
            <div className="absolute -inset-1 border border-gold/15 rounded pointer-events-none" />
            <div className="absolute -inset-2 border border-leather-600/20 rounded pointer-events-none" />
            <p className="text-ivory/15 text-[9px] font-body text-center mt-2 italic">Herdade da Ferraria</p>
          </div>

          {/* Divider */}
          <div className="mx-4 h-px bg-gradient-to-r from-transparent via-gold/15 to-transparent" />

          {/* Quick stats */}
          <div className="mx-4 mt-3 space-y-2">
            {[
              { label: 'Efectivo', value: `${state.animals.length}` },
              { label: 'Tesouraria', value: `${Math.round(state.economy.treasury / 1000)}k€` },
              { label: 'Registos', value: `${state.eventLog.length}` },
            ].map(s => (
              <div key={s.label} className="flex items-baseline justify-between">
                <span className="text-ivory/25 text-[10px] font-body uppercase tracking-wider">{s.label}</span>
                <span className="text-gold/60 text-xs font-display">{s.value}</span>
              </div>
            ))}
          </div>

          {/* Subtle seal at bottom */}
          <div className="mt-auto mx-auto mb-5 opacity-10">
            <div className="w-12 h-12 rounded-full border-2 border-gold/60 flex items-center justify-center">
              <span className="text-xl">🐂</span>
            </div>
            <p className="text-gold/40 text-[8px] font-body text-center mt-1 tracking-widest uppercase">Est. 1947</p>
          </div>
        </div>

        {/* Main content */}
        <div className="flex-1 overflow-hidden flex flex-col">
          {/* Paper surface */}
          <div className="flex-1 overflow-hidden m-5 rounded-lg relative"
            style={{ background: 'linear-gradient(160deg, #1e1509 0%, #180e07 100%)', border: '1px solid rgba(90,60,30,0.35)' }}>
            {/* Paper texture top edge */}
            <div className="absolute top-0 inset-x-8 h-px bg-gradient-to-r from-transparent via-gold/10 to-transparent pointer-events-none" />
            <div className="h-full overflow-hidden flex flex-col p-5">
              <DayFlowPanel />
              <AlphaFirstPlayPanel />
              <AlphaQaPanel />
              <MorningCouncilPanel onOpenTab={setActiveTab} />
              <div className="min-h-0 flex-1 overflow-hidden flex flex-col">
              {activeTab === 'diario'        && <DiarioTab />}
              {activeTab === 'jornal'        && <JornalTab />}
              {activeTab === 'economia'      && <EconomiaTab />}
              {activeTab === 'calendario'    && <CalendarioTab />}
              {activeTab === 'contratos'     && <ContratosTab />}
              {activeTab === 'pessoal'       && <PessoalTab />}
              {activeTab === 'campanha'     && <CampanhaTab />}
              {activeTab === 'livro'         && <LivroTab />}
              {activeTab === 'prestigio'     && <PrestigioTab />}
              {activeTab === 'administracao' && <AdministracaoTab />}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EscritorioScreen;
