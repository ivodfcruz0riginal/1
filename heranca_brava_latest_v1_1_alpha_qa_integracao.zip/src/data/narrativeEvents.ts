import type { NarrativeEvent, NarrativeRelationships } from '../types/narrative';

export const INITIAL_RELATIONSHIPS: NarrativeRelationships = {
  maioral: { trust: 50, respect: 50, fatigue: 10, loyalty: 65, affinity: 55, tension: 12 },
  veterinario: { trust: 45, respect: 50, fatigue: 5, loyalty: 45, affinity: 45, tension: 10 },
  campino: { trust: 45, respect: 50, fatigue: 15, loyalty: 55, affinity: 50, tension: 14 },
  administrador: { trust: 40, respect: 45, fatigue: 5, loyalty: 40, affinity: 42, tension: 18 },
  familia: { trust: 60, respect: 55, fatigue: 0, loyalty: 70, affinity: 65, tension: 8 },
  empresario: { trust: 30, respect: 35, fatigue: 0, loyalty: 25, affinity: 35, tension: 25 },
};

export const NARRATIVE_EVENTS: NarrativeEvent[] = [
  {
    id: 'narr-greet-start',
    dialogueId: 'greet_start',
    characterId: 'maioral',
    choices: [
      {
        label: 'Bom dia, Manuel.',
        resultText: 'O Manuel sente que a relação começa com respeito e proximidade.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 2, message: 'Confiança do maioral aumentou.' },
          { target: 'eventLog', message: 'O ganadeiro iniciou a campanha com uma saudação respeitosa ao maioral.' },
        ],
      },
      {
        label: 'Tem novidades para mim?',
        resultText: 'O Manuel entende que o patrão quer começar pelos assuntos práticos da herdade.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 1, message: 'Respeito operacional do maioral aumentou.' },
          { target: 'eventLog', message: 'O primeiro despacho da campanha foi pedido ao maioral.' },
        ],
      },
      {
        label: 'Que comece o trabalho.',
        resultText: 'A casa começa a campanha com disciplina.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 1 },
          { target: 'eventLog', message: 'A campanha começou com foco no trabalho da herdade.' },
        ],
      },
    ],
  },
  {
    id: 'narr-animal-1',
    dialogueId: 'animal_1',
    characterId: 'maioral',
    choices: [
      {
        label: 'Chama o veterinário.',
        resultText: 'O veterinário será chamado. Há custo imediato, mas reduz-se o risco sanitário.',
        effects: [
          { target: 'treasury', value: -1200, message: 'Consulta veterinária de urgência.' },
          { target: 'relationship', characterId: 'maioral', value: 2 },
          { target: 'animalHealth', animalCategory: 'Macho de Corrida', value: 5 },
          { target: 'eventLog', message: 'O maioral chamou o veterinário para observar um animal agressivo.' },
        ],
      },
      {
        label: 'Vou ver pessoalmente.',
        resultText: 'O patrão acompanha a situação no terreno. O maioral valoriza a presença.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 3 },
          { target: 'eventLog', message: 'O ganadeiro decidiu observar pessoalmente um animal de comportamento difícil.' },
        ],
      },
      {
        label: 'Que fique isolado.',
        resultText: 'O animal será isolado para reduzir risco de acidentes.',
        effects: [
          { target: 'treasury', value: -350, message: 'Custos de isolamento e maneio.' },
          { target: 'relationship', characterId: 'maioral', value: 1 },
          { target: 'eventLog', message: 'Um animal agressivo foi separado por precaução.' },
        ],
      },
      {
        label: 'Ignorar por agora.',
        resultText: 'A situação fica sem resposta. O maioral regista a decisão com reserva.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: -3 },
          { target: 'animalHealth', animalCategory: 'Macho de Corrida', value: -4 },
          { target: 'eventLog', message: 'O aviso do maioral sobre um animal agressivo foi ignorado.' },
        ],
      },
    ],
  },
  {
    id: 'narr-infra-1',
    dialogueId: 'infra_1',
    characterId: 'maioral',
    choices: [
      {
        label: 'Vou tratar disso.',
        resultText: 'A vedação será reparada com custo controlado.',
        effects: [
          { target: 'treasury', value: -1800, message: 'Reparação de vedação no Cercado Norte.' },
          { target: 'relationship', characterId: 'maioral', value: 2 },
          { target: 'eventLog', message: 'Foi ordenada a reparação da vedação do Cercado Norte.' },
        ],
      },
      {
        label: 'Quanto custa a reparação?',
        resultText: 'O Manuel prepara um orçamento antes de avançar.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 1 },
          { target: 'eventLog', message: 'O maioral ficou de apresentar orçamento para a vedação do Cercado Norte.' },
        ],
      },
      {
        label: 'Ignorar por agora.',
        resultText: 'A vedação continua vulnerável. A equipa fica desconfortável com o risco.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: -2 },
          { target: 'eventLog', message: 'A reparação urgente da vedação foi adiada.' },
        ],
      },
      {
        label: 'Contrata quem for preciso.',
        resultText: 'A reparação avança imediatamente com equipa externa.',
        effects: [
          { target: 'treasury', value: -3200, message: 'Contratação urgente para vedação.' },
          { target: 'relationship', characterId: 'maioral', value: 3 },
          { target: 'eventLog', message: 'Foi contratada equipa externa para reparar a vedação com urgência.' },
        ],
      },
    ],
  },

  {
    id: 'narr-monthly-summer',
    dialogueId: 'monthly_summer',
    characterId: 'maioral',
    choices: [
      {
        label: 'Trata disso.',
        resultText: 'A equipa reforça as aguadas e cria sombra extra. A decisão custa dinheiro, mas protege o efetivo.',
        effects: [
          { target: 'treasury', value: -900, message: 'Reforço de água e sombra durante o Verão.' },
          { target: 'relationship', characterId: 'maioral', value: 2 },
          { target: 'animalHealth', value: 4 },
          { target: 'eventLog', message: 'O maioral recebeu ordem para reforçar a vigilância das aguadas.' },
        ],
      },
      {
        label: 'Quantas reses têm acesso à aguada?',
        resultText: 'O Manuel prepara uma verificação dos cercados. O risco fica controlado sem despesa imediata.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 1 },
          { target: 'eventLog', message: 'Foi pedido levantamento das aguadas disponíveis nos cercados.' },
        ],
      },
      {
        label: 'Obrigado pelo aviso.',
        resultText: 'O aviso fica registado, mas nenhuma ação concreta é tomada.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 1 },
          { target: 'eventLog', message: 'O aviso de calor ficou registado sem intervenção imediata.' },
        ],
      },
    ],
  },
  {
    id: 'narr-monthly-winter',
    dialogueId: 'monthly_winter',
    characterId: 'maioral',
    choices: [
      {
        label: 'Redobra a atenção.',
        resultText: 'Os animais jovens passam a ser vigiados com mais frequência. A equipa fica mais cansada, mas o risco baixa.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 2 },
          { target: 'animalHealth', value: 3 },
          { target: 'eventLog', message: 'Foi reforçada a vigilância dos animais jovens durante o Inverno.' },
        ],
      },
      {
        label: 'Chama o veterinário para inspecção.',
        resultText: 'A inspeção preventiva reduz riscos sanitários, com custo imediato para a tesouraria.',
        effects: [
          { target: 'treasury', value: -1500, message: 'Inspeção veterinária preventiva de Inverno.' },
          { target: 'animalHealth', value: 5 },
          { target: 'relationship', characterId: 'maioral', value: 1 },
          { target: 'eventLog', message: 'Foi marcada inspeção veterinária preventiva aos animais jovens.' },
        ],
      },
      {
        label: 'Entendido.',
        resultText: 'A informação fica registada, mas sem reforço operacional.',
        effects: [
          { target: 'eventLog', message: 'O aviso de Inverno ficou registado no diário da herdade.' },
        ],
      },
    ],
  },
  {
    id: 'narr-animal-3',
    dialogueId: 'animal_3',
    characterId: 'maioral',
    choices: [
      {
        label: 'Excelente notícia.',
        resultText: 'A equipa sente que o patrão valoriza os bons sinais da casa.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 1 },
          { target: 'prestige', value: 1 },
          { target: 'eventLog', message: 'O nascimento de dois vitelos saudáveis trouxe ânimo à casa.' },
        ],
      },
      {
        label: 'Vamos registar no livro.',
        resultText: 'Os nascimentos são registados no Livro Genealógico. A gestão da linhagem fica mais rigorosa.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 2 },
          { target: 'eventLog', message: 'Dois vitelos foram registados no Livro Genealógico.' },
        ],
      },
      {
        label: 'Que os vigiem de perto.',
        resultText: 'A vigilância dos vitelos aumenta. Pequeno custo de maneio, maior segurança sanitária.',
        effects: [
          { target: 'treasury', value: -250, message: 'Vigilância reforçada de vitelos recém-nascidos.' },
          { target: 'animalHealth', value: 3 },
          { target: 'eventLog', message: 'Foi ordenada vigilância apertada aos dois vitelos recém-nascidos.' },
        ],
      },
    ],
  },
  {
    id: 'narr-animal-4',
    dialogueId: 'animal_4',
    characterId: 'maioral',
    choices: [
      {
        label: 'Promissor.',
        resultText: 'O novilho fica marcado mentalmente como animal a observar nos próximos meses.',
        effects: [
          { target: 'prestige', value: 1 },
          { target: 'eventLog', message: 'Um novilho promissor ficou marcado para observação futura.' },
        ],
      },
      {
        label: 'Marca-o para a próxima tienta.',
        resultText: 'A próxima tienta ganha prioridade. Há custo de preparação, mas também potencial de seleção.',
        effects: [
          { target: 'treasury', value: -700, message: 'Preparação de novilho promissor para tienta.' },
          { target: 'relationship', characterId: 'maioral', value: 2 },
          { target: 'prestige', value: 2 },
          { target: 'eventLog', message: 'Um novilho promissor foi marcado para a próxima tienta.' },
        ],
      },
      {
        label: 'Quero vê-lo trabalhar.',
        resultText: 'O patrão decide observar diretamente o animal. O maioral valoriza a atenção ao detalhe.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 3 },
          { target: 'eventLog', message: 'O ganadeiro pediu para observar pessoalmente um novilho promissor.' },
        ],
      },
    ],
  },
  {
    id: 'narr-animal-5',
    dialogueId: 'animal_5',
    characterId: 'maioral',
    choices: [
      {
        label: 'Chama o veterinário.',
        resultText: 'O veterinário é chamado antes que o problema se agrave.',
        effects: [
          { target: 'treasury', value: -1200, message: 'Consulta veterinária por perda de apetite.' },
          { target: 'animalHealth', animalCategory: 'Macho de Corrida', value: 5 },
          { target: 'relationship', characterId: 'maioral', value: 2 },
          { target: 'eventLog', message: 'Foi chamado veterinário para um toiro com pouco apetite.' },
        ],
      },
      {
        label: 'Vigiem durante dois dias.',
        resultText: 'A equipa acompanha o animal sem custo imediato, mas mantém algum risco.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 1 },
          { target: 'eventLog', message: 'Um toiro com pouco apetite ficou sob vigilância durante dois dias.' },
        ],
      },
      {
        label: 'Isola-o por precaução.',
        resultText: 'O isolamento reduz risco de contágio e facilita observação, com custo de maneio.',
        effects: [
          { target: 'treasury', value: -450, message: 'Isolamento preventivo de animal com pouco apetite.' },
          { target: 'animalHealth', animalCategory: 'Macho de Corrida', value: 3 },
          { target: 'eventLog', message: 'Um toiro com pouco apetite foi isolado por precaução.' },
        ],
      },
    ],
  },
  {
    id: 'narr-infra-2',
    dialogueId: 'infra_2',
    characterId: 'maioral',
    choices: [
      {
        label: 'Trata disso.',
        resultText: 'O tentadero será preparado sem atrasar a próxima tienta.',
        effects: [
          { target: 'treasury', value: -1600, message: 'Manutenção preventiva do tentadero.' },
          { target: 'relationship', characterId: 'maioral', value: 2 },
          { target: 'prestige', value: 1 },
          { target: 'eventLog', message: 'Foi autorizada manutenção do tentadero antes da próxima tienta.' },
        ],
      },
      {
        label: 'Quando é a próxima tienta?',
        resultText: 'O maioral prepara informação de calendário antes de executar a despesa.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 1 },
          { target: 'eventLog', message: 'Foi pedida confirmação de calendário antes da manutenção do tentadero.' },
        ],
      },
      {
        label: 'Deixa para depois.',
        resultText: 'A manutenção é adiada. Poupa-se dinheiro agora, mas aumenta o risco de falha futura.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: -2 },
          { target: 'prestige', value: -1 },
          { target: 'eventLog', message: 'A manutenção do tentadero foi adiada.' },
        ],
      },
    ],
  },
  {
    id: 'narr-news-4',
    dialogueId: 'news_4',
    characterId: 'maioral',
    choices: [
      {
        label: 'Aceitamos.',
        resultText: 'A ganadaria aceita o convite. O prestígio pode subir, mas haverá custos de preparação.',
        effects: [
          { target: 'treasury', value: -2500, message: 'Preparação para corrida em Vila Franca.' },
          { target: 'prestige', value: 4 },
          { target: 'eventLog', message: 'A Herdade aceitou convite para corrida em Vila Franca de Xira.' },
        ],
      },
      {
        label: 'Precisamos de ver o calendário.',
        resultText: 'A decisão fica pendente para avaliação de calendário.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 1 },
          { target: 'eventLog', message: 'O convite para Vila Franca ficou dependente da análise do calendário.' },
        ],
      },
      {
        label: 'Recusamos por agora.',
        resultText: 'A oportunidade é recusada. Evitam-se riscos e custos.',
        effects: [
          { target: 'prestige', value: -1 },
          { target: 'eventLog', message: 'A Herdade recusou por agora o convite para Vila Franca de Xira.' },
        ],
      },
    ],
  },,

  {
    id: 'narr-loc-escritorio-1',
    dialogueId: 'loc_escritorio_1',
    characterId: 'maioral',
    locationIds: ['escritorio'],
    choices: [
      {
        label: 'Comecemos pela agenda.',
        resultText: 'O maioral coloca a agenda em cima da secretária. O mês fica organizado antes de se gastar dinheiro.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 2 },
          { target: 'eventLog', message: 'O mês começou pela agenda do escritório.' },
        ],
      },
      {
        label: 'Mostra-me as contas.',
        resultText: 'O Livro de Contas é aberto. A equipa percebe que a gestão financeira vem primeiro.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 1 },
          { target: 'eventLog', message: 'O ganadeiro pediu revisão das contas da herdade.' },
        ],
      },
      {
        label: 'Deixa as cartas para depois.',
        resultText: 'A correspondência fica adiada. Nada muda já, mas oportunidades podem arrefecer.',
        effects: [
          { target: 'eventLog', message: 'A correspondência foi deixada para mais tarde.' },
        ],
      },
    ],
  },
  {
    id: 'narr-loc-currais-1',
    dialogueId: 'loc_currais_1',
    characterId: 'maioral',
    locationIds: ['currais'],
    choices: [
      {
        label: 'Manda entrar um.',
        resultText: 'Um novilho é separado para observação. A operação avança com disciplina.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 2 },
          { target: 'prestige', value: 1 },
          { target: 'eventLog', message: 'Foi iniciada apartação individual nos currais.' },
        ],
      },
      {
        label: 'Primeiro quero observar o lote.',
        resultText: 'O maioral aguarda. O patrão privilegia leitura do lote antes de agir.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 3 },
          { target: 'eventLog', message: 'O lote foi observado antes da apartação.' },
        ],
      },
      {
        label: 'Hoje não arriscamos.',
        resultText: 'A operação é adiada. Evita-se risco, mas perde-se ritmo de trabalho.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: -1 },
          { target: 'eventLog', message: 'A apartação nos currais foi adiada por prudência.' },
        ],
      },
    ],
  },
  {
    id: 'narr-loc-tentadero-1',
    dialogueId: 'loc_tentadero_1',
    characterId: 'maioral',
    locationIds: ['tentadero'],
    choices: [
      {
        label: 'Prepara a prova.',
        resultText: 'A equipa prepara o tentadero. Há custo de operação, mas a seleção avança.',
        effects: [
          { target: 'treasury', value: -900, message: 'Preparação operacional do tentadero.' },
          { target: 'relationship', characterId: 'maioral', value: 2 },
          { target: 'prestige', value: 2 },
          { target: 'eventLog', message: 'Foi preparada uma prova no tentadero.' },
        ],
      },
      {
        label: 'Ainda quero rever os animais.',
        resultText: 'A prova é preparada com mais cautela. O maioral valoriza o rigor.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 2 },
          { target: 'eventLog', message: 'A tienta ficou dependente de revisão do lote.' },
        ],
      },
      {
        label: 'Adia para a próxima semana.',
        resultText: 'A prova é adiada. Poupa-se esforço imediato, mas perde-se oportunidade de avaliação.',
        effects: [
          { target: 'prestige', value: -1 },
          { target: 'eventLog', message: 'A prova do tentadero foi adiada.' },
        ],
      },
    ],
  },
  {
    id: 'narr-loc-embarque-1',
    dialogueId: 'loc_embarque_1',
    characterId: 'maioral',
    locationIds: ['embarque'],
    choices: [
      {
        label: 'Revê tudo antes do embarque.',
        resultText: 'A manga e a rampa são verificadas antes de qualquer animal avançar.',
        effects: [
          { target: 'treasury', value: -500, message: 'Revisão preventiva do parque de embarque.' },
          { target: 'relationship', characterId: 'maioral', value: 3 },
          { target: 'eventLog', message: 'O parque de embarque foi revisto antes da operação.' },
        ],
      },
      {
        label: 'Chama o motorista.',
        resultText: 'O transporte é preparado. O camião fica em pré-alinhamento.',
        effects: [
          { target: 'treasury', value: -750, message: 'Chamada e preparação de transporte.' },
          { target: 'eventLog', message: 'O motorista foi chamado para preparar o transporte.' },
        ],
      },
      {
        label: 'Sem transporte por agora.',
        resultText: 'O embarque fica suspenso. A instalação permanece livre.',
        effects: [
          { target: 'eventLog', message: 'Nenhum transporte foi autorizado no parque de embarque.' },
        ],
      },
    ],
  },
  {
    id: 'narr-loc-cercado-norte-1',
    dialogueId: 'loc_cercado_norte_1',
    characterId: 'maioral',
    locationIds: ['cercado_norte'],
    choices: [
      {
        label: 'Repara já a vedação.',
        resultText: 'A reparação avança de imediato. A segurança do lote fica protegida.',
        effects: [
          { target: 'treasury', value: -1800, message: 'Reparação imediata no Cercado Norte.' },
          { target: 'relationship', characterId: 'maioral', value: 2 },
          { target: 'eventLog', message: 'A vedação do Cercado Norte foi mandada reparar.' },
        ],
      },
      {
        label: 'Observa durante a semana.',
        resultText: 'O maioral reforça vigilância sem intervenção estrutural imediata.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 1 },
          { target: 'eventLog', message: 'O Cercado Norte ficou sob observação reforçada.' },
        ],
      },
      {
        label: 'Traz-me orçamento.',
        resultText: 'A decisão fica preparada com números antes da despesa.',
        effects: [
          { target: 'eventLog', message: 'Foi pedido orçamento para reparar a vedação do Cercado Norte.' },
        ],
      },
    ],
  },
  {
    id: 'narr-loc-cercado-sul-1',
    dialogueId: 'loc_cercado_sul_1',
    characterId: 'maioral',
    locationIds: ['cercado_sul'],
    choices: [
      {
        label: 'Marca-o para observação.',
        resultText: 'O novilho fica sinalizado. A seleção começa antes de entrar nos currais.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 2 },
          { target: 'prestige', value: 1 },
          { target: 'eventLog', message: 'Um novilho do Cercado Sul foi marcado para observação.' },
        ],
      },
      {
        label: 'Deixa-os crescer.',
        resultText: 'O lote mantém-se no campo. A decisão privilegia maturação.',
        effects: [
          { target: 'eventLog', message: 'Os novilhos do Cercado Sul foram deixados a crescer.' },
        ],
      },
      {
        label: 'Leva o lote aos currais.',
        resultText: 'A movimentação é preparada. Haverá custo de maneio, mas ganha-se informação.',
        effects: [
          { target: 'treasury', value: -600, message: 'Movimentação de lote do Cercado Sul para os currais.' },
          { target: 'relationship', characterId: 'maioral', value: 1 },
          { target: 'eventLog', message: 'Foi ordenada condução de lote do Cercado Sul para os currais.' },
        ],
      },
    ],
  },
  {
    id: 'narr-loc-barragem-1',
    dialogueId: 'loc_barragem_1',
    characterId: 'maioral',
    locationIds: ['barragem'],
    choices: [
      {
        label: 'Prepara reforço preventivo.',
        resultText: 'A herdade antecipa a seca. Há custo agora, mas menor risco depois.',
        effects: [
          { target: 'treasury', value: -1300, message: 'Reforço preventivo de aguadas.' },
          { target: 'animalHealth', value: 4 },
          { target: 'eventLog', message: 'Foi preparado reforço preventivo de água.' },
        ],
      },
      {
        label: 'Aguarda mais uma semana.',
        resultText: 'A decisão fica suspensa. O risco mantém-se controlado por enquanto.',
        effects: [
          { target: 'eventLog', message: 'O reforço de água foi adiado por uma semana.' },
        ],
      },
      {
        label: 'Faz relatório da água.',
        resultText: 'O maioral prepara um relatório de níveis antes de mexer na tesouraria.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 1 },
          { target: 'eventLog', message: 'Foi pedido relatório do estado das águas da herdade.' },
        ],
      },
    ],
  },
  {
    id: 'narr-loc-armazem-1',
    dialogueId: 'loc_armazem_1',
    characterId: 'maioral',
    locationIds: ['armazem'],
    choices: [
      {
        label: 'Compra feno agora.',
        resultText: 'As reservas sobem antes do preço piorar. A tesouraria sente o impacto.',
        effects: [
          { target: 'treasury', value: -2400, message: 'Compra antecipada de feno.' },
          { target: 'animalHealth', value: 2 },
          { target: 'eventLog', message: 'Foi comprada forragem adicional para a herdade.' },
        ],
      },
      {
        label: 'Organiza primeiro o stock.',
        resultText: 'A equipa reorganiza o armazém e evita despesa imediata.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: 1 },
          { target: 'eventLog', message: 'O armazém entrou em reorganização antes de novas compras.' },
        ],
      },
      {
        label: 'Arriscamos com o que há.',
        resultText: 'Poupa-se dinheiro agora, mas o maioral fica pouco convencido.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: -2 },
          { target: 'eventLog', message: 'A herdade decidiu não reforçar reservas por agora.' },
        ],
      },
    ],
  },
  {
    id: 'narr-loc-oficina-1',
    dialogueId: 'loc_oficina_1',
    characterId: 'maioral',
    locationIds: ['oficina'],
    choices: [
      {
        label: 'Reorganiza a oficina.',
        resultText: 'A oficina ganha capacidade operacional. Custa agora, evita falhas futuras.',
        effects: [
          { target: 'treasury', value: -1100, message: 'Reorganização da oficina.' },
          { target: 'relationship', characterId: 'maioral', value: 2 },
          { target: 'eventLog', message: 'A oficina foi reorganizada por ordem do ganadeiro.' },
        ],
      },
      {
        label: 'Só o essencial.',
        resultText: 'A equipa faz apenas manutenção mínima.',
        effects: [
          { target: 'treasury', value: -300, message: 'Manutenção mínima da oficina.' },
          { target: 'eventLog', message: 'A oficina recebeu apenas manutenção essencial.' },
        ],
      },
      {
        label: 'Fica para depois.',
        resultText: 'A oficina continua frágil. O risco operacional permanece.',
        effects: [
          { target: 'relationship', characterId: 'maioral', value: -2 },
          { target: 'eventLog', message: 'A reorganização da oficina foi adiada.' },
        ],
      },
    ],
  },
  {
    id: 'narr-loc-casa-1',
    dialogueId: 'loc_casa_1',
    characterId: 'maioral',
    locationIds: ['casa'],
    choices: [
      {
        label: 'Vamos investir com prudência.',
        resultText: 'A casa aceita uma campanha equilibrada, sem travar o crescimento.',
        effects: [
          { target: 'prestige', value: 1 },
          { target: 'eventLog', message: 'A família aceitou uma estratégia prudente de investimento.' },
        ],
      },
      {
        label: 'Este ano apertamos custos.',
        resultText: 'A disciplina financeira aumenta, mas algumas oportunidades ficam para trás.',
        effects: [
          { target: 'treasury', value: 1000, message: 'Corte preventivo de custos familiares e administrativos.' },
          { target: 'prestige', value: -1 },
          { target: 'eventLog', message: 'A casa decidiu apertar custos nesta campanha.' },
        ],
      },
      {
        label: 'Ainda não decidi.',
        resultText: 'A família fica à espera. A decisão estratégica continua aberta.',
        effects: [
          { target: 'eventLog', message: 'A estratégia anual da casa ficou por decidir.' },
        ],
      },
    ],
  }
];

export function findNarrativeEvent(dialogueId: string): NarrativeEvent | undefined {
  return NARRATIVE_EVENTS.find(event => event.dialogueId === dialogueId);
}
