import type { LocationId } from '../types/location';

export interface DialogueTemplate {
  id: string;
  text: string;
  choices: string[];
  locationIds?: LocationId[];
  priority?: number;
}

export const GREETING_DIALOGUE: DialogueTemplate = {
  id: 'greet_start',
  text: 'Bom dia, patrão. Bem-vindo à Herdade da Ferraria. É uma honra servir a esta casa.',
  choices: ['Bom dia, Manuel.', 'Tem novidades para mim?', 'Que comece o trabalho.'],
  locationIds: ['escritorio'],
  priority: 100,
};

const MONTHLY_DIALOGUES: DialogueTemplate[] = [
  {
    id: 'monthly_1',
    text: 'Passado mais um mês, patrão. A herdade segue o seu rumo.',
    choices: ['Muito bem.', 'Alguma preocupação?', 'Precisamos de falar sobre o efectivo.'],
    locationIds: ['escritorio', 'casa'],
  },
  {
    id: 'monthly_spring',
    text: 'A Primavera está a chegar. As pastagens estão a reviver. Bom tempo para os animais.',
    choices: ['Excelente notícia.', 'Aproveitemos a época.', 'Algum nascimento esperado?'],
    locationIds: ['cercado_norte', 'cercado_sul'],
  },
  {
    id: 'monthly_summer',
    text: 'O calor aperta, patrão. Os animais precisam de mais água e sombra.',
    choices: ['Trata disso.', 'Quantas reses têm acesso à aguada?', 'Obrigado pelo aviso.'],
    locationIds: ['cercado_norte', 'cercado_sul', 'barragem'],
  },
  {
    id: 'monthly_autumn',
    text: 'O Outono chegou. Altura de preparar o Inverno e garantir reservas de feno.',
    choices: ['Que tudo fique preparado.', 'As reservas estão garantidas?', 'Bem notado, Manuel.'],
    locationIds: ['armazem', 'escritorio'],
  },
  {
    id: 'monthly_winter',
    text: 'O frio chegou. Os animais mais novos precisam de vigilância constante.',
    choices: ['Redobra a atenção.', 'Chama o veterinário para inspecção.', 'Entendido.'],
    locationIds: ['cercado_norte', 'cercado_sul', 'currais'],
  },
];

const ANIMAL_DIALOGUES: DialogueTemplate[] = [
  {
    id: 'animal_1',
    text: 'O Bravio 18 anda demasiado agressivo. Convém vigiar de perto.',
    choices: ['Chama o veterinário.', 'Vou ver pessoalmente.', 'Que fique isolado.', 'Ignorar por agora.'],
    locationIds: ['currais', 'cercado_sul'],
  },
  {
    id: 'animal_2',
    text: 'As vacas do Cercado Sul estão muito tranquilas esta semana.',
    choices: ['Boa notícia.', 'Devemos aproveitar para a tienta?', 'Continuem a vigiar.'],
    locationIds: ['cercado_sul'],
  },
  {
    id: 'animal_3',
    text: 'Nasceram dois vitelos no Cercado Norte. Os dois saudáveis, patrão.',
    choices: ['Excelente notícia.', 'Vamos registar no livro.', 'Que os vigiem de perto.'],
    locationIds: ['cercado_norte', 'escritorio'],
  },
  {
    id: 'animal_4',
    text: 'Um dos novilhos mostrou boa bravura no treino de ontem. Promissor.',
    choices: ['Promissor.', 'Marca-o para a próxima tienta.', 'Quero vê-lo trabalhar.'],
    locationIds: ['tentadero', 'currais'],
  },
  {
    id: 'animal_5',
    text: 'Um dos toiros do Cercado Norte está com pouco apetite. Pode ser coisa passageira.',
    choices: ['Chama o veterinário.', 'Vigiem durante dois dias.', 'Isola-o por precaução.'],
    locationIds: ['cercado_norte', 'currais'],
  },
];

const INFRA_DIALOGUES: DialogueTemplate[] = [
  {
    id: 'infra_1',
    text: 'A vedação do Cercado Norte precisa de reparação urgente. Há um troço cedido.',
    choices: ['Vou tratar disso.', 'Quanto custa a reparação?', 'Ignorar por agora.', 'Contrata quem for preciso.'],
    locationIds: ['cercado_norte', 'oficina'],
  },
  {
    id: 'infra_2',
    text: 'O tentadero precisa de manutenção antes da próxima tienta.',
    choices: ['Trata disso.', 'Quando é a próxima tienta?', 'Deixa para depois.'],
    locationIds: ['tentadero', 'oficina'],
  },
  {
    id: 'infra_3',
    text: 'O celeiro está com pouco espaço. Precisamos de organizar antes do Inverno.',
    choices: ['Que arranjem espaço.', 'Vejo isso mais tarde.', 'Quanto espaço falta?'],
    locationIds: ['armazem'],
  },
];

const NEWS_DIALOGUES: DialogueTemplate[] = [
  {
    id: 'news_1',
    text: 'Recebemos uma carta da Moita, patrão. Parece urgente.',
    choices: ['Quero ver primeiro.', 'O que diz?', 'Deixa em cima da secretária.'],
    locationIds: ['escritorio'],
  },
  {
    id: 'news_2',
    text: 'Um ganadeiro espanhol perguntou pelos nossos sementais.',
    choices: ['Responde com interesse.', 'Não estamos disponíveis.', 'Marca uma reunião.'],
    locationIds: ['escritorio', 'casa'],
  },
  {
    id: 'news_3',
    text: 'O jornal de Lisboa mencionou a nossa ganaderia esta semana.',
    choices: ['Com bom ou mau tom?', 'Traz-me o jornal.', 'Que bom.'],
    locationIds: ['escritorio'],
  },
  {
    id: 'news_4',
    text: 'Chegou um convite para corrida em Vila Franca de Xira no próximo mês.',
    choices: ['Aceitamos.', 'Precisamos de ver o calendário.', 'Recusamos por agora.'],
    locationIds: ['escritorio'],
  },
  {
    id: 'news_5',
    text: 'O veterinário mandou dizer que pode visitar a herdade na próxima semana.',
    choices: ['Que venha.', 'Não é necessário por agora.', 'Combina para a semana a seguir.'],
    locationIds: ['escritorio', 'currais'],
  },
];

const LOCATION_DIALOGUES: DialogueTemplate[] = [
  {
    id: 'loc_escritorio_1',
    text: 'Estamos no escritório, patrão. Tenho a agenda, as contas e duas cartas para despachar.',
    choices: ['Comecemos pela agenda.', 'Mostra-me as contas.', 'Deixa as cartas para depois.'],
    locationIds: ['escritorio'],
    priority: 30,
  },
  {
    id: 'loc_currais_1',
    text: 'Nos currais está tudo pronto. Posso mandar entrar um novilho para apartação.',
    choices: ['Manda entrar um.', 'Primeiro quero observar o lote.', 'Hoje não arriscamos.'],
    locationIds: ['currais'],
    priority: 40,
  },
  {
    id: 'loc_tentadero_1',
    text: 'O tentadero está limpo e a areia foi regada. Podemos preparar a próxima prova.',
    choices: ['Prepara a prova.', 'Ainda quero rever os animais.', 'Adia para a próxima semana.'],
    locationIds: ['tentadero'],
    priority: 40,
  },
  {
    id: 'loc_embarque_1',
    text: 'O parque de embarque está livre. Se houver transporte marcado, convém rever a manga e o camião.',
    choices: ['Revê tudo antes do embarque.', 'Chama o motorista.', 'Sem transporte por agora.'],
    locationIds: ['embarque'],
    priority: 40,
  },
  {
    id: 'loc_cercado_norte_1',
    text: 'No Cercado Norte há boa erva, mas a vedação ainda me deixa desconfiado.',
    choices: ['Repara já a vedação.', 'Observa durante a semana.', 'Traz-me orçamento.'],
    locationIds: ['cercado_norte'],
    priority: 35,
  },
  {
    id: 'loc_cercado_sul_1',
    text: 'O Cercado Sul está calmo. Os novilhos ganharam corpo e há um que merece olho.',
    choices: ['Marca-o para observação.', 'Deixa-os crescer.', 'Leva o lote aos currais.'],
    locationIds: ['cercado_sul'],
    priority: 35,
  },
  {
    id: 'loc_barragem_1',
    text: 'A água está segura por agora, mas se o Verão apertar teremos de reforçar as aguadas.',
    choices: ['Prepara reforço preventivo.', 'Aguarda mais uma semana.', 'Faz relatório da água.'],
    locationIds: ['barragem'],
    priority: 30,
  },
  {
    id: 'loc_armazem_1',
    text: 'O armazém aguenta mais algum tempo, mas as reservas não chegam para um Inverno duro.',
    choices: ['Compra feno agora.', 'Organiza primeiro o stock.', 'Arriscamos com o que há.'],
    locationIds: ['armazem'],
    priority: 30,
  },
  {
    id: 'loc_oficina_1',
    text: 'A oficina precisa de ordem. Se uma viatura falha em dia de embarque, ficamos mal.',
    choices: ['Reorganiza a oficina.', 'Só o essencial.', 'Fica para depois.'],
    locationIds: ['oficina'],
    priority: 30,
  },
  {
    id: 'loc_casa_1',
    text: 'A família quer saber se a campanha deste ano vai exigir mais investimento da casa.',
    choices: ['Vamos investir com prudência.', 'Este ano apertamos custos.', 'Ainda não decidi.'],
    locationIds: ['casa'],
    priority: 25,
  },
];

export const ALL_MONTHLY_POOL: DialogueTemplate[] = [
  ...MONTHLY_DIALOGUES,
  ...ANIMAL_DIALOGUES,
  ...INFRA_DIALOGUES,
  ...NEWS_DIALOGUES,
  ...LOCATION_DIALOGUES,
];

export function getDialogueById(id: string): DialogueTemplate | undefined {
  if (GREETING_DIALOGUE.id === id) return GREETING_DIALOGUE;
  return ALL_MONTHLY_POOL.find(dialogue => dialogue.id === id);
}

function pickFromPool(pool: DialogueTemplate[], excludedDialogueIds: string[] = []): DialogueTemplate {
  const filtered = pool.filter(dialogue => !excludedDialogueIds.includes(dialogue.id));
  const candidates = filtered.length > 0 ? filtered : pool;
  const topPriority = Math.max(...candidates.map(dialogue => dialogue.priority ?? 0));
  const priorityCandidates = candidates.filter(dialogue => (dialogue.priority ?? 0) === topPriority);
  return priorityCandidates[Math.floor(Math.random() * priorityCandidates.length)];
}

export function pickMonthlyDialogue(): DialogueTemplate {
  return pickFromPool([...MONTHLY_DIALOGUES, ...ANIMAL_DIALOGUES, ...INFRA_DIALOGUES, ...NEWS_DIALOGUES]);
}

export function pickDialogueForLocation(locationId: LocationId, excludedDialogueIds: string[] = []): DialogueTemplate | null {
  const pool = ALL_MONTHLY_POOL.filter(dialogue => dialogue.locationIds?.includes(locationId));
  if (pool.length === 0) return null;
  return pickFromPool(pool, excludedDialogueIds);
}
