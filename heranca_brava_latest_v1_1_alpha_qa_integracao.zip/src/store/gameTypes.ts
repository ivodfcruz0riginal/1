import type { Animal } from '../types/animal';
import type { DialogueTemplate } from '../data/maioralDialogues';
import type { DailyTask } from '../data/dailyTasks';
import type { Decision, DecisionCategory } from '../data/decisions';
import type { Location, LocationId, LocationCondition, LocationNotification } from '../types/location';
import type { EconomyState } from './economyEngine';
import type { NarrativeRelationships, NarrativeHistoryRecord, NarrativeEffect, NarrativeCharacterId } from '../types/narrative';
import type { Contract } from '../types/contract';
import type { StaffMember } from '../types/staff';
import type { AnnualObjective, AnnualReport } from '../types/campaign';
import type { MorningCouncilItem, ProfessionalConflictChoice } from '../types/meeting';
import type { CharacterMemory } from '../types/character';
import type { DayPeriod, DayRecord } from '../types/day';
import type { ActiveLocationEvent } from '../types/locationEvent';

export type GamePhase =
  | 'MonthStart'
  | 'DailyPlanning'
  | 'EstateManagement'
  | 'Decisions'
  | 'EndOfMonth'
  | 'Simulation';

export type Month =
  | 'Janeiro' | 'Fevereiro' | 'Março' | 'Abril' | 'Maio' | 'Junho'
  | 'Julho' | 'Agosto' | 'Setembro' | 'Outubro' | 'Novembro' | 'Dezembro';

export type Season = 'Primavera' | 'Verão' | 'Outono' | 'Inverno';

export interface GameEvent {
  id: string;
  month: Month;
  year: number;
  text: string;
  locationId?: LocationId | null;
}

export type BuildingKey = 'escritorio' | 'tentadero' | 'currais' | 'embarque' | 'cercado_norte' | 'cercado_sul' | 'casa';

export interface BuildingNotification {
  icon: string;
  label: string;
}

export type { DialogueTemplate as MaioralDialogue };

export interface DialogueRecord {
  dialogueId: string;
  choice: string;
  month: Month;
  year: number;
}

export type { DailyTask };
export type { Decision, DecisionCategory };
export type { Location, LocationId, LocationCondition, LocationNotification };


export interface NarrativeResult {
  resultText: string;
  choice: string;
  characterId: NarrativeCharacterId;
  appliedEffects: NarrativeEffect[];
  locationId?: LocationId | null;
}

export interface DecisionRecord {
  instanceId: string;
  decisionId: string;
  title: string;
  category: DecisionCategory;
  choice: string;
  month: Month;
  year: number;
  result: string | null;
}

export interface GameState {
  year: number;
  month: Month;
  dayOfMonth: number;
  dayPeriod: DayPeriod;
  season: Season;
  eventLog: GameEvent[];
  dayLog: DayRecord[];
  economy: EconomyState;
  animals: Animal[];
  notifications: Partial<Record<BuildingKey, BuildingNotification>>;
  pendingDialogue: DialogueTemplate | null;
  dialogueHistory: DialogueRecord[];
  relationships: NarrativeRelationships;
  characterMemories: CharacterMemory[];
  narrativeHistory: NarrativeHistoryRecord[];
  lastNarrativeResult: NarrativeResult | null;
  prestige: number;
  contracts: Contract[];
  staff: StaffMember[];
  annualReports: AnnualReport[];
  annualObjectives: AnnualObjective[];
  morningCouncil: MorningCouncilItem[];
  dailyTasks: DailyTask[];
  pendingDecision: Decision | null;
  decisionHistory: DecisionRecord[];
  locations: Location[];
  activeLocationId: LocationId | null;
  activeLocationEvent: ActiveLocationEvent | null;
  phase: GamePhase;
  hasOpenedBuildingThisMonth: boolean;
}

export type GameAction =
  | { type: 'ADVANCE_MONTH' }
  | { type: 'ADVANCE_DAY_PERIOD' }
  | { type: 'CLOSE_DAY' }
  | { type: 'DISMISS_NOTIFICATION'; building: BuildingKey }
  | { type: 'ANSWER_DIALOGUE'; choice: string }
  | { type: 'DISMISS_NARRATIVE_RESULT' }
  | { type: 'ATTEND_MORNING_MEETING'; id: string }
  | { type: 'POSTPONE_MORNING_MEETING'; id: string }
  | { type: 'RESOLVE_PROFESSIONAL_CONFLICT'; id: string; choice: ProfessionalConflictChoice }
  | { type: 'ACCEPT_CONTRACT'; id: string }
  | { type: 'REJECT_CONTRACT'; id: string }
  | { type: 'GIVE_STAFF_REST'; id: string }
  | { type: 'GIVE_STAFF_BONUS'; id: string }
  | { type: 'TRAIN_STAFF'; id: string }
  | { type: 'COMPLETE_TASK'; id: string }
  | { type: 'IGNORE_TASK'; id: string }
  | { type: 'RESOLVE_DECISION'; choice: string }
  | { type: 'SET_ACTIVE_LOCATION'; id: LocationId | null }
  | { type: 'RESOLVE_LOCATION_EVENT'; choiceId: string }
  | { type: 'UPDATE_LOCATION_CONDITION'; id: LocationId; condition: LocationCondition }
  | { type: 'ADD_LOCATION_NOTIFICATION'; id: LocationId; notification: LocationNotification }
  | { type: 'CLEAR_LOCATION_NOTIFICATION'; id: LocationId; notification: LocationNotification }
  | { type: 'UPDATE_LOCATION_OCCUPATION'; id: LocationId; occupation: number }
  | { type: 'SET_PHASE'; phase: GamePhase }
  | { type: 'LOAD_GAME_STATE'; state: GameState };
