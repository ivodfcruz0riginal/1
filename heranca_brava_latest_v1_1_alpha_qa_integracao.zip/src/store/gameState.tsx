import React, { createContext, useContext, useEffect, useReducer } from 'react';
import {
  INITIAL_ECONOMY,
  applyMonthToEconomy,
  type EconomyState,
} from './economyEngine';
import { applyMonthlyGrowth } from '../utils/animalGrowth';
import { animals as initialAnimals } from '../data/animals';
import { GREETING_DIALOGUE, getDialogueById, pickMonthlyDialogue, pickDialogueForLocation } from '../data/maioralDialogues';
import type { DialogueTemplate } from '../data/maioralDialogues';
import { generateDailyTasks } from '../data/dailyTasks';
import { OPENING_DECISION, pickDecision, nextDecisionInstanceId } from '../data/decisions';
import { INITIAL_LOCATIONS } from '../data/locations';
import { INITIAL_RELATIONSHIPS } from '../data/narrativeEvents';
import { applyNarrativeChoice } from '../services/narrativeEngine';
import { loadCampaign, saveCampaign } from '../services/saveService';
import { calculatePrestigeSnapshot } from '../services/prestigeService';
import { getInitialContracts, hydrateContracts, acceptContract, rejectContract, canAcceptContract, processMonthlyContracts } from '../services/contractService';
import { initialStaff } from '../data/staff';
import { processMonthlyStaff, giveStaffRest, giveStaffBonus, trainStaff } from '../services/staffService';
import { createAnnualObjectives, createAnnualReport, classifyRanchStatus } from '../services/campaignService';
import { createMorningCouncil, shouldRefreshMorningCouncil } from '../services/morningCouncilService';
import { addCharacterMemory, applyRelationshipShift, createCharacterMemory } from '../services/characterService';
import {
  updateLocationCondition,
  addLocationNotification,
  clearLocationNotification,
  updateLocationOccupation,
} from '../services/locationService';

// ── Re-export types ───────────────────────────────────────────────────────────

export type {
  GamePhase,
  Month,
  Season,
  GameEvent,
  BuildingKey,
  BuildingNotification,
  MaioralDialogue,
  DialogueRecord,
  DailyTask,
  Decision,
  DecisionCategory,
  DecisionRecord,
  Location,
  LocationId,
  LocationCondition,
  LocationNotification,
  GameState,
  GameAction,
} from './gameTypes';

import type {
  GamePhase,
  Month,
  Season,
  GameEvent,
  BuildingKey,
  BuildingNotification,
  DialogueRecord,
  DecisionRecord,
  GameState,
  GameAction,
  LocationId,
  LocationCondition,
  LocationNotification,
  Decision,
} from './gameTypes';
import type { ProfessionalConflictChoice } from '../types/meeting';
import { DAY_PERIOD_LABELS } from '../types/day';
import { createDayRecord, getNextDayPeriod, isLastDayPeriod, summarizeDay } from '../services/dayCycleService';
import { createLocationEvent } from '../services/locationEventService';
import { buildDiaryContinuityLine } from '../services/characterMemoryService';
import { simulateWorldStep } from '../services/worldSimulationService';
import { createAlphaDayChronicle } from '../services/alphaIntegrationService';

// ── Re-export constants ───────────────────────────────────────────────────────

export {
  MONTHS,
  SEASON_MAP,
  EVENTS_POOL,
  ESCRITORIO_NOTIFICATIONS,
  CERCADO_NOTIFICATIONS,
} from './gameConstants';

import {
  MONTHS,
  SEASON_MAP,
  EVENTS_POOL,
  ESCRITORIO_NOTIFICATIONS,
  CERCADO_NOTIFICATIONS,
} from './gameConstants';

// ── Re-export EconomyState ────────────────────────────────────────────────────

export type { EconomyState };

// ── Helpers ───────────────────────────────────────────────────────────────────

function pickNotification(pool: BuildingNotification[]): BuildingNotification {
  return pool[Math.floor(Math.random() * pool.length)];
}

// ── Reducer ──────────────────────────────────────────────────────────────────

function computePhase(
  pendingDialogue: DialogueTemplate | null,
  pendingDecision: Decision | null,
  hasOpenedBuilding: boolean,
): GamePhase {
  if (pendingDialogue !== null) return 'MonthStart';
  if (pendingDecision !== null) return 'Decisions';
  if (!hasOpenedBuilding) return 'DailyPlanning';
  return 'EstateManagement';
}

let _eventIdCounter = 0;

function nextId(): string {
  return `evt-${++_eventIdCounter}-${Date.now()}`;
}

function randomRanchEvent(month: Month, year: number): GameEvent {
  const text = EVENTS_POOL[Math.floor(Math.random() * EVENTS_POOL.length)];
  return { id: nextId(), month, year, text };
}

function advanceMonthState(state: GameState): GameState {
  const currentIdx = MONTHS.indexOf(state.month);
  const nextIdx = (currentIdx + 1) % 12;
  const nextMonth = MONTHS[nextIdx];
  const nextYear = nextIdx === 0 ? state.year + 1 : state.year;
  const nextSeason = SEASON_MAP[nextMonth];

  const ranchEvent = randomRanchEvent(nextMonth, nextYear);

  const { economy: baseEconomy, economicEvent } = applyMonthToEconomy(
    state.economy,
    nextMonth,
    nextYear,
    nextSeason,
  );

  const contractResult = processMonthlyContracts(state.contracts ?? getInitialContracts(), nextMonth, nextYear);
  const staffResult = processMonthlyStaff(state.staff ?? initialStaff);
  const contractNet = contractResult.income - contractResult.expenses;
  const staffExpense = staffResult.payroll;
  const combinedNet = contractNet - staffExpense;
  const monthlyEvents = [
    ...contractResult.events,
    `Folha salarial da equipa — ${staffExpense.toLocaleString('pt-PT')}€ pagos.`,
    ...staffResult.events,
  ];

  const newEconomy = combinedNet !== 0
    ? {
        ...baseEconomy,
        treasury: baseEconomy.treasury + combinedNet,
        history: baseEconomy.history.map((record, index) => index === 0
          ? {
              ...record,
              income: record.income + contractResult.income,
              expenses: record.expenses + contractResult.expenses + staffExpense,
              profit: record.profit + combinedNet,
              treasury: baseEconomy.treasury + combinedNet,
              events: [...record.events, ...monthlyEvents],
            }
          : record),
      }
    : baseEconomy;

  const { animals: newAnimals, events: animalEvents } = applyMonthlyGrowth(
    state.animals,
    nextMonth,
    nextYear,
    nextSeason,
  );

  const newEvents: GameEvent[] = [ranchEvent];
  if (economicEvent) newEvents.push(economicEvent);
  animalEvents.forEach(ev => {
    newEvents.push({ id: nextId(), month: nextMonth, year: nextYear, text: ev.text });
  });
  monthlyEvents.forEach(text => {
    newEvents.push({ id: nextId(), month: nextMonth, year: nextYear, text, locationId: 'escritorio' });
  });

  const newLog = [...newEvents, ...state.eventLog].slice(0, 20);

  // Each month: 70% chance of escritório notification, 30% chance per cercado
  const newNotifications = { ...state.notifications };
  if (Math.random() < 0.7) {
    newNotifications.escritorio = pickNotification(ESCRITORIO_NOTIFICATIONS);
  }
  if (Math.random() < 0.3) {
    newNotifications.cercado_norte = pickNotification(CERCADO_NOTIFICATIONS);
  }
  if (Math.random() < 0.3) {
    newNotifications.cercado_sul = pickNotification(CERCADO_NOTIFICATIONS);
  }

  const newDecision = Math.random() < 0.55
    ? pickDecision(state.decisionHistory.slice(0, 3).map(r => r.decisionId))
    : null;
  const newDialogue = pickMonthlyDialogue();

  let nextState: GameState = {
    year: nextYear,
    month: nextMonth,
    dayOfMonth: 1,
    dayPeriod: 'manha',
    season: nextSeason,
    eventLog: newLog,
    dayLog: state.dayLog ?? [],
    economy: newEconomy,
    animals: newAnimals,
    notifications: newNotifications,
    pendingDialogue: newDialogue,
    dialogueHistory: state.dialogueHistory,
    relationships: state.relationships,
    characterMemories: state.characterMemories,
    narrativeHistory: state.narrativeHistory,
    lastNarrativeResult: state.lastNarrativeResult,
    prestige: state.prestige,
    contracts: contractResult.contracts,
    staff: staffResult.staff,
    annualReports: state.annualReports ?? [],
    annualObjectives: state.annualObjectives ?? [],
    morningCouncil: [],
    dailyTasks: generateDailyTasks(),
    pendingDecision: newDecision,
    decisionHistory: state.decisionHistory,
    locations: state.locations,
    activeLocationId: null,
    activeLocationEvent: null,
    hasOpenedBuildingThisMonth: false,
    phase: computePhase(newDialogue, newDecision, false),
  };

  if (nextMonth === 'Janeiro') {
    const reportYear = nextYear - 1;
    const report = createAnnualReport(nextState, reportYear, nextMonth);
    const objectives = createAnnualObjectives(nextYear, nextState, nextMonth);
    const achieved = report.objectiveResults.filter(result => result.achieved).length;
    const status = classifyRanchStatus(nextState);

    nextState = {
      ...nextState,
      annualReports: [report, ...(nextState.annualReports ?? [])].slice(0, 10),
      annualObjectives: [
        ...objectives,
        ...(nextState.annualObjectives ?? []).filter(objective => objective.year !== nextYear),
      ].slice(0, 40),
      eventLog: [{
        id: nextId(),
        month: nextMonth,
        year: nextYear,
        text: `Relatório anual ${reportYear}: ${status}. ${achieved}/${report.objectiveResults.length} objetivos cumpridos. Resultado anual: ${report.annualProfit.toLocaleString('pt-PT')}€.` ,
        locationId: 'escritorio' as LocationId,
      }, ...nextState.eventLog].slice(0, 20),
    };
  }

  nextState = {
    ...nextState,
    morningCouncil: createMorningCouncil(nextState),
  };

  return nextState;
}

function withDynamicPrestige(state: GameState): GameState {
  return { ...state, prestige: calculatePrestigeSnapshot(state).score };
}
function closeDayState(state: GameState): GameState {
  const pendingTasks = state.dailyTasks.filter(task => task.status === 'pending');
  const pendingMeetings = state.morningCouncil.filter(item => item.status === 'pending');

  const autoIgnoredTaskRecords = pendingTasks.map(task =>
    createDayRecord(
      state,
      'task_ignored',
      'Tarefa ficou por tratar',
      `${task.label} não foi concluída antes do fim do dia.`,
      state.activeLocationId,
    ),
  );

  const autoPostponedMeetingRecords = pendingMeetings.map(meeting =>
    createDayRecord(
      state,
      'morning_council',
      `Ficou por atender: ${meeting.characterName}`,
      meeting.title,
      'escritorio',
    ),
  );

  let closingState: GameState = {
    ...state,
    dailyTasks: state.dailyTasks.map(task =>
      task.status === 'pending' ? { ...task, status: 'ignored' as const } : task,
    ),
    morningCouncil: state.morningCouncil.map(item =>
      item.status === 'pending' ? { ...item, status: 'postponed' as const } : item,
    ),
  };

  pendingMeetings.forEach(meeting => {
    closingState = applyRelationshipShift(closingState, meeting.characterId, { trust: -1, fatigue: 1, tension: 1 });
    closingState = addCharacterMemory(closingState, createCharacterMemory(
      meeting.characterId,
      'meeting_postponed',
      `Ficou por atender: ${meeting.title}`,
      `${meeting.characterName} esperou durante o dia, mas o assunto não foi tratado.`,
      state.month,
      state.year,
      meeting.urgency === 'critica' ? 5 : meeting.urgency === 'alta' ? 3 : 1,
      'escritorio',
    ));
  });

  const summary = summarizeDay(closingState);
  const continuityLine = buildDiaryContinuityLine(closingState);
  const alphaChronicle = createAlphaDayChronicle(closingState);
  const closeRecord = createDayRecord(closingState, 'day_closed', `Crónica do dia ${state.dayOfMonth}`, alphaChronicle, 'escritorio');
  const unresolvedText = pendingMeetings.length > 0 || pendingTasks.length > 0
    ? ` Ficaram por tratar ${pendingMeetings.length} assunto(s) e ${pendingTasks.length} tarefa(s).`
    : '';
  const event = { id: nextId(), month: state.month, year: state.year, text: `${summary}${unresolvedText} ${continuityLine} ${alphaChronicle}`, locationId: 'escritorio' as LocationId };
  const closingDayLog = [
    closeRecord,
    ...autoPostponedMeetingRecords,
    ...autoIgnoredTaskRecords,
    ...(closingState.dayLog ?? []),
  ].slice(0, 140);

  if (state.dayOfMonth >= 28) {
    const monthlyState = advanceMonthState({
      ...closingState,
      dayLog: closingDayLog,
      eventLog: [event, ...closingState.eventLog].slice(0, 30),
    });
    return {
      ...monthlyState,
      dayLog: monthlyState.dayLog,
      eventLog: monthlyState.eventLog,
    };
  }

  const nextBase: GameState = {
    ...closingState,
    dayOfMonth: state.dayOfMonth + 1,
    dayPeriod: 'manha',
    dayLog: closingDayLog,
    eventLog: [event, ...closingState.eventLog].slice(0, 30),
    dailyTasks: generateDailyTasks(),
    morningCouncil: [],
    pendingDialogue: null,
    activeLocationId: null,
    activeLocationEvent: null,
    hasOpenedBuildingThisMonth: false,
    phase: 'DailyPlanning',
  };

  return {
    ...nextBase,
    morningCouncil: createMorningCouncil(nextBase),
  };
}


function reducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case 'ADVANCE_MONTH':
      return withDynamicPrestige(advanceMonthState(state));
    case 'ADVANCE_DAY_PERIOD': {
      if (isLastDayPeriod(state.dayPeriod)) return state;
      const nextPeriod = getNextDayPeriod(state.dayPeriod);
      const simulation = simulateWorldStep(state, nextPeriod);
      const periodRecord = createDayRecord(
        state,
        'period_advanced',
        `Avançou para ${DAY_PERIOD_LABELS[nextPeriod]}`,
        `O dia ${state.dayOfMonth} avançou para ${DAY_PERIOD_LABELS[nextPeriod].toLowerCase()}.`,
        state.activeLocationId,
      );

      const routineRecords = simulation.routineLines.map(line =>
        createDayRecord(
          { ...state, dayPeriod: nextPeriod },
          'routine',
          'Rotina da herdade',
          line,
          state.activeLocationId,
        ),
      );

      const worldRecords = simulation.events.map(worldEvent =>
        createDayRecord(
          { ...state, dayPeriod: nextPeriod },
          'world_event',
          worldEvent.title,
          worldEvent.description,
          worldEvent.locationId,
        ),
      );

      let nextState: GameState = {
        ...state,
        dayPeriod: nextPeriod,
        dayLog: [periodRecord, ...worldRecords, ...routineRecords, ...(state.dayLog ?? [])].slice(0, 160),
        eventLog: [
          ...simulation.events.map(worldEvent => ({
            id: nextId(),
            month: state.month,
            year: state.year,
            text: `${worldEvent.title} — ${worldEvent.description}`,
            locationId: worldEvent.locationId,
          })),
          ...state.eventLog,
        ].slice(0, 40),
        economy: simulation.events.some(worldEvent => worldEvent.treasury)
          ? {
              ...state.economy,
              treasury: Math.max(0, state.economy.treasury + simulation.events.reduce((sum, worldEvent) => sum + (worldEvent.treasury ?? 0), 0)),
            }
          : state.economy,
        prestige: Math.max(0, Math.min(100, state.prestige + simulation.events.reduce((sum, worldEvent) => sum + (worldEvent.prestige ?? 0), 0))),
      };

      simulation.events.forEach(worldEvent => {
        if (worldEvent.condition) {
          nextState = { ...nextState, locations: updateLocationCondition(nextState.locations, worldEvent.locationId, worldEvent.condition) };
        }
        if (worldEvent.notification) {
          nextState = { ...nextState, locations: addLocationNotification(nextState.locations, worldEvent.locationId, worldEvent.notification) };
        }
        if (worldEvent.characterId) {
          nextState = addCharacterMemory(nextState, createCharacterMemory(
            worldEvent.characterId,
            'warning',
            worldEvent.title,
            worldEvent.description,
            state.month,
            state.year,
            worldEvent.memoryWeight ?? 1,
            worldEvent.locationId,
          ));
        }
      });

      return withDynamicPrestige(nextState);
    }
    case 'CLOSE_DAY':
      return withDynamicPrestige(closeDayState(state));
    case 'DISMISS_NOTIFICATION': {
      const notifications = { ...state.notifications };
      delete notifications[action.building];
      return { ...state, notifications };
    }
    case 'ANSWER_DIALOGUE': {
      if (!state.pendingDialogue) return state;
      const dialogueId = state.pendingDialogue.id;
      const record: DialogueRecord = {
        dialogueId,
        choice: action.choice,
        month: state.month,
        year: state.year,
      };

      const baseState: GameState = {
        ...state,
        pendingDialogue: null,
        dialogueHistory: [record, ...state.dialogueHistory],
      };

      const { state: stateWithEffects, resultText, appliedEffects } = applyNarrativeChoice(
        baseState,
        dialogueId,
        action.choice,
        nextId,
        state.activeLocationId,
      );

      let finalState: GameState = {
        ...stateWithEffects,
        lastNarrativeResult: resultText
          ? { resultText, choice: action.choice, characterId: 'maioral', appliedEffects, locationId: state.activeLocationId }
          : stateWithEffects.lastNarrativeResult,
        phase: computePhase(null, state.pendingDecision, state.hasOpenedBuildingThisMonth),
      };

      if (resultText) {
        finalState = addCharacterMemory(finalState, createCharacterMemory(
          'maioral',
          'narrative_choice',
          `Escolha: ${action.choice}`,
          resultText,
          state.month,
          state.year,
          Math.max(1, appliedEffects.length),
          state.activeLocationId,
        ));
      }

      return withDynamicPrestige(finalState);
    }
    case 'DISMISS_NARRATIVE_RESULT': {
      return { ...state, lastNarrativeResult: null };
    }
    case 'ATTEND_MORNING_MEETING': {
      const meeting = state.morningCouncil.find(item => item.id === action.id);
      if (!meeting) return state;
      const dialogue = meeting.dialogueId ? getDialogueById(meeting.dialogueId) ?? null : null;
      const linkedLocationEvent = meeting.locationId !== 'escritorio'
        ? createLocationEvent(state, meeting.locationId)
        : state.activeLocationEvent;
      let nextState: GameState = {
        ...state,
        pendingDialogue: dialogue ?? state.pendingDialogue,
        activeLocationId: meeting.locationId,
        activeLocationEvent: linkedLocationEvent,
        morningCouncil: state.morningCouncil.map(item =>
          item.id === action.id ? { ...item, status: 'attended' as const } : item,
        ),
        eventLog: [{
          id: nextId(),
          month: state.month,
          year: state.year,
          text: `Conselho da manhã — ${meeting.characterName}: ${meeting.title}.${meeting.locationId !== 'escritorio' ? ` Encaminha para ${meeting.locationId}.` : ''}`,
          locationId: 'escritorio' as LocationId,
        }, ...state.eventLog].slice(0, 30),
        dayLog: [createDayRecord(state, 'morning_council', `Atendido: ${meeting.characterName}`, meeting.title, 'escritorio'), ...(state.dayLog ?? [])].slice(0, 120),
        phase: computePhase(dialogue ?? state.pendingDialogue, state.pendingDecision, state.hasOpenedBuildingThisMonth),
      };
      nextState = applyRelationshipShift(nextState, meeting.characterId, { trust: 1, respect: 1, tension: -1 });
      nextState = addCharacterMemory(nextState, createCharacterMemory(
        meeting.characterId,
        'meeting_attended',
        `Atendido: ${meeting.title}`,
        `${meeting.characterName} foi recebido no escritório e o assunto ficou em andamento.`,
        state.month,
        state.year,
        meeting.urgency === 'critica' ? 4 : meeting.urgency === 'alta' ? 3 : 2,
        'escritorio',
      ));
      return withDynamicPrestige(nextState);
    }
    case 'POSTPONE_MORNING_MEETING': {
      const meeting = state.morningCouncil.find(item => item.id === action.id);
      if (!meeting) return state;
      let nextState: GameState = {
        ...state,
        morningCouncil: state.morningCouncil.map(item =>
          item.id === action.id ? { ...item, status: 'postponed' as const } : item,
        ),
        eventLog: [{
          id: nextId(),
          month: state.month,
          year: state.year,
          text: `Assunto adiado — ${meeting.characterName}: ${meeting.title}.`,
          locationId: 'escritorio' as LocationId,
        }, ...state.eventLog].slice(0, 30),
        dayLog: [createDayRecord(state, 'morning_council', `Adiado: ${meeting.characterName}`, meeting.title, 'escritorio'), ...(state.dayLog ?? [])].slice(0, 120),
      };
      nextState = applyRelationshipShift(nextState, meeting.characterId, { trust: -1, fatigue: 2, tension: 2 });
      nextState = addCharacterMemory(nextState, createCharacterMemory(
        meeting.characterId,
        'meeting_postponed',
        `Adiado: ${meeting.title}`,
        `${meeting.characterName} ficou à espera. O assunto não foi tratado neste mês.`,
        state.month,
        state.year,
        meeting.urgency === 'critica' ? 5 : meeting.urgency === 'alta' ? 3 : 1,
        'escritorio',
      ));
      return withDynamicPrestige(nextState);
    }
    case 'RESOLVE_PROFESSIONAL_CONFLICT': {
      const meeting = state.morningCouncil.find(item => item.id === action.id);
      const conflict = meeting?.professionalConflict;
      if (!meeting || !conflict) return state;

      const chosePrimary = action.choice === 'primary';
      const chosenId = chosePrimary ? conflict.primaryCharacterId : conflict.secondaryCharacterId;
      const otherId = chosePrimary ? conflict.secondaryCharacterId : conflict.primaryCharacterId;
      const chosenName = chosePrimary ? conflict.primaryCharacterName : conflict.secondaryCharacterName;
      const otherName = chosePrimary ? conflict.secondaryCharacterName : conflict.primaryCharacterName;
      const resultText = chosePrimary
        ? `${chosenName} sai reforçado: a casa opta por prudência de maneio e controlo de custos. ${otherName} aceita, mas fica a observar o risco clínico.`
        : `${chosenName} sai reforçado: a casa assume a prevenção sanitária mesmo com custo imediato. ${otherName} respeita a decisão, mas avisa que a tesouraria também é sanidade.`;

      let nextState: GameState = {
        ...state,
        economy: chosePrimary
          ? { ...state.economy, treasury: state.economy.treasury + 750 }
          : { ...state.economy, treasury: Math.max(0, state.economy.treasury - 1500) },
        prestige: chosePrimary ? state.prestige : Math.min(100, state.prestige + 1),
        morningCouncil: state.morningCouncil.map(item =>
          item.id === action.id ? { ...item, status: 'attended' as const } : item,
        ),
        activeLocationId: meeting.locationId,
        eventLog: [{
          id: nextId(),
          month: state.month,
          year: state.year,
          text: `Conflito técnico resolvido — ${meeting.title}: ${chosePrimary ? conflict.primaryChoiceLabel : conflict.secondaryChoiceLabel}.`,
          locationId: 'escritorio' as LocationId,
        }, ...state.eventLog].slice(0, 30),
        lastNarrativeResult: {
          resultText,
          choice: chosePrimary ? conflict.primaryChoiceLabel : conflict.secondaryChoiceLabel,
          characterId: chosenId,
          appliedEffects: [],
          locationId: 'escritorio' as LocationId,
        },
      };

      nextState = applyRelationshipShift(nextState, chosenId, { trust: 3, respect: 2, tension: -2 });
      nextState = applyRelationshipShift(nextState, otherId, { trust: -1, respect: -1, tension: 3 });
      nextState = addCharacterMemory(nextState, createCharacterMemory(
        chosenId,
        'professional_conflict',
        `Apoiado: ${meeting.title}`,
        `O patrão escolheu seguir ${chosenName} no conflito técnico com ${otherName}.`,
        state.month,
        state.year,
        meeting.urgency === 'critica' ? 5 : 4,
        'escritorio',
      ));
      nextState = addCharacterMemory(nextState, createCharacterMemory(
        otherId,
        'professional_conflict',
        `Contrariado: ${meeting.title}`,
        `O patrão não seguiu o parecer de ${otherName} no conflito técnico com ${chosenName}.`,
        state.month,
        state.year,
        meeting.urgency === 'critica' ? 4 : 3,
        'escritorio',
      ));
      return withDynamicPrestige(nextState);
    }
    case 'ACCEPT_CONTRACT': {
      const contract = state.contracts.find(c => c.id === action.id);
      if (!contract || contract.status !== 'offered') return state;
      const validation = canAcceptContract(contract, state);
      if (!validation.ok) {
        return {
          ...state,
          eventLog: [{ id: nextId(), month: state.month, year: state.year, text: `Contrato recusado administrativamente — ${validation.reason}.`, locationId: 'escritorio' }, ...state.eventLog].slice(0, 20),
        };
      }
      const upfrontIncome = contract.upfrontIncome ?? 0;
      const upfrontExpense = contract.upfrontExpense ?? 0;
      const net = upfrontIncome - upfrontExpense;
      return withDynamicPrestige({
        ...state,
        contracts: acceptContract(state.contracts, action.id),
        prestige: Math.max(0, Math.min(100, state.prestige + (contract.prestigeEffect ?? 0))),
        economy: {
          ...state.economy,
          treasury: state.economy.treasury + net,
        },
        eventLog: [{
          id: nextId(),
          month: state.month,
          year: state.year,
          text: `Contrato aceite — ${contract.title}. Movimento inicial: +${upfrontIncome.toLocaleString('pt-PT')}€ / -${upfrontExpense.toLocaleString('pt-PT')}€.` ,
          locationId: contract.locationId ?? 'escritorio',
        }, ...state.eventLog].slice(0, 20),
      });
    }
    case 'REJECT_CONTRACT': {
      const contract = state.contracts.find(c => c.id === action.id);
      if (!contract || contract.status !== 'offered') return state;
      return {
        ...state,
        contracts: rejectContract(state.contracts, action.id),
        eventLog: [{ id: nextId(), month: state.month, year: state.year, text: `Contrato recusado — ${contract.title}.`, locationId: contract.locationId ?? 'escritorio' }, ...state.eventLog].slice(0, 20),
      };
    }
    case 'GIVE_STAFF_REST': {
      const member = state.staff.find(staff => staff.id === action.id);
      if (!member) return state;
      return {
        ...state,
        staff: giveStaffRest(state.staff, action.id),
        eventLog: [{ id: nextId(), month: state.month, year: state.year, text: `${member.name} ficou de descanso para recuperar antes dos próximos trabalhos.`, locationId: 'escritorio' }, ...state.eventLog].slice(0, 20),
      };
    }
    case 'GIVE_STAFF_BONUS': {
      const member = state.staff.find(staff => staff.id === action.id);
      if (!member) return state;
      const bonus = 1000;
      return withDynamicPrestige({
        ...state,
        staff: giveStaffBonus(state.staff, action.id),
        economy: { ...state.economy, treasury: state.economy.treasury - bonus },
        eventLog: [{ id: nextId(), month: state.month, year: state.year, text: `Bónus atribuído a ${member.name} — ${bonus.toLocaleString('pt-PT')}€ pagos pela casa.`, locationId: 'escritorio' }, ...state.eventLog].slice(0, 20),
      });
    }
    case 'TRAIN_STAFF': {
      const member = state.staff.find(staff => staff.id === action.id);
      if (!member) return state;
      const cost = 1500;
      return withDynamicPrestige({
        ...state,
        staff: trainStaff(state.staff, action.id),
        economy: { ...state.economy, treasury: state.economy.treasury - cost },
        eventLog: [{ id: nextId(), month: state.month, year: state.year, text: `${member.name} recebeu formação prática — ${cost.toLocaleString('pt-PT')}€ investidos.`, locationId: 'escritorio' }, ...state.eventLog].slice(0, 20),
      });
    }
    case 'COMPLETE_TASK': {
      const task = state.dailyTasks.find(t => t.id === action.id);
      return {
        ...state,
        dailyTasks: state.dailyTasks.map(t =>
          t.id === action.id ? { ...t, status: 'completed' } : t
        ),
        dayLog: task ? [createDayRecord(state, 'task_completed', 'Tarefa concluída', task.label, state.activeLocationId), ...(state.dayLog ?? [])].slice(0, 120) : state.dayLog,
      };
    }
    case 'IGNORE_TASK': {
      const task = state.dailyTasks.find(t => t.id === action.id);
      return {
        ...state,
        dailyTasks: state.dailyTasks.map(t =>
          t.id === action.id ? { ...t, status: 'ignored' } : t
        ),
        dayLog: task ? [createDayRecord(state, 'task_ignored', 'Tarefa ignorada', task.label, state.activeLocationId), ...(state.dayLog ?? [])].slice(0, 120) : state.dayLog,
      };
    }
    case 'RESOLVE_DECISION': {
      if (!state.pendingDecision) return state;
      const record: DecisionRecord = {
        instanceId: nextDecisionInstanceId(),
        decisionId: state.pendingDecision.id,
        title: state.pendingDecision.title,
        category: state.pendingDecision.category,
        choice: action.choice,
        month: state.month,
        year: state.year,
        result: null,
      };
      return withDynamicPrestige({
        ...state,
        pendingDecision: null,
        decisionHistory: [record, ...state.decisionHistory],
        phase: computePhase(state.pendingDialogue, null, state.hasOpenedBuildingThisMonth),
      });
    }
    case 'SET_ACTIVE_LOCATION': {
      const opened = action.id !== null ? true : state.hasOpenedBuildingThisMonth;
      const recentDialogueIds = state.dialogueHistory.slice(0, 4).map(record => record.dialogueId);
      const locationDialogue = action.id && !state.pendingDialogue && !state.lastNarrativeResult
        ? pickDialogueForLocation(action.id, recentDialogueIds)
        : null;
      const location = action.id ? state.locations.find(loc => loc.id === action.id) : null;
      const locationEvent = action.id ? createLocationEvent(state, action.id) : null;
      return {
        ...state,
        activeLocationId: action.id,
        activeLocationEvent: locationEvent,
        pendingDialogue: locationDialogue ?? state.pendingDialogue,
        hasOpenedBuildingThisMonth: opened,
        dayLog: location ? [createDayRecord(state, 'location_visit', `Visita: ${location.name}`, location.description, action.id), ...(state.dayLog ?? [])].slice(0, 120) : state.dayLog,
        phase: computePhase(locationDialogue ?? state.pendingDialogue, state.pendingDecision, opened),
      };
    }
    case 'RESOLVE_LOCATION_EVENT': {
      const activeEvent = state.activeLocationEvent;
      if (!activeEvent) return state;
      const choice = activeEvent.choices.find(item => item.id === action.choiceId);
      if (!choice) return state;
      const effects = choice.effects;
      let locations = state.locations;
      if (effects.condition) locations = updateLocationCondition(locations, activeEvent.locationId, effects.condition);
      if (effects.addNotification) locations = addLocationNotification(locations, activeEvent.locationId, effects.addNotification);
      if (effects.clearNotification) locations = clearLocationNotification(locations, activeEvent.locationId, effects.clearNotification);

      let nextState: GameState = {
        ...state,
        locations,
        activeLocationEvent: null,
        economy: effects.treasury
          ? { ...state.economy, treasury: Math.max(0, state.economy.treasury + effects.treasury) }
          : state.economy,
        prestige: effects.prestige
          ? Math.max(0, Math.min(100, state.prestige + effects.prestige))
          : state.prestige,
        eventLog: [{
          id: nextId(),
          month: state.month,
          year: state.year,
          text: `${activeEvent.title} — ${choice.result}`,
          locationId: activeEvent.locationId,
        }, ...state.eventLog].slice(0, 30),
        dayLog: [createDayRecord(
          state,
          'location_event',
          `Quadro resolvido: ${activeEvent.title}`,
          `Evento de quadro resolvido — ${activeEvent.id}. ${choice.result}`,
          activeEvent.locationId,
        ), ...(state.dayLog ?? [])].slice(0, 140),
        lastNarrativeResult: {
          resultText: choice.result,
          choice: choice.label,
          characterId: activeEvent.characterId,
          appliedEffects: [],
          locationId: activeEvent.locationId,
        },
      };

      if (effects.relationship) {
        const { characterId, ...shift } = effects.relationship;
        nextState = applyRelationshipShift(nextState, characterId, shift);
        nextState = addCharacterMemory(nextState, createCharacterMemory(
          characterId,
          'location_event',
          activeEvent.title,
          choice.result,
          state.month,
          state.year,
          activeEvent.severity === 'critica' ? 5 : activeEvent.severity === 'alta' ? 4 : 2,
          activeEvent.locationId,
        ));
      }

      return withDynamicPrestige(nextState);
    }
    case 'UPDATE_LOCATION_CONDITION':
      return { ...state, locations: updateLocationCondition(state.locations, action.id, action.condition) };
    case 'ADD_LOCATION_NOTIFICATION':
      return { ...state, locations: addLocationNotification(state.locations, action.id, action.notification) };
    case 'CLEAR_LOCATION_NOTIFICATION':
      return { ...state, locations: clearLocationNotification(state.locations, action.id, action.notification) };
    case 'UPDATE_LOCATION_OCCUPATION':
      return { ...state, locations: updateLocationOccupation(state.locations, action.id, action.occupation) };
    case 'SET_PHASE':
      return { ...state, phase: action.phase };
    case 'LOAD_GAME_STATE':
      return withDynamicPrestige(action.state);
    default:
      return state;
  }
}

// ── Initial state ────────────────────────────────────────────────────────────

const INITIAL_STATE_BASE: GameState = {
  year: 1985,
  month: 'Março',
  dayOfMonth: 1,
  dayPeriod: 'manha',
  season: 'Primavera',
  eventLog: [
    {
      id: 'evt-0',
      month: 'Março',
      year: 1985,
      text: 'A Herdade da Ferraria inicia uma nova época. Que seja próspera.',
    },
  ],
  dayLog: [],
  economy: INITIAL_ECONOMY,
  animals: initialAnimals,
  notifications: {},
  pendingDialogue: GREETING_DIALOGUE,
  dialogueHistory: [],
  relationships: INITIAL_RELATIONSHIPS,
  characterMemories: [],
  narrativeHistory: [],
  lastNarrativeResult: null,
  prestige: 50,
  contracts: getInitialContracts(),
  staff: initialStaff,
  annualReports: [],
  annualObjectives: [],
  morningCouncil: [],
  dailyTasks: generateDailyTasks(),
  pendingDecision: OPENING_DECISION,
  decisionHistory: [],
  locations: INITIAL_LOCATIONS,
  activeLocationId: null,
  activeLocationEvent: null,
  hasOpenedBuildingThisMonth: false,
  phase: 'MonthStart' as GamePhase,
};

const INITIAL_STATE_WITH_OBJECTIVES: GameState = withDynamicPrestige({
  ...INITIAL_STATE_BASE,
  annualObjectives: createAnnualObjectives(1985, INITIAL_STATE_BASE, 'Março'),
});

const INITIAL_STATE: GameState = {
  ...INITIAL_STATE_WITH_OBJECTIVES,
  morningCouncil: createMorningCouncil(INITIAL_STATE_WITH_OBJECTIVES),
};

// ── Context ──────────────────────────────────────────────────────────────────

interface GameStateContextValue {
  state: GameState;
  advanceMonth: () => void;
  advanceDayPeriod: () => void;
  closeDay: () => void;
  dismissNotification: (building: BuildingKey) => void;
  answerDialogue: (choice: string) => void;
  dismissNarrativeResult: () => void;
  attendMorningMeeting: (id: string) => void;
  postponeMorningMeeting: (id: string) => void;
  resolveProfessionalConflict: (id: string, choice: ProfessionalConflictChoice) => void;
  acceptContract: (id: string) => void;
  rejectContract: (id: string) => void;
  giveStaffRest: (id: string) => void;
  giveStaffBonus: (id: string) => void;
  trainStaff: (id: string) => void;
  completeTask: (id: string) => void;
  ignoreTask: (id: string) => void;
  resolveDecision: (choice: string) => void;
  setActiveLocation: (id: LocationId | null) => void;
  resolveLocationEvent: (choiceId: string) => void;
  updateLocationCondition: (id: LocationId, condition: LocationCondition) => void;
  addLocationNotification: (id: LocationId, notification: LocationNotification) => void;
  clearLocationNotification: (id: LocationId, notification: LocationNotification) => void;
  updateLocationOccupation: (id: LocationId, occupation: number) => void;
  setPhase: (phase: GamePhase) => void;
  saveGame: () => void;
  loadGame: (state: GameState) => void;
}


const GameStateContext = createContext<GameStateContextValue | null>(null);

function hydrateLoadedState(state: GameState): GameState {
  return withDynamicPrestige({
    ...state,
    contracts: hydrateContracts(state.contracts),
    dayOfMonth: state.dayOfMonth ?? 1,
    dayPeriod: state.dayPeriod ?? 'manha',
    dayLog: state.dayLog ?? [],
    relationships: state.relationships ?? INITIAL_RELATIONSHIPS,
    characterMemories: state.characterMemories ?? [],
    narrativeHistory: state.narrativeHistory ?? [],
    lastNarrativeResult: state.lastNarrativeResult ?? null,
    locations: state.locations ?? INITIAL_LOCATIONS,
    activeLocationEvent: state.activeLocationEvent ?? null,
    staff: state.staff ?? initialStaff,
    annualReports: state.annualReports ?? [],
    annualObjectives: state.annualObjectives && state.annualObjectives.length > 0
      ? state.annualObjectives
      : createAnnualObjectives(state.year ?? 1985, state, state.month ?? 'Março'),
    morningCouncil: state.morningCouncil && !shouldRefreshMorningCouncil(state)
      ? state.morningCouncil
      : createMorningCouncil(state),
  });
}

function loadInitialState(): GameState {
  const saved = loadCampaign();
  return saved?.state ? hydrateLoadedState(saved.state) : INITIAL_STATE;
}

export const GameStateProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(reducer, undefined, loadInitialState);

  const advance = () => dispatch({ type: 'ADVANCE_MONTH' });
  const advanceDayPeriod = () => dispatch({ type: 'ADVANCE_DAY_PERIOD' });
  const closeDay = () => dispatch({ type: 'CLOSE_DAY' });
  const dismissNotification = (building: BuildingKey) =>
    dispatch({ type: 'DISMISS_NOTIFICATION', building });
  const answerDialogue = (choice: string) =>
    dispatch({ type: 'ANSWER_DIALOGUE', choice });
  const dismissNarrativeResult = () =>
    dispatch({ type: 'DISMISS_NARRATIVE_RESULT' });
  const attendMorningMeeting = (id: string) =>
    dispatch({ type: 'ATTEND_MORNING_MEETING', id });
  const postponeMorningMeeting = (id: string) =>
    dispatch({ type: 'POSTPONE_MORNING_MEETING', id });
  const resolveProfessionalConflict = (id: string, choice: ProfessionalConflictChoice) =>
    dispatch({ type: 'RESOLVE_PROFESSIONAL_CONFLICT', id, choice });
  const acceptContractAction = (id: string) =>
    dispatch({ type: 'ACCEPT_CONTRACT', id });
  const rejectContractAction = (id: string) =>
    dispatch({ type: 'REJECT_CONTRACT', id });
  const giveStaffRestAction = (id: string) =>
    dispatch({ type: 'GIVE_STAFF_REST', id });
  const giveStaffBonusAction = (id: string) =>
    dispatch({ type: 'GIVE_STAFF_BONUS', id });
  const trainStaffAction = (id: string) =>
    dispatch({ type: 'TRAIN_STAFF', id });
  const completeTask = (id: string) =>
    dispatch({ type: 'COMPLETE_TASK', id });
  const ignoreTask = (id: string) =>
    dispatch({ type: 'IGNORE_TASK', id });
  const resolveDecision = (choice: string) =>
    dispatch({ type: 'RESOLVE_DECISION', choice });
  const setActiveLocation = (id: LocationId | null) =>
    dispatch({ type: 'SET_ACTIVE_LOCATION', id });
  const resolveLocationEvent = (choiceId: string) =>
    dispatch({ type: 'RESOLVE_LOCATION_EVENT', choiceId });
  const updateLocationCondition = (id: LocationId, condition: LocationCondition) =>
    dispatch({ type: 'UPDATE_LOCATION_CONDITION', id, condition });
  const addLocationNotification = (id: LocationId, notification: LocationNotification) =>
    dispatch({ type: 'ADD_LOCATION_NOTIFICATION', id, notification });
  const clearLocationNotification = (id: LocationId, notification: LocationNotification) =>
    dispatch({ type: 'CLEAR_LOCATION_NOTIFICATION', id, notification });
  const updateLocationOccupation = (id: LocationId, occupation: number) =>
    dispatch({ type: 'UPDATE_LOCATION_OCCUPATION', id, occupation });
  const setPhase = (phase: GamePhase) =>
    dispatch({ type: 'SET_PHASE', phase });
  const saveGame = () => {
    saveCampaign(state);
  };
  const loadGame = (loadedState: GameState) =>
    dispatch({ type: 'LOAD_GAME_STATE', state: loadedState });

  useEffect(() => {
    saveCampaign(state);
  }, [state.year, state.month, state.eventLog, state.economy, state.animals, state.decisionHistory, state.dialogueHistory, state.narrativeHistory, state.characterMemories, state.contracts, state.staff, state.morningCouncil, state.dayOfMonth, state.dayPeriod, state.dayLog, state.activeLocationEvent]);

  return (
    <GameStateContext.Provider value={{
      state, advanceMonth: advance, advanceDayPeriod, closeDay, dismissNotification, answerDialogue, dismissNarrativeResult,
      attendMorningMeeting, postponeMorningMeeting, resolveProfessionalConflict,
      acceptContract: acceptContractAction, rejectContract: rejectContractAction,
      giveStaffRest: giveStaffRestAction, giveStaffBonus: giveStaffBonusAction, trainStaff: trainStaffAction,
      completeTask, ignoreTask, resolveDecision,
      setActiveLocation, resolveLocationEvent, updateLocationCondition, addLocationNotification,
      clearLocationNotification, updateLocationOccupation, setPhase, saveGame, loadGame,
    }}>
      {children}
    </GameStateContext.Provider>
  );
};

export function useGameState(): GameStateContextValue {
  const ctx = useContext(GameStateContext);
  if (!ctx) throw new Error('useGameState must be used inside GameStateProvider');
  return ctx;
}
