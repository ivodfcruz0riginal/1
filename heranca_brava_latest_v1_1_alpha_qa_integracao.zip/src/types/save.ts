import type { GameState } from '../store/gameTypes';

export const SAVE_VERSION = 1;
export const SAVE_STORAGE_KEY = 'heranca-brava:campaign-save:v1';

export interface CampaignSave {
  version: number;
  savedAt: string;
  state: GameState;
}

export interface SaveSummary {
  exists: boolean;
  version?: number;
  savedAt?: string;
  year?: number;
  month?: string;
  treasury?: number;
  prestige?: number;
  animals?: number;
}
