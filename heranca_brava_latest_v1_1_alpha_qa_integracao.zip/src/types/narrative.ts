import type { Month } from '../store/gameTypes';
import type { LocationId } from './location';

export type NarrativeCharacterId =
  | 'maioral'
  | 'veterinario'
  | 'campino'
  | 'administrador'
  | 'familia'
  | 'empresario';

export type NarrativeEffectTarget =
  | 'treasury'
  | 'relationship'
  | 'animalHealth'
  | 'eventLog'
  | 'prestige';

export interface NarrativeEffect {
  target: NarrativeEffectTarget;
  value?: number;
  characterId?: NarrativeCharacterId;
  animalCategory?: string;
  message?: string;
}

export interface NarrativeChoice {
  label: string;
  effects: NarrativeEffect[];
  resultText: string;
}

export interface NarrativeEvent {
  id: string;
  dialogueId: string;
  characterId: NarrativeCharacterId;
  locationIds?: LocationId[];
  choices: NarrativeChoice[];
}

export interface NarrativeRelationshipState {
  trust: number;
  respect: number;
  fatigue: number;
  loyalty: number;
  affinity?: number;
  tension?: number;
}

export type NarrativeRelationships = Record<NarrativeCharacterId, NarrativeRelationshipState>;

export interface NarrativeHistoryRecord {
  id: string;
  dialogueId: string;
  characterId: NarrativeCharacterId;
  choice: string;
  resultText: string;
  month: Month;
  year: number;
  appliedEffects: NarrativeEffect[];
  locationId?: LocationId | null;
}
