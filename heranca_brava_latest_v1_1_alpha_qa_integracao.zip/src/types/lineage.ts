import type { Animal } from './animal';

export interface LineageTraitAverages {
  bravery: number;
  nobility: number;
  mobility: number;
  stamina: number;
  transmission: number;
  fertility: number;
}

export interface LineageSummary {
  id: string;
  name: string;
  totalAnimals: number;
  activeAnimals: number;
  breedingAnimals: number;
  sementais: number;
  vacas: number;
  youngAnimals: number;
  averageAgeYears: number;
  averageTraits: LineageTraitAverages;
  influenceScore: number;
  foundingFemales: Animal[];
  keySires: Animal[];
  recentYoung: Animal[];
  riskLevel: 'baixo' | 'medio' | 'alto';
  note: string;
}

export interface AnimalLineageTrail {
  animal: Animal;
  father?: Animal;
  mother?: Animal;
  paternalGrandfather?: Animal;
  paternalGrandmother?: Animal;
  maternalGrandfather?: Animal;
  maternalGrandmother?: Animal;
  generationDepth: number;
  knownAncestors: number;
  readableTrail: string[];
}
