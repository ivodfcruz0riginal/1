import type { LocationId, LocationCondition, LocationNotification } from './location';
import type { NarrativeCharacterId } from './narrative';

export type LocationEventSeverity = 'baixa' | 'media' | 'alta' | 'critica';

export type LocationEventEffect = {
  treasury?: number;
  prestige?: number;
  condition?: LocationCondition;
  addNotification?: LocationNotification;
  clearNotification?: LocationNotification;
  relationship?: {
    characterId: NarrativeCharacterId;
    trust?: number;
    respect?: number;
    fatigue?: number;
    loyalty?: number;
    affinity?: number;
    tension?: number;
  };
};

export interface LocationEventChoice {
  id: string;
  label: string;
  result: string;
  effects: LocationEventEffect;
}

export interface LocationEventTemplate {
  id: string;
  locationId: LocationId;
  title: string;
  description: string;
  characterId: NarrativeCharacterId;
  characterName: string;
  severity: LocationEventSeverity;
  condition?: {
    minTreasury?: number;
    maxTreasury?: number;
    notification?: LocationNotification;
    maxOccupationRatio?: number;
    minOccupationRatio?: number;
    seasons?: string[];
  };
  choices: LocationEventChoice[];
}

export interface ActiveLocationEvent extends LocationEventTemplate {
  instanceId: string;
  dayOfMonth: number;
  month: string;
  year: number;
}
