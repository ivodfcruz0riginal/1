import type { LocationId } from './location';
import type { NarrativeCharacterId } from './narrative';

export type MeetingUrgency = 'baixa' | 'normal' | 'alta' | 'critica';
export type MeetingStatus = 'pending' | 'attended' | 'postponed';
export type ProfessionalConflictChoice = 'primary' | 'secondary';

export type OfficeTabKey =
  | 'diario'
  | 'jornal'
  | 'economia'
  | 'calendario'
  | 'contratos'
  | 'pessoal'
  | 'campanha'
  | 'livro'
  | 'prestigio'
  | 'administracao';

export interface ProfessionalConflict {
  id: string;
  type: 'sanidade_vs_maneio' | 'gestao_vs_tradicao' | 'prestigio_vs_prudencia';
  primaryCharacterId: NarrativeCharacterId;
  primaryCharacterName: string;
  secondaryCharacterId: NarrativeCharacterId;
  secondaryCharacterName: string;
  primaryLine: string;
  secondaryLine: string;
  stakes: string;
  primaryChoiceLabel: string;
  secondaryChoiceLabel: string;
  memoryHint?: string;
}

export interface MorningCouncilItem {
  id: string;
  monthKey: string;
  characterId: NarrativeCharacterId;
  characterName: string;
  role: string;
  title: string;
  summary: string;
  urgency: MeetingUrgency;
  locationId: LocationId;
  dialogueId?: string;
  recommendedTab?: OfficeTabKey;
  status: MeetingStatus;
  availabilityNote?: string;
  substituteFor?: NarrativeCharacterId;
  professionalConflict?: ProfessionalConflict;
}


