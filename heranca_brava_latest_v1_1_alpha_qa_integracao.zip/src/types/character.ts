import type { Month } from '../store/gameTypes';
import type { NarrativeCharacterId } from './narrative';
import type { LocationId } from './location';
import type { Season } from '../store/gameTypes';

export type CharacterRole =
  | 'maioral'
  | 'veterinario'
  | 'administrador'
  | 'campino'
  | 'familia'
  | 'empresario';

export type CharacterTemperament =
  | 'tradicional'
  | 'metodico'
  | 'prudente'
  | 'impulsivo'
  | 'ambicioso'
  | 'familiar';

export type CharacterMemoryType =
  | 'routine_absence'
  | 'meeting_attended'
  | 'meeting_postponed'
  | 'narrative_choice'
  | 'staff_action'
  | 'campaign_milestone'
  | 'warning'
  | 'professional_conflict'
  | 'location_event'
  | 'day_closure'
  | 'memory_followup';

export interface LivingCharacterProfile {
  id: NarrativeCharacterId;
  name: string;
  displayName: string;
  role: CharacterRole;
  age: number;
  yearsAtRanch: number;
  temperament: CharacterTemperament;
  shortBio: string;
  speaksLike: string;
  ambition: string;
  fear: string;
  defaultLocationId: LocationId;
}

export interface CharacterMemory {
  id: string;
  characterId: NarrativeCharacterId;
  type: CharacterMemoryType;
  title: string;
  text: string;
  month: Month;
  year: number;
  weight: number;
  locationId?: LocationId | null;
}


export type CharacterAvailability = 'available' | 'busy' | 'away' | 'resting';

export interface CharacterRoutineEntry {
  id: string;
  characterId: NarrativeCharacterId;
  label: string;
  availability: CharacterAvailability;
  locationId: LocationId;
  months?: Month[];
  seasons?: Season[];
  note: string;
  priority: number;
  substituteCharacterId?: NarrativeCharacterId;
}

export interface CharacterAgendaStatus {
  characterId: NarrativeCharacterId;
  availability: CharacterAvailability;
  locationId: LocationId;
  label: string;
  note: string;
  substituteCharacterId?: NarrativeCharacterId;
}
