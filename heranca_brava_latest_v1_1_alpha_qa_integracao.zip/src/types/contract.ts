import type { LocationId } from './location';

export type ContractType = 'corrida' | 'venda' | 'avenca' | 'servico' | 'visita';
export type ContractStatus = 'offered' | 'active' | 'completed' | 'rejected' | 'expired';

export interface ContractRequirement {
  minPrestige?: number;
  minTreasury?: number;
  minAnimals?: number;
}

export interface Contract {
  id: string;
  title: string;
  partner: string;
  type: ContractType;
  status: ContractStatus;
  description: string;
  locationId?: LocationId | null;
  durationMonths: number;
  monthsRemaining: number;
  upfrontIncome?: number;
  upfrontExpense?: number;
  monthlyIncome?: number;
  monthlyExpense?: number;
  completionIncome?: number;
  prestigeEffect?: number;
  riskLabel?: string;
  requirements?: ContractRequirement;
}

export interface ContractProcessResult {
  contracts: Contract[];
  income: number;
  expenses: number;
  events: string[];
}
