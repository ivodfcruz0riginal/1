export type StaffRole = 'maioral' | 'campino' | 'veterinario' | 'administracao' | 'motorista';
export type StaffStatus = 'ativo' | 'descanso' | 'doente' | 'indisponivel';

export interface StaffMember {
  id: string;
  name: string;
  role: StaffRole;
  age: number;
  seniority: number;
  monthlySalary: number;
  competence: number;
  loyalty: number;
  morale: number;
  fatigue: number;
  status: StaffStatus;
  notes: string[];
}

export interface StaffMonthlyResult {
  staff: StaffMember[];
  payroll: number;
  events: string[];
}
