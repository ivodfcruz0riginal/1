import type { LocationId } from './location';

export type DayPeriod = 'manha' | 'meio_dia' | 'tarde' | 'noite';

export type DayRecordType =
  | 'morning_council'
  | 'location_visit'
  | 'task_completed'
  | 'task_ignored'
  | 'day_closed'
  | 'period_advanced'
  | 'location_event'
  | 'world_event'
  | 'routine';

export interface DayRecord {
  id: string;
  dayOfMonth: number;
  month: string;
  year: number;
  period: DayPeriod;
  type: DayRecordType;
  title: string;
  description: string;
  locationId?: LocationId | null;
}

export const DAY_PERIOD_LABELS: Record<DayPeriod, string> = {
  manha: 'Manhã',
  meio_dia: 'Meio-dia',
  tarde: 'Tarde',
  noite: 'Noite',
};

export const DAY_PERIOD_ORDER: DayPeriod[] = ['manha', 'meio_dia', 'tarde', 'noite'];
