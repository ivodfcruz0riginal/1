import type { Month } from '../store/gameTypes';

export type RanchStatusTier =
  | 'Em Crise'
  | 'Estável'
  | 'Em Crescimento'
  | 'Referência Regional'
  | 'Referência Nacional'
  | 'Lendária';

export type AnnualObjectiveMetric =
  | 'treasury'
  | 'prestige'
  | 'animals'
  | 'activeContracts'
  | 'staffMorale';

export interface AnnualObjective {
  id: string;
  year: number;
  title: string;
  description: string;
  metric: AnnualObjectiveMetric;
  target: number;
  createdMonth: Month;
}

export interface ObjectiveResult {
  objectiveId: string;
  title: string;
  achieved: boolean;
  currentValue: number;
  target: number;
  rewardText: string;
}

export interface AnnualReport {
  id: string;
  year: number;
  generatedMonth: Month;
  treasury: number;
  treasuryDelta: number;
  annualIncome: number;
  annualExpenses: number;
  annualProfit: number;
  prestige: number;
  prestigeTier: string;
  activeAnimals: number;
  births: number;
  deaths: number;
  activeContracts: number;
  staffAverageMorale: number;
  ranchStatus: RanchStatusTier;
  notableEvents: string[];
  objectiveResults: ObjectiveResult[];
}

export interface CampaignSnapshot {
  campaignYear: number;
  monthsPlayed: number;
  targetYears: number;
  monthsRemaining: number;
  completionPercent: number;
  ranchStatus: RanchStatusTier;
  activeObjectives: ObjectiveProgress[];
}

export interface ObjectiveProgress extends AnnualObjective {
  currentValue: number;
  progress: number;
  achieved: boolean;
}
