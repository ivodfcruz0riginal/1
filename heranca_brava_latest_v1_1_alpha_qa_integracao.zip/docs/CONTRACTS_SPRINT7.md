# Herança Brava — Sprint 7: Contratos Funcionais

## Objetivo
Transformar o separador Contratos do Escritório de estado vazio para um sistema jogável com propostas, aceitação, rejeição, contratos ativos e impacto económico mensal.

## Alterações realizadas

### Novos ficheiros
- `src/types/contract.ts`
- `src/data/contracts.ts`
- `src/services/contractService.ts`

### Ficheiros alterados
- `src/store/gameTypes.ts`
- `src/store/gameState.tsx`
- `src/screens/office/ContratosTab.tsx`

## Funcionalidades
- Propostas de contrato iniciais.
- Aceitar ou recusar contratos.
- Requisitos mínimos por contrato.
- Contratos ativos com duração mensal.
- Impacto em tesouraria.
- Integração no histórico económico mensal.
- Registo automático no Diário/EventLog.
- Persistência através do Save/Load já existente.
- Hidratação de saves antigos sem perder compatibilidade.

## Critério de validação
- Build executada com sucesso via `npm run build`.

## Próximo sprint recomendado
Sprint 8 — Staff funcional: maioral, campinos e veterinário com custo mensal, competência, lealdade e impacto nos eventos.
