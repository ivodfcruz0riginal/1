# Herança Brava v0.8 — Linhagens

## Build base
`heranca_brava_latest_v0_7_world_simulation_integrada.zip`

## Objetivo
Introduzir a primeira camada funcional do Livro de Linhagens sem criar uma frente paralela de projeto.

## Ficheiros novos
- `src/types/lineage.ts`
- `src/services/lineageService.ts`
- `src/components/LineagePanel.tsx`

## Ficheiros alterados
- `src/screens/EfetivoScreen.tsx`
- `src/components/AnimalDetailPanel.tsx`

## Alterações
- Adicionado resumo das linhagens existentes no efetivo.
- Cada linha passa a mostrar influência, risco, reprodutores, vacas de base e jovens.
- O painel do animal passa a mostrar leitura genealógica direta: pai, mãe, avós conhecidos e profundidade de registo.
- A leitura genética deixa de ser apenas valor individual e passa a começar a contar a história da casa.

## Regra de autenticidade
A linhagem não é tratada como árvore de talentos nem como nível. É tratada como memória genética da ganadaria: sementais, vacas de base, renovação, risco de perda e influência na casa.
