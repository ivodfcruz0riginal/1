Baseado na Sprint19. Adicionada especificação do loop principal.
