# Herança Brava — Sprint 5: Save / Load

## Objetivo
Transformar a experiência de sessão em campanha persistente.

## Implementado

- `src/types/save.ts`
  - `CampaignSave`
  - `SaveSummary`
  - versão de save
  - chave de localStorage

- `src/services/saveService.ts`
  - `saveCampaign(state)`
  - `loadCampaign()`
  - `deleteCampaignSave()`
  - `getSaveSummary()`

- `src/store/gameState.tsx`
  - inicialização automática a partir do save local quando existir
  - action `LOAD_GAME_STATE`
  - métodos `saveGame` e `loadGame`
  - autosave quando o estado principal muda

- `src/screens/office/AdministracaoTab.tsx`
  - painel de campanha
  - guardar campanha
  - carregar campanha
  - apagar save
  - resumo do último save

## Critério validado

- Build TypeScript/Vite concluída com sucesso.
- O sistema usa `localStorage`, adequado para browser/Bolt nesta fase.

## Próxima Sprint Recomendada

Sprint 6 — Prestígio Dinâmico.
