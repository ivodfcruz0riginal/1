# Sprint 21 - Um Dia na Herdade

Objetivo:
- Conselho da Manhã
- Escolha de destino
- 2-3 decisões
- Diário
- Fim do dia

Critério: ciclo jogável de um dia.