# Herança Brava — Build de Referência

## Versão atual
`heranca_brava_latest.zip`

## Origem
Criada a partir de `heranca_brava_eventos_contextuais_sprint24.zip`.

## Decisão de produção
A partir desta versão, deixa de existir uma coleção de ZIPs independentes. O projeto passa a evoluir como uma única build completa.

## Regra operacional
1. Auditar a build atual.
2. Alterar ficheiros reais do projeto.
3. Validar com `npm run build`.
4. Atualizar documentação mínima: changelog, QA e decision log quando aplicável.
5. Gerar novo `heranca_brava_latest.zip`.

## Estado validado
- Build React/Vite validada com `npm run build`.
- Estrutura principal confirmada: `src`, `docs`, `design`, `qa`.
- Build Candidate atual para a milestone First Play.

## Próximo foco
Milestone First Play: transformar o ciclo diário num primeiro dia jogável e memorável.
