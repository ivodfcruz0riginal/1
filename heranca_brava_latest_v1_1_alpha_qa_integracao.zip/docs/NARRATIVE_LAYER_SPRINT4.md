# Herança Brava — Narrative Layer Sprint 4

## Objetivo
Criar o Diário filtrado por local/quadro no Escritório, para que a gestão narrativa passe a ficar arquivada por sítio da herdade.

## Implementado

### Diário por quadro/localização
- Novo filtro de localização no `DiarioTab`.
- Permite consultar entradas por:
  - todos os quadros;
  - sem local;
  - Escritório;
  - Currais;
  - Tentadero;
  - Parque de Embarque;
  - Cercados;
  - Barragem;
  - Armazém;
  - Oficina;
  - Casa Principal.

### Integração narrativa
- O Diário passa a combinar:
  - `eventLog` tradicional;
  - `narrativeHistory` dos diálogos com personagens.
- As escolhas narrativas ficam visíveis no Diário com etiqueta `Diálogo`.
- As entradas mostram o nome do local quando existe `locationId`.

### Persistência de localização narrativa
- `GameEvent` suporta agora `locationId` opcional.
- `NarrativeHistoryRecord` já guardava `locationId`, mas o motor narrativo não o preenchia corretamente.
- `applyNarrativeChoice` passa a registar `locationId` em:
  - eventos gerados por narrativa;
  - histórico narrativo.

## Ficheiros alterados
- `src/screens/office/DiarioTab.tsx`
- `src/store/gameTypes.ts`
- `src/services/narrativeEngine.ts`

## Validação
- Build validada com sucesso via `npm run build`.

## Próximo passo recomendado
Sprint 5 — Save/Load local com persistência da campanha no browser.
