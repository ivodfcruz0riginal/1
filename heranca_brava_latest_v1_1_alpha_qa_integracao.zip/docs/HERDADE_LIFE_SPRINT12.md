# Herdade Life Sprint 12 — Personagens e Memória

## Build base
`heranca_brava_herdade_life_sprint11.zip`

## Objetivo
Transformar as personagens do Conselho da Manhã em habitantes com perfil, relação e memória persistente.

## Alterações

### Novos ficheiros
- `src/types/character.ts`
- `src/data/characters.ts`
- `src/services/characterService.ts`

### Ficheiros alterados
- `src/types/narrative.ts`
- `src/data/narrativeEvents.ts`
- `src/store/gameTypes.ts`
- `src/store/gameState.tsx`
- `src/services/morningCouncilService.ts`
- `src/screens/office/PessoalTab.tsx`

## Funcionalidades
- Perfis vivos para António, Dr. Duarte, D. Beatriz, Joaquim, Família e Empresário.
- Memórias persistentes por personagem.
- Atender ou adiar assuntos cria memórias.
- Escolhas narrativas criam memórias relevantes.
- Relações ganham afinidade e tensão, além de confiança, respeito, lealdade e cansaço.
- Conselho da Manhã passa a reagir ao tom da relação e a memórias recentes.
- Separador Pessoal passa a mostrar Personagens Principais e memórias recentes.

## Critério de validação
- A build compila.
- Memórias e relações entram no GameState e são guardadas via Save/Load existente.
- Nenhum sistema existente foi duplicado.

## Build
Validada com `npm run build`.
