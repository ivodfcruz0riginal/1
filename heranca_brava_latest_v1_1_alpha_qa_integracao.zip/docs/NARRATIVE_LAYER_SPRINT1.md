# Herança Brava — Narrative Interaction Layer Sprint 1

## Objetivo
Ligar os diálogos do maioral a consequências reais no estado do jogo.

## Ficheiros criados
- `src/types/narrative.ts`
- `src/data/narrativeEvents.ts`
- `src/services/narrativeEngine.ts`

## Ficheiros alterados
- `src/store/gameTypes.ts`
- `src/store/gameState.tsx`

## O que ficou funcional
- Relações narrativas por personagem.
- Histórico narrativo de escolhas.
- Efeitos de diálogo sobre tesouraria.
- Efeitos de diálogo sobre confiança/respeito.
- Efeitos simples sobre saúde animal.
- Efeitos sobre prestígio.
- Registo automático no Diário da Herdade.

## Regra de produção aplicada
Nenhum diálogo deve ser apenas decorativo. Quando existir mapeamento narrativo, a escolha altera estado real do jogo.

## Próximo passo recomendado
Expandir `NARRATIVE_EVENTS` para 10 eventos do Maioral e mostrar feedback visual do resultado após cada escolha.
