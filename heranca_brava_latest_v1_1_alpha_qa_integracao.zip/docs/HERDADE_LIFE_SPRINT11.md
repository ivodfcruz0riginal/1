# Herança Brava — Sprint 11
## Herdade Life System: Conselho da Manhã

Build base: `heranca_brava_campanha_5_anos_sprint9.zip`

## Regra aplicada
Antes de acrescentar funcionalidade, foi revista a build existente. A Sprint 11 não cria novos motores paralelos: liga os sistemas existentes através de uma camada de coordenação.

## Objetivo
Transformar o Escritório num ponto vivo de gestão: ao entrar no Escritório, o jogador vê até três pessoas/assuntos prioritários da herdade antes de consultar separadores.

## Novo
- `src/types/meeting.ts`
- `src/services/morningCouncilService.ts`
- Painel `Conselho da Manhã` dentro do Escritório

## Alterado
- `src/store/gameTypes.ts`
- `src/store/gameState.tsx`
- `src/screens/EscritorioScreen.tsx`
- `src/App.tsx`

## Integrações
O Conselho da Manhã lê dados já existentes:
- economia;
- contratos;
- staff;
- prestígio;
- objetivos de campanha;
- narrativa existente.

## Comportamento
- Gera até 3 assuntos por mês.
- Dá prioridade a tesouraria crítica, contratos pendentes, staff cansado, prestígio baixo e objetivos anuais.
- Permite atender ou adiar.
- Atender pode abrir a tab recomendada e acionar um diálogo existente.
- Regista o assunto no Diário.
- Persistência incluída via Save/Load porque `morningCouncil` passa a fazer parte do `GameState`.

## Validação
- `npm install`
- `npm run build`
- Build validada com sucesso.

## Próximo passo recomendado
Sprint 12 — Memória de Personagens: transformar escolhas repetidas em memórias persistentes que alteram diálogos futuros.
