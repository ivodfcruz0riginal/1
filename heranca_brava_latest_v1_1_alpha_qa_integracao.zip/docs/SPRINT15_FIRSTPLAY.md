# Sprint 15 - First Play

Goal:
- Focus development on the Maioral vertical slice.
- Integrate Morning Council as primary entry point.
- Freeze new systems.
- Next coding tasks:
  1. Enhance characterService with persistent memories.
  2. Wire morningCouncilService into EscritorioScreen.
  3. Replace menu-first flow by conversation-first flow.
Acceptance:
Player starts day by meeting up to 3 characters before opening office tabs.
