# Sprint 16 — Vertical Slice do Maioral António

## Objetivo
Transformar o António de uma personagem descrita para uma personagem funcional, capaz de ler o estado da herdade e aparecer no Conselho da Manhã com voz própria.

## Alterações reais de código
- Novo `src/services/antonioService.ts`.
- Integração do António no `morningCouncilService`.
- Integração do estado emocional do António no separador `Pessoal`.

## Comportamento implementado
O António passa a avaliar:
- tesouraria;
- cansaço da equipa;
- prestígio;
- contratos pendentes;
- tensão/memórias recentes.

Com base nisso, o Conselho da Manhã altera:
- título do assunto;
- frase de personagem;
- urgência;
- separador recomendado.

## Regra de produção validada
Esta sprint não criou menus nem sistemas paralelos. Usou a build existente e adicionou profundidade a uma personagem central.
