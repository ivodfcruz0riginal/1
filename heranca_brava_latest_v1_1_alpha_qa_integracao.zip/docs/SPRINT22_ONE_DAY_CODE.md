# Sprint 22 — Ciclo Jogável de Um Dia

## Build base
heranca_brava_um_dia_sprint21.zip

## Objetivo
Transformar o conceito de "Um Dia na Herdade" em código real, ligando Conselho da Manhã, tarefas, visitas a quadros, Diário e avanço diário.

## Implementado
- Estado de dia dentro da campanha: `dayOfMonth` e `dayPeriod`.
- Períodos do dia: Manhã, Meio-dia, Tarde e Noite.
- Serviço `dayCycleService.ts` para avanço de período, fecho do dia e resumo diário.
- Registo diário persistente (`dayLog`).
- Conselho da Manhã passa a regenerar por dia, não apenas por mês.
- Tarefas concluídas/ignoradas entram no registo do dia.
- Visitas a quadros/localizações entram no registo do dia.
- Fecho do dia gera resumo automático no Diário.
- Ao fim do dia 28, o sistema fecha o mês usando a lógica mensal já existente.
- Header mostra Dia e Período.
- Botões para Avançar Período e Fechar Dia.
- Diário ganhou filtro "Dia" e etiquetas Dia/Período.

## Regra de design aplicada
O jogador deixa de avançar apenas por mês. Agora vive dias dentro da herdade, com prioridades, deslocações e consequências registadas.
