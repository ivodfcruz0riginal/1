# World Simulation v0.7

Goal:
- Characters follow daily routines.
- World events continue while player is elsewhere.
- Diary records autonomous events.

Planned integration:
- routineService.ts
- worldSimulationService.ts
- dayCycleService integration
