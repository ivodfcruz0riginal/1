# Changelog Sprint 19

## Novos ficheiros
- `src/services/beatrizService.ts`
- `src/services/financialConflictService.ts`
- `docs/SPRINT19_BEATRIZ_VERTICAL_SLICE.md`
- `docs/CHANGELOG_SPRINT19.md`

## Ficheiros alterados
- `src/services/morningCouncilService.ts`
- `src/screens/office/PessoalTab.tsx`

## QA
- Build TypeScript/Vite validada com sucesso.
- Mantida compatibilidade com Conselho da Manhã e sistema de conflitos profissionais.
