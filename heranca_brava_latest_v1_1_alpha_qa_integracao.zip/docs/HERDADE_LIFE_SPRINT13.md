# Herança Brava — Herdade Life Sprint 13

## Objetivo
Dar rotina própria às Personagens Principais, para que o Conselho da Manhã deixe de ser apenas uma lista fixa de assuntos e passe a refletir a vida real da herdade.

## Build base
`heranca_brava_personagens_memoria_sprint12.zip`

## Alterações principais

### 1. Agenda das personagens
Criados tipos e rotinas para as personagens principais:
- disponibilidade;
- local atual;
- rotina mensal/sazonal;
- substituição temporária.

### 2. Conselho da Manhã com agenda
O Conselho da Manhã passa a consultar a agenda antes de apresentar assuntos:
- António pode estar nos currais ou nos cercados;
- Joaquim pode substituir o maioral;
- Dr. Duarte aparece mais em meses de ronda sanitária;
- D. Beatriz ganha peso nos fechos trimestrais;
- Empresário aparece mais na temporada taurina;
- Família aparece em momentos domésticos específicos.

### 3. Pessoal com agenda atual
O separador Pessoal mostra a agenda atual de cada Personagem Principal.

### 4. Regras mantidas
- Sem novos sistemas duplicados.
- Sem novos ecrãs principais.
- Tudo assenta sobre `characterService` e `morningCouncilService` existentes.
- Compatível com Save/Load porque a agenda é derivada do estado atual da campanha.

## Ficheiros alterados
- `src/types/character.ts`
- `src/types/meeting.ts`
- `src/data/characters.ts`
- `src/services/characterService.ts`
- `src/services/morningCouncilService.ts`
- `src/screens/EscritorioScreen.tsx`
- `src/screens/office/PessoalTab.tsx`

## Validação
Build validada com sucesso via `npm run build`.
