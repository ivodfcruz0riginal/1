# Changelog — Sprint 24

## Novos ficheiros
- `src/types/locationEvent.ts`
- `src/data/locationEvents.ts`
- `src/services/locationEventService.ts`
- `docs/SPRINT24_EVENTOS_CONTEXTUAIS_QUADRO.md`
- `docs/CHANGELOG_SPRINT24.md`
- `docs/QA_SPRINT24.md`

## Ficheiros alterados
- `src/store/gameTypes.ts`
- `src/store/gameState.tsx`
- `src/types/day.ts`
- `src/components/LocationDetailPanel.tsx`

## Funcionalidades
- Eventos contextuais aparecem ao abrir quadros/localizações.
- Cada evento tem personagem, severidade e escolhas.
- Escolhas aplicam efeitos em tesouraria, prestígio, relações, memórias, notificações e condição do local.
- Eventos resolvidos ficam registados no Diário do dia e no Diário geral.

## Critério de aprovação
O jogador deve sentir que ir aos currais, cercados, oficina, barragem ou embarque pode gerar uma situação própria, ligada ao estado da herdade.
