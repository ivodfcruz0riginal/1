# Sprint 24 — Eventos Contextuais por Quadro

## Objetivo
Transformar cada local da herdade num quadro com decisões próprias, em vez de ser apenas um ponto de navegação.

## Build base
`heranca_brava_qa_7dias_sprint23.zip`

## Implementação
- Criado `src/types/locationEvent.ts`.
- Criado `src/data/locationEvents.ts` com eventos por localização.
- Criado `src/services/locationEventService.ts`.
- Integrado `activeLocationEvent` no `GameState`.
- Integrado evento contextual ao abrir um local no mapa.
- Adicionada resolução de evento contextual com efeitos reais.
- Atualizado `LocationDetailPanel.tsx` para mostrar situação, personagem, severidade e escolhas.

## Locais com eventos nesta sprint
- Currais
- Cercado Norte
- Cercado Sul
- Tentadero
- Embarque
- Armazém
- Barragem
- Oficina
- Casa Principal

## Regras de autenticidade
- Toiros não são treinados.
- Situações de campo devem surgir como observação, maneio, sanidade, instalações, água, alimentação ou logística.
- Nenhuma decisão importante é apenas um botão; deve vir ligada a uma personagem.

## Validação
- `npm run build` executado com sucesso.
