# Sprint 17 — Dr. Duarte Vertical Slice

## Objetivo
Criar o segundo personagem vertical do Herança Brava: Dr. Duarte, veterinário.

Depois do António representar a tradição e a leitura de campo, Duarte passa a representar a ciência, prevenção sanitária e custo técnico das decisões.

## Implementado
- Novo `duarteService.ts`.
- Snapshot clínico do Dr. Duarte com humor, parecer, urgência e diagnóstico.
- O Conselho da Manhã passa a chamar Duarte quando existe risco sanitário, tesouraria clínica frágil ou visita sanitária relevante.
- A voz de Duarte é aplicada aos encontros do Conselho.
- O separador Pessoal mostra o parecer clínico atual do veterinário.

## Integrações
- Reutiliza `characterService`, `morningCouncilService`, `GameState`, relações e memórias existentes.
- Não cria novo motor paralelo.
- Mantém compatibilidade com Save/Load porque não altera o shape do estado salvo.

## Direção de Design
António e Duarte podem discordar. O jogador deixa de escolher apenas uma ação e começa a escolher que leitura profissional quer seguir: tradição ou ciência.
