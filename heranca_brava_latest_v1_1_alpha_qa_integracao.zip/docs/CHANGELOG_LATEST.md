# Changelog — Build Latest

## Alterações desta consolidação
- Criada build única de referência: `heranca_brava_latest.zip`.
- Adicionado `docs/BUILD_REFERENCE.md`.
- Adicionado `docs/CHANGELOG_LATEST.md`.
- Mantida a base da Sprint 24 como estado funcional atual.
- Build validada com `npm run build`.

## Sem alterações de gameplay nesta consolidação
Esta versão não adiciona novas mecânicas. O objetivo é consolidar a build oficial para continuar o desenvolvimento sem criar projetos paralelos.
