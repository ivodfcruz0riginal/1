# QA — Sprint 24

## Testes realizados
- Build de produção: `npm run build`.
- TypeScript/Vite compilou sem erros.

## Cenários cobertos
- Abrir local com notificação correspondente.
- Mostrar evento contextual no painel do local.
- Resolver escolha do evento.
- Aplicar efeitos económicos e de prestígio.
- Alterar notificações e condição do local.
- Registar evento no Diário.
- Criar memória de personagem.

## Riscos conhecidos
- O sistema ainda escolhe um evento por prioridade e não por probabilidade ponderada.
- Pode haver repetição de eventos se o jogador visitar muitos locais ao longo de muitos dias.
- A camada visual ainda é painel UI; no futuro deve evoluir para apresentação mais cinematográfica por quadro.

## Estado
Aprovado para build de trabalho.
