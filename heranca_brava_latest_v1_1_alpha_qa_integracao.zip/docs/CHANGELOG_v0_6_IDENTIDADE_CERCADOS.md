# Herança Brava v0.6 — Identidade dos Cercados e Quadros

## Objetivo
Dar identidade própria aos locais da herdade, sobretudo aos cercados, para reforçar o princípio de que o jogador deve aprender a observar a ganadaria e reconhecer a herdade como uma casa, não como uma lista de menus.

## Alterações de código

### `src/types/location.ts`
- Adicionado `LocationIdentity`.
- Cada localização pode agora guardar:
  - terreno;
  - água;
  - sombra;
  - função principal;
  - lote residente;
  - história do local;
  - focos de observação.

### `src/data/locations.ts`
- Adicionada identidade a:
  - Cercado Norte;
  - Cercado Sul;
  - Currais;
  - Parque de Embarque;
  - Barragem.
- Corrigida linguagem de autenticidade: os machos vivem soltos por camada/lote e são observados, não treinados.

### `src/services/locationService.ts`
- Adicionados helpers:
  - `hasLocationIdentity`;
  - `getLocationIdentitySummary`;
  - `getObservationPrompt`.

### `src/components/LocationDetailPanel.tsx`
- Painel de localização mostra agora:
  - identidade do quadro;
  - terreno;
  - água e sombra;
  - história;
  - guia de observação.

## Resultado de gameplay
Ao clicar num local, o jogador deixa de ver apenas estado/capacidade/notificações. Passa a perceber que cada lugar tem função, memória e sinais próprios a observar.

## Build
- Validada com `npm run build`.
