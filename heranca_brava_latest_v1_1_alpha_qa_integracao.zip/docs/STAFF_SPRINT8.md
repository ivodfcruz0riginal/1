# Herança Brava — Staff Funcional Sprint 8

## Objetivo
Transformar o pessoal da ganadaria num sistema funcional ligado à economia, prestígio, diário e save/load.

## Entregue
- Novo modelo `StaffMember`.
- Dados iniciais da equipa: maioral, campinos, veterinária e administração.
- `staffService` com folha salarial, evolução mensal, cansaço, moral, formação, descanso e bónus.
- Estado global atualizado com `staff`.
- Processamento mensal da equipa integrado no avanço do mês.
- Custos salariais explícitos aplicados à economia mensal.
- Eventos de cansaço/moral registados no Diário.
- Prestígio dinâmico passa a considerar a força da equipa.
- Novo separador `Pessoal` no Escritório.
- Ações de gestão: dar descanso, atribuir bónus e formação.
- Compatível com Save/Load existente.

## Critério de aceitação
- A build compila com sucesso.
- A equipa aparece no Escritório.
- A folha salarial impacta a economia ao avançar mês.
- Decisões sobre pessoal alteram moral, lealdade, competência e cansaço.
- As decisões ficam registadas no diário/event log.

## Próximo Sprint recomendado
Campanha completa de 5 anos: testar loop persistente com Save/Load, economia, contratos, prestígio, narrativa e staff.
