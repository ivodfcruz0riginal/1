# Changelog Sprint 22

## Novos ficheiros
- `src/types/day.ts`
- `src/services/dayCycleService.ts`
- `docs/SPRINT22_ONE_DAY_CODE.md`
- `docs/CHANGELOG_SPRINT22.md`
- `qa/QA_SPRINT22.md`

## Ficheiros alterados
- `src/store/gameTypes.ts`
- `src/store/gameState.tsx`
- `src/components/Header.tsx`
- `src/components/TasksPanel.tsx`
- `src/services/morningCouncilService.ts`
- `src/screens/office/DiarioTab.tsx`

## Alterações principais
- Adicionado ciclo de dia e período.
- Adicionado fecho de dia com resumo automático.
- Conselho da Manhã passa a ser diário.
- Ações de tarefas e visitas passam a gerar registo diário.
- UI mostra Dia/Período e permite fechar dia.

## Validação
- `npm run build` executado com sucesso.
