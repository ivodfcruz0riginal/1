# Herança Brava v1.0 Alpha — Integração Total

## Objetivo
Ligar os sistemas já existentes num único fluxo jogável:
Conselho da Manhã → Quadro → Decisão → Diário → Crónicas → Amanhã.

## Ficheiros novos
- `src/services/alphaIntegrationService.ts`

## Ficheiros alterados
- `src/store/gameState.tsx`
- `src/screens/EscritorioScreen.tsx`

## Alterações
- Novo painel **Fio do Dia** no Escritório.
- Próximo passo sugerido com base no estado real da herdade.
- Assuntos vivos agregados a partir de Conselho, eventos de quadro, memórias e mundo vivo.
- Fecho do dia passa a escrever uma crónica integrada e não apenas um resumo técnico.
- O Diário/Crónicas passa a reforçar o que fica pendente para amanhã.

## Critério de aceitação
O jogador deve perceber:
1. Quem está à espera no Conselho.
2. Que local deve visitar.
3. Que decisões ficaram por resolver.
4. Que fio narrativo continua no dia seguinte.
