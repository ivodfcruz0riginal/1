# Herança Brava v0.5 — Memória das Personagens

## Objetivo
Reforçar a continuidade narrativa entre Conselho da Manhã, visitas aos quadros, decisões e Diário.

## Alterações de código

### Novo ficheiro
- `src/services/characterMemoryService.ts`
  - Seleciona memórias relevantes por personagem.
  - Gera linhas de memória para o Conselho da Manhã.
  - Identifica memórias pendentes que podem regressar em dias seguintes.
  - Gera linha de continuidade para a Crónica do Dia.

### Ficheiros alterados
- `src/types/character.ts`
  - Acrescentados tipos de memória: `location_event`, `day_closure`, `memory_followup`.

- `src/services/morningCouncilService.ts`
  - Conselho da Manhã passa a usar memórias relevantes por personagem.
  - Assuntos antigos importantes podem regressar como follow-up.
  - Reuniões podem apontar para o quadro/local coerente quando existe diálogo contextual.

- `src/store/gameState.tsx`
  - Atender uma reunião que aponta para um local pode criar evento contextual desse quadro.
  - Fecho do dia passa a incluir linha de continuidade narrativa no Diário.

## Resultado esperado
O jogador deve sentir que as personagens lembram decisões anteriores e que os assuntos não desaparecem entre um dia e o seguinte.
