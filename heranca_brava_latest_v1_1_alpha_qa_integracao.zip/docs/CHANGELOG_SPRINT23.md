# Changelog — Sprint 23

## Alterado
- `src/screens/EscritorioScreen.tsx`
  - Adicionado painel **Dia na Herdade**.
  - Adicionados botões para avançar período e fechar dia a partir do Escritório.
  - Adicionado resumo de pressão do dia, pendências, tarefas e deslocações.

- `src/store/gameState.tsx`
  - Fecho do dia agora transforma tarefas pendentes em ignoradas.
  - Fecho do dia agora transforma assuntos pendentes em adiados.
  - Assuntos não atendidos geram memórias e impacto em relações.
  - Diário passa a registar pendências do dia.

## Validado
- `npm run build` executado com sucesso.
- Ciclo diário preparado para teste de 7 dias.

## Build
`heranca_brava_qa_7dias_sprint23.zip`
