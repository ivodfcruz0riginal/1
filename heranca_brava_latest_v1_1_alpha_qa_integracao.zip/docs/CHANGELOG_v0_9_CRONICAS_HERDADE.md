# Herança Brava v0.9 — Crónicas da Herdade

## Objetivo
Transformar o antigo Livro da Casa num arquivo vivo da campanha, ligando Diário, memórias das personagens, linhagens, relatórios anuais e acontecimentos da herdade.

## Ficheiros novos
- `src/services/chronicleService.ts`

## Ficheiros alterados
- `src/screens/office/LivroTab.tsx`

## Alterações principais
- O Livro da Casa passa a chamar-se visualmente **Crónicas da Herdade**.
- Criado sistema de entradas de crónica com tipo, tom, peso e local associado.
- As crónicas são geradas a partir de:
  - registos do dia;
  - memórias das personagens;
  - eventos da herdade;
  - relatórios anuais;
  - leitura de linhagens.
- Adicionadas secções:
  - Assuntos vivos;
  - Marcos recentes da casa;
  - Livro genealógico vivo;
  - Arquivo da campanha;
  - Memória antiga da casa.
- O jogador passa a conseguir ver que assuntos continuam em aberto e que acontecimentos já estão a formar a memória da herdade.

## Princípio de design reforçado
O Diário regista o dia. As Crónicas preservam o legado.
