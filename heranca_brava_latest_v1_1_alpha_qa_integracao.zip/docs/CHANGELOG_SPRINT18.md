# Changelog — Sprint 18

## Novos ficheiros
- `src/services/professionalConflictService.ts`
- `docs/SPRINT18_CONFLITO_TECNICO.md`
- `docs/CHANGELOG_SPRINT18.md`
- `qa/QA_SPRINT18.md`

## Ficheiros alterados
- `src/types/meeting.ts`
- `src/types/character.ts`
- `src/services/morningCouncilService.ts`
- `src/store/gameTypes.ts`
- `src/store/gameState.tsx`
- `src/screens/EscritorioScreen.tsx`

## Alterações principais
- Adicionado suporte a conflitos profissionais no Conselho da Manhã.
- Criado conflito António vs Dr. Duarte para decisões de sanidade/maneio.
- Adicionadas escolhas específicas: confiar no António ou seguir o Dr. Duarte.
- Consequências reais em relações, memórias, diário, tesouraria/prestígio.
- Corrigida duplicação acidental de dispatch em `postponeMorningMeeting`.

## Build
- `npm run build` executado com sucesso.
