# Herança Brava v1.1 Alpha — QA & Integração

## Alterações

- Adicionado `src/services/alphaQaService.ts`.
- Adicionado painel **Alpha QA · Integração** no Escritório.
- O painel avalia a cadeia principal do First Play:
  - Conselho da Manhã;
  - ligação Conselho → Quadro;
  - Diário do Dia;
  - memória das personagens;
  - vida autónoma da herdade;
  - ligação Diário → Crónicas.
- A avaliação produz estado `aprovado`, `afinar` ou `bloqueante` com ações sugeridas.

## Objetivo

A v1.1 não acrescenta sistemas de gameplay. Acrescenta uma camada de QA visível para ajudar a perceber, durante o teste, onde o First Play está a falhar.
