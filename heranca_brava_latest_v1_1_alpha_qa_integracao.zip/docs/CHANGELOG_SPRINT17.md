# Changelog — Sprint 17

## Novos ficheiros
- `src/services/duarteService.ts`
- `docs/SPRINT17_DUARTE_VERTICAL_SLICE.md`
- `docs/CHANGELOG_SPRINT17.md`

## Alterados
- `src/services/morningCouncilService.ts`
- `src/screens/office/PessoalTab.tsx`

## QA
- Build TypeScript/Vite validada.
- Sem alterações ao modelo persistido de Save/Load.
