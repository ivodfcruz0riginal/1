# Herança Brava v0.7 — World Simulation

## Objetivo
Dar vida à herdade entre períodos do dia, para que o mundo continue a acontecer mesmo quando o jogador não intervém diretamente.

## Ficheiros alterados
- `src/services/routineService.ts`
- `src/services/worldSimulationService.ts`
- `src/store/gameState.tsx`
- `src/types/day.ts`

## Alterações principais
- Rotinas diárias por personagem principal: António, Dr. Duarte, D. Beatriz, Joaquim, Família e Empresário.
- Simulação de acontecimentos autónomos ao avançar período do dia.
- Eventos de baixa intensidade ligados a cercados, barragem, currais e oficina.
- Registo automático no Diário através de novos tipos `routine` e `world_event`.
- Memórias de personagem criadas quando António, Joaquim ou outros intervêm autonomamente.
- Notificações de local atualizadas por acontecimentos da herdade.

## Regra de autenticidade aplicada
Os toiros não são treinados. A simulação trabalha com observação de lotes, comportamento, cercas, água, rotinas de maneio e pequenos acontecimentos naturais da herdade.
