# Sprint 18 — Conflito Técnico António / Dr. Duarte

## Objetivo
Criar o primeiro conflito real entre personagens principais, usando a arquitetura já existente do Herdade Life System.

## Decisão de Produção
Não foram criados novos motores gerais. A sprint reutiliza:
- `antonioService.ts`
- `duarteService.ts`
- `characterService.ts`
- `morningCouncilService.ts`
- `gameState.tsx`

## Funcionalidade
Quando existe risco sanitário e pressão de tesouraria/equipa/relação, o Conselho da Manhã pode apresentar um conflito técnico entre:
- António — maneio, tradição, prudência operacional e custos.
- Dr. Duarte — prevenção sanitária, ciência e intervenção clínica.

O jogador escolhe em quem confia.

## Consequências
A escolha altera:
- relações com António e Dr. Duarte;
- tensão entre pareceres técnicos;
- tesouraria/prestígio conforme o lado escolhido;
- memórias persistentes de ambos;
- diário da herdade.

## Critério de Aceitação
O jogador deve deixar de receber apenas um conselho isolado. Em situações críticas, deve sentir que está a arbitrar dois pareceres legítimos e incompatíveis.
