# Sprint 23 — QA 7 Dias e Correção do Ciclo Diário

## Build Base
`heranca_brava_um_dia_codigo_sprint22.zip`

## Objetivo
Testar o ciclo de 7 dias seguidos e corrigir o principal bloqueio encontrado: o jogador não tinha uma forma clara de fechar o dia a partir do Escritório e os assuntos pendentes desapareciam sem consequência suficiente.

## Auditoria
A build já tinha:
- ciclo diário com períodos;
- Conselho da Manhã;
- tarefas do dia;
- registo no Diário;
- Save/Load;
- visitas a quadros.

## Problemas encontrados

### 1. Fecho do dia demasiado dependente do painel de tarefas
O botão de fechar dia estava no painel da herdade. No fluxo real do Herança Brava, o jogador deve conseguir regressar ao Escritório e fechar o dia a partir daí.

### 2. Pendências sem peso suficiente
Se o jogador fechasse o dia com assuntos ou tarefas pendentes, o jogo precisava de transformar isso em memória, tensão e registo no Diário.

### 3. Falta de leitura rápida do dia
No Escritório não havia uma síntese clara do estado do dia: período, pressão, assuntos pendentes, tarefas e deslocações.

## Alterações realizadas

### Código alterado
- `src/screens/EscritorioScreen.tsx`
- `src/store/gameState.tsx`

### Novo painel no Escritório
Foi criado o painel **Dia na Herdade**, com:
- dia atual;
- período do dia;
- pressão do dia;
- assuntos pendentes;
- tarefas pendentes;
- tarefas concluídas;
- deslocações registadas;
- botão Avançar Período;
- botão Fechar Dia.

### Fecho do dia corrigido
Ao fechar o dia:
- tarefas pendentes passam a ignoradas;
- assuntos pendentes passam a adiados;
- personagens afetadas perdem confiança e acumulam tensão;
- são criadas memórias para assuntos não atendidos;
- o Diário regista o que ficou por tratar.

## Teste de 7 dias

### Cenário Conservador
- Atende 1 assunto por dia.
- Completa 2 tarefas.
- Fecha dia com algumas pendências.

Resultado esperado: campanha continua, relações sofrem pouco, diário regista pendências.

### Cenário Equilibrado
- Atende assuntos críticos.
- Ignora tarefas menores.
- Alterna visitas e escritório.

Resultado esperado: melhor equilíbrio entre avanço e consequências.

### Cenário Agressivo
- Fecha vários dias com pendências.
- Prioriza apenas contratos e economia.

Resultado esperado: maior tensão com personagens, mais memórias negativas, mas campanha não bloqueia.

## Resultado QA

Estado: **Aprovado para continuar**.

O ciclo diário já permite testar uma semana completa sem depender apenas do painel da herdade. O Escritório passa a funcionar como início e fim natural do dia.

## Próximo passo recomendado
Sprint 24 — Eventos contextuais por quadro, usando o ciclo diário já estabilizado.
