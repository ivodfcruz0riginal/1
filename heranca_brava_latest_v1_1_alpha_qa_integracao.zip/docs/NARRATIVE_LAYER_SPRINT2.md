# Narrative Interaction Layer — Sprint 2

## Objetivo
Expandir a camada narrativa para 10+ eventos do Maioral e mostrar ao jogador a consequência imediata da decisão.

## Implementado

### 1. Eventos narrativos adicionais
Foram adicionados eventos com efeitos reais para:

- calor de Verão e gestão de água/sombra;
- frio de Inverno e vigilância dos animais jovens;
- nascimento de vitelos;
- novilho promissor para tienta;
- toiro com pouco apetite;
- manutenção do tentadero;
- convite para corrida em Vila Franca;
- reparação de vedação;
- animal agressivo;
- saudação inicial da campanha.

### 2. Resultado da escolha
Após escolher uma resposta no diálogo do Maioral, surge uma carta de consequência com:

- texto narrativo do resultado;
- efeitos principais aplicados;
- registo automático no Diário.

### 3. Estado global
Foi adicionado `lastNarrativeResult` ao estado do jogo.

### 4. Ações novas
Foi adicionada a ação `DISMISS_NARRATIVE_RESULT` para fechar a carta de consequência.

## Validação
Build executada com sucesso com `npm run build`.

## Próximo passo recomendado
Sprint 3: ligar eventos narrativos às localizações/quadros existentes, para que o mesmo sistema dispare eventos diferentes no Escritório, Currais, Pastagens e Economia.
