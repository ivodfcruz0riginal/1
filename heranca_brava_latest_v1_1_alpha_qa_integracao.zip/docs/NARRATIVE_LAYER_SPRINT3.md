# Herança Brava — Narrative Layer Sprint 3

## Objetivo
Ligar os eventos narrativos aos quadros/localizações existentes da herdade.

## Implementado

### 1. Diálogos por localização
Cada diálogo pode agora declarar `locationIds`, permitindo que o jogo apresente conversas adequadas ao sítio onde o jogador está.

Exemplos:
- Escritório: agenda, contas e cartas.
- Currais: apartação e observação de lote.
- Tentadero: preparação de prova.
- Embarque: revisão de manga/camião.
- Cercados: vedação, observação de novilhos e água.
- Armazém, Oficina, Barragem e Casa: decisões próprias.

### 2. Motor de seleção contextual
Foi criada lógica para escolher diálogo adequado ao local ativo:

- `pickDialogueForLocation(locationId, excludedDialogueIds)`
- evita repetir diálogos recentes;
- privilegia diálogos com maior prioridade.

### 3. Integração no Game State
Ao abrir um local no mapa, se não houver diálogo pendente, o jogo procura automaticamente uma situação narrativa daquele local.

### 4. Histórico contextual
As decisões narrativas passam a guardar também o `locationId`, permitindo no futuro filtrar o Diário por local.

### 5. Novos eventos do Maioral
Foram adicionados eventos contextuais para:
- Escritório
- Currais
- Tentadero
- Embarque
- Cercado Norte
- Cercado Sul
- Barragem
- Armazém
- Oficina
- Casa Principal

## Ficheiros alterados

- `src/data/maioralDialogues.ts`
- `src/data/narrativeEvents.ts`
- `src/types/narrative.ts`
- `src/store/gameTypes.ts`
- `src/store/gameState.tsx`
- `src/services/narrativeEngine.ts`

## Resultado
A gestão narrativa deixa de ser apenas mensal e passa a nascer dos quadros. O jogador entra num local e recebe uma situação própria desse espaço, mantendo a lógica:

Quadro → Personagem → Diálogo → Escolha → Consequência real.

## Build
Validada com sucesso com `npm run build`.
