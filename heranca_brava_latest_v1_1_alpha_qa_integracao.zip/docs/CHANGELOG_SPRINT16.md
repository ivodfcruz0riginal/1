# Changelog — Sprint 16

## Novos ficheiros
- `src/services/antonioService.ts`
- `docs/SPRINT16_ANTONIO_VERTICAL_SLICE.md`
- `docs/CHANGELOG_SPRINT16.md`
- `qa/QA_SPRINT16.md`
- `design/DECISION_LOG_SPRINT16.md`

## Ficheiros alterados
- `src/services/morningCouncilService.ts`
- `src/screens/office/PessoalTab.tsx`

## Resultado
O Maioral António passa a reagir ao estado da campanha com voz própria, reforçando a regra: as pessoas são a interface do Herança Brava.
