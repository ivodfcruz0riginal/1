# Herança Brava — Sprint 6: Prestígio Dinâmico

## Objetivo
Substituir o prestígio fixo/hardcoded por um cálculo dinâmico baseado no estado real da campanha.

## Alterações

### Novo serviço
- `src/services/prestigeService.ts`

Calcula:
- pontuação total de prestígio;
- escalão da ganadaria;
- tendência recente;
- fatores de contribuição;
- diagnóstico textual.

### Integração com o estado
- `gameState.tsx` recalcula o prestígio ao avançar o mês, responder diálogos narrativos, resolver decisões e carregar campanha.

### UI
- `PrestigioTab.tsx` deixou de usar valor fixo.
- Mostra agora:
  - pontuação real;
  - escalão;
  - tendência;
  - fatores de prestígio;
  - conquistas por limiar;
  - leitura/diagnóstico da casa.

## Fatores utilizados
- Qualidade do efetivo.
- Saúde e apresentação dos animais.
- Solidez económica.
- Relações com personagens.
- Reputação pública e narrativa.

## Critério de aceitação
O prestígio deve mudar conforme evoluem animais, economia, eventos e decisões narrativas.
