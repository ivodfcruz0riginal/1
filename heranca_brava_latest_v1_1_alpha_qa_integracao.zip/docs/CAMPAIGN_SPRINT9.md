# Herança Brava — Sprint 9
## Campanha Completa de 5 Anos

### Objetivo
Validar que a build já permite uma campanha persistente e acompanhável ao longo de 5 anos, ligando economia, staff, contratos, prestígio, diário, narrativa e save/load.

### Implementado
- Novo modelo de campanha: objetivos anuais, relatórios anuais e estado da ganadaria.
- Novo serviço `campaignService`.
- Novo tipo `campaign.ts`.
- Integração no `GameState`.
- Geração automática de relatório anual ao virar de Dezembro para Janeiro.
- Geração automática de objetivos anuais.
- Nova tab `Campanha` no Escritório.
- Botão de avanço mensal dentro da tab de campanha para facilitar testes longos.
- Persistência compatível com Save/Load.

### Regras de produção respeitadas
- Build baseada no Sprint 8.
- Sistemas existentes revistos antes de acrescentar código.
- Sem duplicação de staff, contratos, prestígio ou save/load.
- Alteração mínima focada na campanha de 5 anos.

### Critério de aceitação
O jogador consegue avançar meses/anos, receber relatórios anuais, acompanhar objetivos, ver o estado da ganadaria e manter tudo persistente via Save/Load.
