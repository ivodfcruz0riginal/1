# Decision Log — Sprint 16

## Decisão
Desenvolver verticalmente uma personagem antes de expandir o elenco.

## Motivo
O Herança Brava precisa de qualidade emocional, não apenas de mais sistemas. O António passa a ser o modelo de referência para as restantes personagens.

## Impacto no jogo
O Conselho da Manhã deixa de apresentar apenas assuntos genéricos e começa a refletir a leitura humana de uma personagem central.

## Impacto técnico
Foi criado um serviço dedicado (`antonioService`) que não duplica a arquitetura existente; apenas interpreta o `GameState` e devolve voz/persona contextual.
