# Herança Brava — Sprint 9

Build atualizada a partir do Sprint 8.

## Sprint 9 incluído
- Campanha completa de 5 anos.
- Objetivos anuais.
- Relatórios anuais automáticos.
- Estado da ganadaria.
- Nova tab `Campanha` no Escritório.
- Integração com economia, staff, contratos, prestígio e Save/Load.

## Validação
`npm run build` executado com sucesso.


## Sprint 12 — Personagens e Memória

Adiciona perfis vivos, memória persistente e relações mais humanas às personagens principais do Herdade Life System.

## Sprint 13 — Rotinas e Agenda das Personagens

Esta versão acrescenta agenda e rotina às Personagens Principais. O Conselho da Manhã passa a respeitar disponibilidade, localização e substituições temporárias, reforçando a sensação de herdade viva sem criar novos sistemas duplicados.

## Sprint 18 — Conflito Técnico
Adiciona o primeiro conflito funcional entre Personagens Principais: António vs Dr. Duarte. O Conselho da Manhã passa a poder apresentar dois pareceres técnicos incompatíveis e o jogador escolhe em quem confiar.

## v0.7 — World Simulation
A herdade passa a gerar pequenos acontecimentos ao avançar períodos do dia. As personagens têm rotinas e o Diário regista a vida da casa sem depender apenas das ações diretas do jogador.
